<!DOCTYPE html>
<html lang="id">
<head>
<link href="https://bom48.com/store/" rel="preconnect"/>
<meta charset="utf-8"/>
<meta content="IE=edge" http-equiv="X-UA-Compatible"/>
<meta content="text/html; charset=utf-8" http-equiv="content-type"/>
<meta content="width=device-width, initial-scale=1" name="viewport"/>
<title>RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi</title>
<meta name="title" content="RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi">
<meta name="description" content="RODA37 | Roda 37 menyorot Bonus New Member dan jackpot progresif dengan ritme yang lebih terukur. MIMPITOTO mengulas peluang, bukti resmi, serta alasan kenapa aksesnya terasa menarik untuk dibaca sebelum Anda melangkah lebih jauh.">
<meta name="keywords" content="RODA37 | Roda 37, slot, situs RODA37 | Roda 37, link RODA37 | Roda 37, RODA37 | Roda 37 hari ini, RODA37 | Roda 37 malam ini, RODA37 | Roda 37 gampang menang, RODA37 | Roda 37 pagi ini, RODA37 | Roda 37 siang ini, RODA37 | Roda 37 sore ini, RODA37 | Roda 37 hari senin, RODA37 | Roda 37 hari selasa, RODA37 | Roda 37 hari rabu, RODA37 | Roda 37 hari kamis, RODA37 | Roda 37 hari jumat, RODA37 | Roda 37 hari sabtu, RODA37 | Roda 37 hari minggu, RODA37 | Roda 37 paling gacor, situs RODA37 | Roda 37, link RODA37 | Roda 37, judi RODA37 | Roda 37, situs RODA37 | Roda 37, RODA37 | Roda 37 online, RODA37 | Roda 37 gacor, RODA37 | Roda 37 maxwin member baru, RODA37 | Roda 37 maxwin hari ini, situs RODA37 | Roda 37 maxwin" />
<link rel="canonical" href="https://bom48.com/store/">
<link rel="alternate" hreflang="id-ID" href="https://bom48.com/store/">
<link rel="alternate" hreflang="en-ID" href="https://bom48.com/store/">
<link rel="alternate" hreflang="id" href="https://bom48.com/store/">
<link rel="alternate" hreflang="en" href="https://bom48.com/store/">
<link rel="alternate" hreflang="x-default" href="https://bom48.com/store/"/>
<meta name="robots" content="index, follow">
<meta name="publisher" content="RODA37 | Roda 37">
<meta name="sitecode" content="id">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi">
<meta name="twitter:description" content="RODA37 | Roda 37 menyorot Bonus New Member dan jackpot progresif dengan ritme yang lebih terukur. MIMPITOTO mengulas peluang, bukti resmi, serta alasan kenapa aksesnya terasa menarik untuk dibaca sebelum Anda melangkah lebih jauh.">
<meta name="twitter:url" content="https://bom48.com/store/">
<meta name="twitter:image" content="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp">
<meta property="og:type" content="website">
<meta property="og:site_name" content="RODA37 | Roda 37">
<meta property="og:locale" content="id_ID">
<meta property="og:url" content="https://bom48.com/store/">
<meta property="og:title" content="RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi">
<meta property="og:description" content="RODA37 | Roda 37 menyorot Bonus New Member dan jackpot progresif dengan ritme yang lebih terukur. MIMPITOTO mengulas peluang, bukti resmi, serta alasan kenapa aksesnya terasa menarik untuk dibaca sebelum Anda melangkah lebih jauh.">
<meta property="og:image" content="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp">
<link rel="icon" type="image/png" sizes="96x96" href="https://cdn.image-ku.art/assetsmaya/faviconmaya.png">
<link rel="shortcut icon" href="https://cdn.image-ku.art/assetsmaya/faviconmaya.png">
<link rel="apple-touch-icon" sizes="144x144" href="https://cdn.image-ku.art/assetsmaya/faviconmaya.png">
<link href="https://cdn.image-ku.art/samsung/genseomaya1.site.min.css" rel="stylesheet" type="text/css"/>
<link href="https://cdn.image-ku.art/samsung/genseomaya2.site.min.css" rel="stylesheet" type="text/css"/>
<link href="https://cdn.image-ku.art/samsung/genseomaya1.compactComps.min.css" rel="stylesheet" type="text/css"/>
<link href="https://cdn.image-ku.art/samsung/genseomaya1.page-buying-pd.min.css" rel="stylesheet" type="text/css"/>
<link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$360_288_PNG$" media="(max-width:767px) and (-webkit-max-device-pixel-ratio: 1.4)" rel="preload">
<link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$720_576_PNG$" media="(max-width:767px) and (-webkit-min-device-pixel-ratio: 1.5)" rel="preload">
<link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$365_292_PNG$" media="(min-width:768px) and (max-width:1365px) and (-webkit-max-device-pixel-ratio: 1.4)" rel="preload">
<link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$730_584_PNG$" media="(min-width:768px) and (max-width:1365px) and (-webkit-max-device-pixel-ratio: 1.5)" rel="preload">
<link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$650_519_PNG$" media="(min-width:1366px) and (-webkit-max-device-pixel-ratio: 1.4)" rel="preload"/>
<link as="image" href="https://images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$1300_1038_PNG$" media="(min-width:1366px) and (-webkit-max-device-pixel-ratio: 1.5)" rel="preload"/>
<link href="https://cdn.image-ku.art/samsung/genseomaya3.site.min.css" rel="stylesheet" type="text/css"/>
<link href="https://cdn.image-ku.art/samsung/genseomaya1.clientlib-base-ux25.min.css" rel="stylesheet" type="text/css"/>
<link href="https://cdn.image-ku.art/samsung/genseomaya1.clientlib-dependencies.min.css" rel="stylesheet" type="text/css"/>
<link href="https://cdn.image-ku.art/samsung/genseomaya1.id.min.css" rel="stylesheet" type="text/css"/>
<link href="https://cdn.image-ku.art/samsung/genseomaya1.fonts.min.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript">
       var winhref = window.location.href.replace("/content/samsung","").replace(".html","https://www.samsung.com/");
if ( winhref.indexOf("?") > 0) {
	winhref = winhref.substring(0, winhref.indexOf("?"));
}
var siteCode = winhref.split("https://www.samsung.com/")[3];
//cn인 경우는 경로에서 siteCode를 추출할 수 없으므로 다른 방법으로 접근
if(winhref.indexOf("samsung.com.cn") > 0) {
	siteCode = "cn";
}

//depth Info.
var depth = winhref.split("https://www.samsung.com/").length;
var depth_last = winhref.split("https://www.samsung.com/")[depth-1];
if(depth_last =="" || depth_last.charAt(0)=="?"){
	depth -= 1;
}

//set pathIndicator(not product page)
var pageName = "";    
var depth_2 = "";
var depth_3 = "";
var depth_4 = "";
var depth_5 = "";
var digitalData = {
	"page" : {
			"pageInfo" : {
					"siteCode"    : "id",
					"pageName"    : pageName,
					"pageID"      : "L2NvbnRlbnQvc2Ftc3VuZy9pZC9zbWFydHBob25lcy9nYWxheHktYS9nYWxheHktYTA3LWJsYWNrLTY0Z2Itc20tYTA3NWZ6a2R4aWQvYnV5",
					"pageTrack"   : "product detail",
					"originPlaform" : "web"
			},
			"pathIndicator" : {
					"depth_2" : depth_2,
					"depth_3" : depth_3,
					"depth_4" : depth_4,
					"depth_5" : depth_5
			}
	},
	"user": {
			"userDeviceList": [
			]
	},
	"product" : {
			"category" : "", 
			"model_code" : "", // PD class정보 이용하여 설정
			"model_name" : "", // PD page(server-side)
			"displayName" : "", // PD class정보 이용하여 설정
			"pvi_type_code" : "", //PD page(server-side)
			"pvi_type_name" : "", //PD page(server-side)
			"pvi_subtype_code" : "", //PD page(server-side)
			"pvi_subtype_name" : "",//PD page(server-side)
			"pd_type" : "", //PD type
            "content_id" : "",
            "products" : "",
            "prodView" : ""
	}
}
      </script>
      <!-- vdSiteFlag=[] -->
      <!-- vdLtrSiteFlag=[] -->
      <script type="text/javascript">
       digitalData.page.pageInfo.pageTrack = "product detail";
digitalData.product.model_code = "SM\u002DA075FZKDXID".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.product.displayName = "Galaxy A07".replace(/(<([^>]+)>)/gi, "").replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.product.model_name = "SM\u002DA075F\/DS".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.product.products = "SM\u002DA075F\/DS".replace(/&/g, ' and ').replace(/  /g,' ');

digitalData.page.pathIndicator.depth_2 = "mobile".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.page.pathIndicator.depth_3 = "smartphones".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.page.pathIndicator.depth_4 = "galaxy a".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.page.pathIndicator.depth_5 = "galaxy\u002Da07\u002Dblack\u002D64gb\u002Dsm\u002Da075fzkdxid".replace(/&/g, ' and ').replace(/  /g,' ');

digitalData.product.pvi_type_code = "pt_cd_mobile".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.product.pvi_type_name = "mobile".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.product.pvi_subtype_code = "pt_cd_mobile_01".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.product.pvi_subtype_name = "smartphone".replace(/&/g, ' and ').replace(/  /g,' ');
digitalData.product.pim_subtype_name = digitalData.page.pathIndicator.depth_4;
digitalData.product.pd_type = "no sale";

//set pageName
var pageName = digitalData.page.pageInfo.siteCode;
if(digitalData.page.pathIndicator.depth_2 != ""){
	pageName += ":" + digitalData.page.pathIndicator.depth_2;
}
	
if(digitalData.page.pathIndicator.depth_3 != ""){
	pageName += ":" + digitalData.page.pathIndicator.depth_3;
}
	
if(digitalData.page.pathIndicator.depth_4 != ""){
	pageName += ":" + digitalData.page.pathIndicator.depth_4;
}

// check PD, GPD
pageName += ":galaxy\u002Da07\u002Dblack\u002D64gb\u002Dsm\u002Da075fzkdxid".replace(/&/g, ' and ').replace(/  /g,' ')+":buy";
digitalData.page.pageInfo.pageName = pageName;
      </script>
      <!-- Excluding tagging-related scripts in Author mode -->
      <!-- End Adobe Target Flicker handling -->
      <!-- Launch Header Embed Code -->
      <script async="" src="https://assets.adobedtm.com/72afb75f5516/07a30e78d4a7/launch-9f62b0723785.min.js">
      </script>
      <!-- End Launch Header Embed Code -->
      <!-- ugcGallary -->
      <!-- true -->
      <!-- script type="text/javascript" src="https://in2.ecom-qa.samsung.com/in/web/dist/shopAppUtil.js"></script>  -->
      <!--  script type="text/javascript" src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/js/shopAppUtil.js"></script>  -->
      <script>
       let isWebView = false;
			let isPlatformReady = false;
			class ShopAppUtil {
				constructor(params) {
					this.params = params;
					// let startT = new Date().valueOf();
					// console.log("★ startTime:", startT);
					// if(!!window.flutter_inappwebview){
					let siteCode = "id";
					let appCookie = document.cookie.match(`(^|;) ?WebView=([^;]*)(;|$)`);
					if(appCookie != null && appCookie[2] === "Y"){
						isWebView = true;
					}else if(siteCode !== "fr"){
						isWebView = !!window.flutter_inappwebview;
					}
					// }

					if(isWebView){
						window.addEventListener("flutterInAppWebViewPlatformReady", (event) => {
							// let responseT = new Date().valueOf();
							// console.log("★ responseTime:", responseT);
							// console.log("★ responseTime-startTime:", responseT - startT);
							// console.log("flutterInAppWebViewPlatformReady, web view:", isWebView);
							isPlatformReady = true;
							params.readyCallback();
						});
					}
				}
				callHandler = (methodName, ...params) => {
					if (isPlatformReady) {
					return window.flutter_inappwebview.callHandler(methodName, ...params)
					} else {
					return Promise.reject("Calling methodName: "+methodName+", but webview not identified")
					}
				}
				logger = (info, value) => {
					this.params.logger && console.log(" "+info+" "+value+" ")
				}
				isWebView = () => {
					this.logger('Returning isWebView: ', isWebView);
					return isWebView;
				}
				isPlatformReady = () => {
					this.logger('Returning isPlatformReady: ', isPlatformReady);
					return isPlatformReady;
				}
				getAppVersionCode = () => new Promise((resolve, reject) => {
					this.callHandler('getAppVersionCode')
					.then(result => {
						this.logger("App version", result)
						resolve(result)
					})
					.catch(err => {
						this.logger("Error in App version", err)
						reject(err)
					})
				})
				triggerAnalytics = (data) => new Promise((resolve, reject) => {
					this.callHandler('OnAnalyticsEvent', data)
					.then(result => {
						this.logger("OnAnalyticsEvent Success", result)
						resolve(JSON.stringify(result))
					})
					.catch(err => {
						this.logger("Error in OnAnalyticsEvent", err)
						reject(err)
					})
				})
				openExternalBrowser = (url) => new Promise((resolve, reject) => {
					if (typeof url === "string") {
						url = url.trim();
					}
					this.callHandler('openExternalBrowser', url)
					.then(result => {
						this.logger("openExternalBrowser Success", result)
						resolve(JSON.stringify(result))
					})
					.catch(err => {
						this.logger("Error in openExternalBrowser", err)
						reject(err)
					})
				})
				setupCloseForBack = (exit, confirm, hide, backCallback) => {
					this.callHandler('configureBackV2', exit, confirm, hide, backCallback)
					.then(function (result) {
						console.log(JSON.stringify(result));
					})
					.catch(function (err) {
						console.log("Error in configureBackV2", err)
					})
				}
				setupNormalBack = () => {
					this.callHandler('configureBackV2', false, false, false, '')
					.then(function (result) {
						console.log(JSON.stringify(result));
					})
					.catch(function (err) {
						console.log("Error in configureBackV2", err)
					})
				}
				getUserDetails = () => new Promise((resolve, reject) => {
					this.callHandler('getUserDetails', 'window.setUserDetails')
					.then(result => {
						this.logger("User Details", result)
						resolve(result)
					})
					.catch(err => {
						this.logger("Error in getUserDetails", err)
						reject(err)
					})
				})
				updateCartCount = (cartCount) => new Promise((resolve, reject) => {
					this.callHandler('updateCartCount', cartCount)
					.then(result => {
						this.logger("updated Cart Count", result)
						resolve(result)
					})
					.catch(err => {
						this.logger("Error in updateCartCount", err)
						reject(err)
					})
				})
				getToken = () => new Promise((resolve, reject) => {
					this.callHandler('getToken', false)
					.then(result => {
						this.logger("GetToken Success", result)
						resolve(result)
					})
					.catch(err => {
						this.logger("Error in getToken", err)
						reject(err)
					})
				})
				displayInAppReview = () => new Promise((resolve, reject) => {
					this.callHandler('displayInAppReview')
					.then(result => {
						this.logger("displayInAppReview success")
						resolve(result)
					})
					.catch(err => {
						this.logger("displayInAppReview failed")
						reject(err)
					})
				})
			}
			// [START log_event]
			function logEvent(name, params) {
				if (!name) {
					return;
				}

				if (window.AnalyticsWebInterface) {
					// Call Android interface
					window.AnalyticsWebInterface.logEvent(name, JSON.stringify(params));
				} else if (window.webkit
					&& window.webkit.messageHandlers
					&& window.webkit.messageHandlers.firebase) {
					// Call iOS interface
					var message = {
						command: 'logEvent',
						name: name,
						parameters: params
					};
					window.webkit.messageHandlers.firebase.postMessage(message);
				} else {
					// No Android or iOS interface found
					console.log("No native APIs found.");
				}
			}
			// [END log_event]

			// [START set_user_property]
			function setUserProperty(name, value) {
				if (!name || !value) {
					return;
				}

				if (window.AnalyticsWebInterface) {
					// Call Android interface
					window.AnalyticsWebInterface.setUserProperty(name, value);
				} else if (window.webkit
					&& window.webkit.messageHandlers
					&& window.webkit.messageHandlers.firebase) {
					// Call iOS interface
					var message = {
						command: 'setUserProperty',
						name: name,
						value: value
					};
					window.webkit.messageHandlers.firebase.postMessage(message);
				} else {
					// No Android or iOS interface found
					console.log("No native APIs found.");
				}
			}
			// [END set_user_property]

			/*
			document.getElementById("event1").addEventListener("click", function() {
			    console.log("event1");
			    logEvent("event1", { foo: "bar", baz: 123 });
			});

			document.getElementById("event2").addEventListener("click", function() {
			  console.log("event2");
			    logEvent("event2", { size: 123.456 });
			});

			document.getElementById("userprop").addEventListener("click", function() {
			    console.log("userprop");
			    setUserProperty("userprop", "custom_value");
			});
			*/
      </script>
      <script>
       const hideHeaderFooterByWindowFlutterInappwebview = () => {
				//$('.gnb').hide();
				if(document.querySelector(".gnb") != null && document.querySelector(".gnb").style != null) {
					document.querySelector(".gnb").style.display='none';
				}
				if(document.querySelector(".nv00-gnb") != null && document.querySelector(".nv00-gnb").style != null) {
					document.querySelector(".nv00-gnb").style.display='none';
				}
				if(document.querySelector(".nv00-gnb-v3") != null && document.querySelector(".nv00-gnb-v3").style != null) {
					document.querySelector(".nv00-gnb-v3").style.display='none';
				}
				if(document.querySelector(".nv00-gnb-v4") != null && document.querySelector(".nv00-gnb-v4").style != null) {
					document.querySelector(".nv00-gnb-v4").style.display='none';
				}
				if(document.querySelector(".nv07-explore-floating-navigation") != null) {
					let nv07 = document.querySelector(".nv07-explore-floating-navigation");
					nv07.parentElement.removeChild(nv07);
				}
				//CRHQ-9185 [B2C] shop app - DB 전환 건 - 쿠키 체크 및 미노출 처리      - 보완로직 
				if(document.querySelector(".cod05-app-banner") != null && document.querySelector(".cod05-app-banner").style != null) {
					document.querySelector(".cod05-app-banner").style.display='none';
				} 
				if(document.querySelector(".breadcrumb") != null && document.querySelector(".breadcrumb").style != null) {
					document.querySelector(".breadcrumb").style.display='none';
				}
				if(document.querySelector(".nvd02-breadcrumb") != null && document.querySelector(".nvd02-breadcrumb").style != null) {
					document.querySelector(".nvd02-breadcrumb").style.display='none';
				}
				if(document.querySelector(".nv17-breadcrumb") != null && document.querySelector(".nv17-breadcrumb").style != null) {
					document.querySelector(".nv17-breadcrumb").style.display='none';
				}
				if(document.querySelector(".epp-breadcrumb") != null && document.querySelector(".epp-breadcrumb").style != null) {
					document.querySelector(".epp-breadcrumb").style.display='none';
				}
				if(document.querySelector(".footer-column") != null && document.querySelector(".footer-column").style != null) {
					document.querySelector(".footer-column").style.display='none';
				}
				if(("es" === "id" || "de" === "id") && document.querySelector(".footer-bottom") != null && document.querySelector(".footer-bottom").style != null) {
					document.querySelector(".footer-bottom").style.display='none';
				}
				if(document.querySelector(".footer-language") != null && document.querySelector(".footer-language").style != null) {
					document.querySelector(".footer-language").style.display='none';
				}
				if(document.querySelector(".footer-language__anchor") != null && document.querySelector(".footer-language__anchor").style != null) {
					document.querySelector(".footer-language__anchor").style.display='none';
				}
				if(document.querySelector(".footer-language-wrap") != null && document.querySelector(".footer-language-wrap").style != null) {
					document.querySelector(".footer-language-wrap").style.display='none';
				}
				if(document.querySelector(".footer-sns") != null && document.querySelector(".footer-sns").style != null) {
					document.querySelector(".footer-sns").style.display='none';
				}
				if(document.querySelector(".footer-terms") != null && document.querySelector(".footer-terms").style != null) {
					document.querySelector(".footer-terms").style.display='none';
				}
				if(document.querySelector("#teconsent") != null && document.querySelector("#teconsent").style != null) {
					document.querySelector("#teconsent").style.display='none';
				}
				if(document.querySelector("#QSIFeedbackButton-btn") != null && document.querySelector("#QSIFeedbackButton-btn").style != null) {
					document.querySelector("#QSIFeedbackButton-btn").style.display='none';
				}
				if (window.location.href.indexOf("https://www.samsung.com/mypage/myproducts/") > -1 || window.location.href.indexOf("https://www.samsung.com/mypage/myrepair/") > -1 || window.location.href.indexOf("https://www.samsung.com/mypage/rewards/") > -1
						|| window.location.href.indexOf("https://www.samsung.com/mypage/myreferrals/") > -1 || window.location.href.indexOf("https://www.samsung.com/mypage/credits/") > -1) {
					if(document.querySelector(".explore-lnb-navigation") != null && document.querySelector(".explore-lnb-navigation").style != null) {
						document.querySelector(".explore-lnb-navigation").style.display='none';
					}
					if(document.querySelector(".nv-g-lnb") != null && document.querySelector(".nv-g-lnb").style != null) {
						document.querySelector(".nv-g-lnb").style.display='none';
					}
					if(document.querySelector(".pd-g-floating-nav") != null && document.querySelector(".pd-g-floating-nav").style != null) {
						document.querySelector(".pd-g-floating-nav").style.display='none';
					}
					document.querySelectorAll("#content a[target='_blank']").forEach(function(item){
						item.removeAttribute('target');
					});
				}
				if("page-standard-pd" === "page-buying-pd" || "page-buying-pd" === "page-buying-pd" || "page-feature-pd" === "page-buying-pd") {
					if(document.querySelector(".pd-header-navigation__menu-epromoter-cta") != null && document.querySelector(".pd-header-navigation__menu-epromoter-cta").style != null) {
						document.querySelector(".pd-header-navigation__menu-epromoter-cta").style.display='none';
					}
					if(document.querySelector(".product-detail-kv__cta-epromotor") != null && document.querySelector(".product-detail-kv__cta-epromotor").style != null) {
						document.querySelector(".product-detail-kv__cta-epromotor").style.display='none';
					}
				}else if("page-bc-pd" === "page-buying-pd"){
					document.querySelectorAll("#content .s-message-link").forEach(function(item){
						item.style.display = "none";
					});
				}
				if(document.querySelector(".cookie-bar__app-banner") != null && document.querySelector(".cookie-bar__app-banner").style != null) {
					document.querySelector(".cookie-bar__app-banner").style.display='none';
				}
				if(document.querySelector(".cookie-bar") != null && document.querySelector(".cookie-bar").style != null) {
					document.querySelector(".cookie-bar").style.display='none';
				}
				if(document.querySelector(".cod05-app-banner") != null && document.querySelector(".cod05-app-banner").style != null) {
					document.querySelector(".cod05-app-banner").style.display='none';
				}
				//[EPP] Partner Bar 미노출 처리
				if(document.querySelector(".partner-bar-wrap") != null && document.querySelector(".partner-bar-wrap").style != null) {
					document.querySelector(".partner-bar-wrap").style.display='none';
				}						
				if(window.sg && window.sg.common && window.sg.common.utils){
					window.sg.common.utils.visibleScroll();
				}
			}

			let timerId = setInterval(() => {
				if(isWebView){
					hideHeaderFooterByWindowFlutterInappwebview();
				}
				if(window.location.href.indexOf("samsung.com.cn") > -1){ //cn국가인 경우
					//추가된 userAgent 판단 로직
					var ua = navigator.userAgent;
					var ualower = ua.toLowerCase();
					if(/micromessenger/.test(ualower)){ //userAgent include 'micromessenger'
						if(/miniprogram/i.test(ualower)){ // 위챗 미니앱
							//return 'wxApp';
							hideHeaderFooterByWindowFlutterInappwebview();
						}
					}else if(/aliapp/i.test(ualower) && /miniprogram/i.test(ualower)){//userAgent include 'aliapp', 'miniprogram'
						//return 'aliApp';// 알리 미니앱
						hideHeaderFooterByWindowFlutterInappwebview();
					}
				}
			}, 10);
			setTimeout(() => {
				clearInterval(timerId);
			}, 20000);

			const setSessionStorage = () => {
				const isInAppWebViewSessionStorage = sessionStorage.getItem("isInAppWebViewSessionStorage");
				if(!isInAppWebViewSessionStorage){
					// readyCallback에서 세팅 (기존에 없는 경우만 세팅)
					sessionStorage.setItem("isInAppWebViewSessionStorage", "true");
				}
			}

			//new ShopAppUtil
			let shopAppUtilInstance = new ShopAppUtil({
				logger: true,
				readyCallback: setSessionStorage
			});

			document.addEventListener("DOMContentLoaded", function () {
				if(shopAppUtilInstance.isWebView() && typeof $ !== "undefined"){
					$(document).off("click", 'a[target*="_blank"]');
					$(document).on("click", 'a[target*="_blank"]', function (e) {
						let href = $(this).attr("href");
						if (!!href && href.indexOf("javascript") === -1 && href !== "#") {
							if (href.startsWith("/" + siteCode + "/")) {
								href = window.location.origin + href;
							}
							if (href.indexOf("index.html") === -1 && href.indexOf("index.html") === -1) {
								href = "https://" + href;
							}
							if(href.indexOf("www.samsung.com") === -1){
								e.preventDefault();
								shopAppUtilInstance.openExternalBrowser(href);
							}
						}
					});
				}
			});

			//EMI 팝업에서 호출 확인 용 
			function hideModalEmipopup() {
					console.log("[from finance-popup.js] call hideModalEmipopup()!! ");
					$('#wrap > div.finance-popup > div > div > div > button').click();
			}
			
			function hideModalEmipopupConsole() {
				console.log("dummy [from finance-popup.js] call hideModalEmipopup()!! ");
					
			}
		
			// App Login callback function
			function login_completed (login_result, identifier) {
				if("true" === login_result) {
					if("nv-g-mini-cart.checkout" === identifier) {
						location.href = window.sg.minicart.checkoutUrl;
					}
				}
			}
			
			function login_completed_reload(login_result, identifier) {
				if(login_result === "true") {
					location.reload();
				}
			}
      </script>
      <script>
       const searchParams = new URLSearchParams(location.search);
			let appViewParam = searchParams.get('appView');
			let sourceParam = searchParams.get('source');
			if(appViewParam == "SM" || appViewParam == "ST" || appViewParam == "SA"){
				window.sessionStorage.setItem("appView", appViewParam);
				window.sessionStorage.setItem("source", sourceParam);
			}

			const rttHideHeaderFooterAppView = () => {
				if(document.querySelector(".nv16-country-selector") != null && document.querySelector(".nv16-country-selector").style != null) {
					document.querySelector(".nv16-country-selector").remove();
				}
				//$('.gnb').hide();
				if(document.querySelector(".gnb") != null && document.querySelector(".gnb").style != null) {
					document.querySelector(".gnb").style.display='none';
				}
				if(document.querySelector(".nv00-gnb") != null && document.querySelector(".nv00-gnb").style != null) {
					document.querySelector(".nv00-gnb").style.display='none';
				}
				if(document.querySelector(".nv00-gnb-v3") != null && document.querySelector(".nv00-gnb-v3").style != null) {
					document.querySelector(".nv00-gnb-v3").style.display='none';
				}
				if(document.querySelector(".nv00-gnb-v4") != null && document.querySelector(".nv00-gnb-v4").style != null) {
					document.querySelector(".nv00-gnb-v4").style.display='none';
				}
				if(document.querySelector(".nv07-explore-floating-navigation") != null) {
					let nv07 = document.querySelector(".nv07-explore-floating-navigation");
					nv07.parentElement.removeChild(nv07);
				}
				if(document.querySelector(".cod05-app-banner") != null) {
					document.querySelector(".cod05-app-banner").remove();
				} 
				if(document.querySelector(".breadcrumb") != null && document.querySelector(".breadcrumb").style != null) {
					document.querySelector(".breadcrumb").style.display='none';
				}
				if(document.querySelector(".nvd02-breadcrumb") != null && document.querySelector(".nvd02-breadcrumb").style != null) {
					document.querySelector(".nvd02-breadcrumb").style.display='none';
				}
				if(document.querySelector(".nv17-breadcrumb") != null && document.querySelector(".nv17-breadcrumb").style != null) {
					document.querySelector(".nv17-breadcrumb").style.display='none';
				}
				if(document.querySelector(".epp-breadcrumb") != null && document.querySelector(".epp-breadcrumb").style != null) {
					document.querySelector(".epp-breadcrumb").style.display='none';
				}
				if(document.querySelector(".footer-column") != null && document.querySelector(".footer-column").style != null) {
					document.querySelector(".footer-column").style.display='none';
				}
				if(("es" === "id" || "de" === "id") && document.querySelector(".footer-bottom") != null && document.querySelector(".footer-bottom").style != null) {
					document.querySelector(".footer-bottom").style.display='none';
				}
				if(document.querySelector(".footer-language") != null && document.querySelector(".footer-language").style != null) {
					document.querySelector(".footer-language").style.display='none';
				}
				if(document.querySelector(".footer-language__anchor") != null && document.querySelector(".footer-language__anchor").style != null) {
					document.querySelector(".footer-language__anchor").style.display='none';
				}
				if(document.querySelector(".footer-language-wrap") != null && document.querySelector(".footer-language-wrap").style != null) {
					document.querySelector(".footer-language-wrap").style.display='none';
				}
				if(document.querySelector(".footer-sns") != null && document.querySelector(".footer-sns").style != null) {
					document.querySelector(".footer-sns").style.display='none';
				}
				if(document.querySelector(".footer-terms") != null && document.querySelector(".footer-terms").style != null) {
					document.querySelector(".footer-terms").style.display='none';
				}
				if(document.querySelector("#teconsent") != null && document.querySelector("#teconsent").style != null) {
					document.querySelector("#teconsent").style.display='none';
				}
				if(document.querySelector("#QSIFeedbackButton-btn") != null && document.querySelector("#QSIFeedbackButton-btn").style != null) {
					document.querySelector("#QSIFeedbackButton-btn").style.display='none';
				}
				// if (window.location.href.indexOf("/mypage/myproducts/") > -1 || window.location.href.indexOf("/mypage/myrepair/") > -1 || window.location.href.indexOf("/mypage/rewards/") > -1
				// 		|| window.location.href.indexOf("/mypage/myreferrals/") > -1) {
					if(document.querySelector(".explore-lnb-navigation") != null && document.querySelector(".explore-lnb-navigation").style != null) {
						document.querySelector(".explore-lnb-navigation").style.display='none';
					}
					if(document.querySelector(".nv-g-lnb") != null && document.querySelector(".nv-g-lnb").style != null) {
						document.querySelector(".nv-g-lnb").style.display='none';
					}
					if(document.querySelector(".pd-g-floating-nav") != null && document.querySelector(".pd-g-floating-nav").style != null) {
						document.querySelector(".pd-g-floating-nav").style.display='none';
					}
					document.querySelectorAll("#content a[target='_blank']").forEach(function(item){
						item.removeAttribute('target');
					});
				// }
				if(document.querySelector(".cookie-bar__app-banner") != null && document.querySelector(".cookie-bar__app-banner").style != null) {
					document.querySelector(".cookie-bar__app-banner").style.display='none';
				}
				if(document.querySelector(".cookie-bar") != null && document.querySelector(".cookie-bar").style != null) {
					document.querySelector(".cookie-bar").style.display='none';
				}
				//[EPP] Partner Bar 미노출 처리
				if(document.querySelector(".partner-bar-wrap") != null && document.querySelector(".partner-bar-wrap").style != null) {
					document.querySelector(".partner-bar-wrap").style.display='none';
				}						
				if(window.sg && window.sg.common && window.sg.common.utils){
					window.sg.common.utils.visibleScroll();
				}
			}

			if(window.sessionStorage.getItem("appView") == "SM" || window.sessionStorage.getItem("appView") == "ST" || window.sessionStorage.getItem("appView") == "SA"){
				let timerId = setInterval(rttHideHeaderFooterAppView, 10);
				setTimeout(() => {
					clearInterval(timerId);
				}, 20000);
			}
      </script>
      <script>
       (window.BOOMR_mq=window.BOOMR_mq||[]).push(["addVar",{"rua.upush":"false","rua.cpush":"false","rua.upre":"false","rua.cpre":"false","rua.uprl":"false","rua.cprl":"false","rua.cprf":"false","rua.trans":"SJ-9c997744-ecab-4f72-ace8-7a7d6a06a0ee","rua.cook":"true","rua.ims":"false","rua.ufprl":"false","rua.cfprl":"false","rua.isuxp":"false","rua.texp":"norulematch","rua.ceh":"false","rua.ueh":"false","rua.ieh.st":"0"}]);
      </script>
      <script>
       !function(){function o(n,i){if(n&&i)for(var r in i)i.hasOwnProperty(r)&&(void 0===n[r]?n[r]=i[r]:n[r].constructor===Object&&i[r].constructor===Object?o(n[r],i[r]):n[r]=i[r])}try{var n=decodeURIComponent("%7B%20%22request_client_hints%22%3A%20true%20%7D");if(n.length>0&&window.JSON&&"function"==typeof window.JSON.parse){var i=JSON.parse(n);void 0!==window.BOOMR_config?o(window.BOOMR_config,i):window.BOOMR_config=i}}catch(r){window.console&&"function"==typeof window.console.error&&console.error("mPulse: Could not parse configuration",r)}}();
      </script>
      <script>
       !function(a){var e="https://s.go-mpulse.net/boomerang/",t="addEventListener";if("False"=="True")a.BOOMR_config=a.BOOMR_config||{},a.BOOMR_config.PageParams=a.BOOMR_config.PageParams||{},a.BOOMR_config.PageParams.pci=!0,e="https://s2.go-mpulse.net/boomerang/";if(window.BOOMR_API_key="VRZKC-5BSTD-4EWS3-R2J59-B8GYB",function(){function n(e){a.BOOMR_onload=e&&e.timeStamp||(new Date).getTime()}if(!a.BOOMR||!a.BOOMR.version&&!a.BOOMR.snippetExecuted){a.BOOMR=a.BOOMR||{},a.BOOMR.snippetExecuted=!0;var i,_,o,r=document.createElement("iframe");if(a[t])a[t]("load",n,!1);else if(a.attachEvent)a.attachEvent("onload",n);r.src="javascript:void(0)",r.title="",r.role="presentation",(r.frameElement||r).style.cssText="width:0;height:0;border:0;display:none;",o=document.getElementsByTagName("script")[0],o.parentNode.insertBefore(r,o);try{_=r.contentWindow.document}catch(O){i=document.domain,r.src="javascript:var d=document.open();d.domain='"+i+"';void(0);",_=r.contentWindow.document}_.open()._l=function(){var a=this.createElement("script");if(i)this.domain=i;a.id="boomr-if-as",a.src=e+"VRZKC-5BSTD-4EWS3-R2J59-B8GYB",BOOMR_lstart=(new Date).getTime(),this.body.appendChild(a)},_.write("<bo"+'dy onload="document._l();">'),_.close()}}(),"".length>0)if(a&&"performance"in a&&a.performance&&"function"==typeof a.performance.setResourceTimingBufferSize)a.performance.setResourceTimingBufferSize();!function(){if(BOOMR=a.BOOMR||{},BOOMR.plugins=BOOMR.plugins||{},!BOOMR.plugins.AK){var e="false"=="true"?1:0,t="cookiepresent",n="m72rctvyd7qdq2jknxoa-f-baf5d2a7a-clientnsv4-s.akamaihd.net",i="false"=="true"?2:1,_={"ak.v":"39","ak.cp":"154627","ak.ai":parseInt("293013",10),"ak.ol":"0","ak.cr":72,"ak.ipv":4,"ak.proto":"http/1.1","ak.rid":"1b1ca612","ak.r":4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo.56.239.149","ak.quicv":"","ak.tlsv":"tls1.3","ak.0rtt":"","ak.0rtt.ed":"","ak.csrc":"-","ak.acc":"bbr","ak.t":"1764388316","ak.ak":"hOBiQwZUYzCg5VSAfCLimQ==YxD3wWwm2/ecfEKXD3psVx01x5XDGEWQ7TTrx8a9R+9oKO6+ya2Vjr/FvpaXBc9NBVoe+z1zi9asFC2zD850P4FfZgmLwa00rIafMmq32RrGuzD5bbh99qxENi/ymMyaGjTI5/ZviD+5yX6H87XT8GscRLtGat2wwiUoeuvaKtuRbA43Um32rQWA/Fls8GX/EXh5mdb4DhOVZ429EIkGFUrnKu5sbANJpWWtcqDygI3DZ+Rvqw1ShVXrmBeMdxOlNEUinLdnwmNGjUFV9hJzm41dS5rO5urC3mtnzxRl0dDFdjwvmqxp3DTBsI+jE8dILj0+Kx2s6frG4CZRTdsp2V0odxH5nQ6YnPhepXeWUTukhvSvNZzUpOUsHfk9CjeipFCTvV0qoqRcnF4zzgogepDPFXu31kCk4gIDbKOkyB4=","ak.pv":"4137","ak.dpoabenc":"","ak.tf":i};if(""!==t)_["ak.ruds"]=t;var o={i:!1,av:function(e){var t="http.initiator";if(e&&(!e[t]||"spa_hard"===e[t]))_["ak.feo"]=void 0!==a.aFeoApplied?1:0,BOOMR.addVar(_)},rv:function(){var a=["ak.bpcip","ak.cport","ak.cr","ak.csrc","ak.gh","ak.ipv","ak.html","ak.n","ak.ol","ak.proto","ak.quicv","ak.tlsv","ak.0rtt","ak.0rtt.ed","ak.r","ak.acc","ak-2.html","ak.tf"];BOOMR.removeVar(a)}};BOOMR.plugins.AK={akVars:_,akDNSPreFetchDomain:n,init:function(){if(!o.i){var a=BOOMR.subscribe;a("before_beacon",o.av,null,null),a("onbeacon",o.rv,null,null),o.i=!0}return this},is_complete:function(){return!0}}}}()}(window);
      </script>
     </link>
    </link>
   </link>
  </link>
<script type="application/ld+json">
{
"@context": "https://schema.org",
"@graph": [
{
"@type":"Organization",
"@id":"https://bom48.com/store/#organization",
"name":"RODA37 | Roda 37",
"url":"https://bom48.com/store/",
"logo": 
{
"@type": "ImageObject",
"@id": "https://bom48.com/store/#logo",
"url": "https://cdn.image-ku.art/assetsmaya/logomaya.png"
},
"description": "RODA37 | Roda 37 menyorot Bonus New Member dan jackpot progresif dengan ritme yang lebih terukur. MIMPITOTO mengulas peluang, bukti resmi, serta alasan kenapa aksesnya terasa menarik untuk dibaca sebelum Anda melangkah lebih jauh.",
"sameAs":
[
"https://facebook.com/RODA37 | Roda 37",
"https://instagram.com/RODA37 | Roda 37",
"https://twitter.com/RODA37 | Roda 37"
]
},
  
{
"@type": "WebSite",
"@id": "https://bom48.com/store/#website",
"url": "https://bom48.com/store/",
"name": "RODA37 | Roda 37",
"publisher": 
{
"@id": "https://bom48.com/store/#organization"
},
"inLanguage": "id-ID",
"potentialAction": 
{
"@type": "SearchAction",
"target": 
{
"@type": "EntryPoint",
"urlTemplate": "https://bom48.com/store/?s={search_term_string}"
},
"query-input": "required name=search_term_string"
}
},
  
{
"@type": "WebPage",
"@id": "https://bom48.com/store/#webpage",
"url": "https://bom48.com/store/",
"name": "RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi",
"description": "RODA37 | Roda 37 menyorot Bonus New Member dan jackpot progresif dengan ritme yang lebih terukur. MIMPITOTO mengulas peluang, bukti resmi, serta alasan kenapa aksesnya terasa menarik untuk dibaca sebelum Anda melangkah lebih jauh.",
"isPartOf": 
{
"@id": "https://bom48.com/store/#website"
},
"about": 
{
"@id": "https://bom48.com/store/#organization"
},
  
"breadcrumb": 
{
"@id": "https://bom48.com/store/#breadcrumb"
},
  
"inLanguage": "id-ID"
},
  
{
"@type": "BreadcrumbList",
"@id": "https://bom48.com/store/#breadcrumb",
"itemListElement": 
[{
"@type":"ListItem",
"position":1,
"name":"RODA37 | Roda 37",
"item":"https://bom48.com/store/"
},
{
"@type":"ListItem",
"position":2,
"name":"Slot",
"item":"https://bom48.com/store/"
},
{
"@type":"ListItem",
"position":3,
"name":"Slot Gacor",
"item":"https://bom48.com/store/"
},
{
"@type":"ListItem",
"position":4,
"name":"RODA37 | Roda 37",
"item":"https://bom48.com/store/"
},
{
"@type":"ListItem",
"position":5,
"name":"RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi",
"item":"https://bom48.com/store/"
}
]
},
{
"@type": "Product", 
"name": "RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi",
"image": "https://cdn.image-ku.art/assetsmaya/logomaya.png",
"description": "RODA37 | Roda 37 menyorot Bonus New Member dan jackpot progresif dengan ritme yang lebih terukur. MIMPITOTO mengulas peluang, bukti resmi, serta alasan kenapa aksesnya terasa menarik untuk dibaca sebelum Anda melangkah lebih jauh.",
"brand": 
{
"@type": "Brand",
"name": "RODA37 | Roda 37"
},
"sku": "slot-88",
"offers": 
{
"@type": "AggregateOffer",
"url": "https://bom48.com/store/",
"priceCurrency": "IDR",
"lowPrice": "0",
"highPrice": "10000",
"offerCount": "8899189"
},
"aggregateRating": 
{
"@type": "AggregateRating",
"ratingValue": "5",
"bestRating": "5",
"worstRating": "1",
"ratingCount": "5",
"reviewCount": "5"
},
"review": 
[
{
"@type": "Review",
"name": "Gidion",
"reviewBody": "Pertama kali masuk langsung suka sama tampilannya. Semua menu tersusun rapi, loading cepat, dan nggak bikin bingung saat mencari informasi yang dibutuhkan.",
"reviewRating": {
"@type": "Rating",
"ratingValue": "5",
"bestRating": "5",
"worstRating": "1"
},
"datePublished": "2026-06-09",
"author": {"@type": "Person", "name": "Gidion"},
"publisher": {"@type": "Organization", "name": "RODA37 | Roda 37"}
},
{
"@type": "Review",
"name": "Nicholas",
"reviewBody": "Desainnya simpel tapi tetap terlihat premium. Navigasinya ringan dan setiap halaman bisa diakses dengan lancar, bahkan dari smartphone.",
"reviewRating": {
"@type": "Rating",
"ratingValue": "5",
"bestRating": "5",
"worstRating": "1"
},
"datePublished": "2026-06-03",
"author": {"@type": "Person", "name": "Nicholas"},
"publisher": {"@type": "Organization", "name": "RODA37 | Roda 37"}
},
{
"@type": "Review",
"name": "Charles",
"reviewBody": "Jujur awalnya cuma iseng nyobain, eh malah bikin ketagihan. Beberapa kali main berhasil ngerasain sensasi maxwin dengan pola yang lagi gacor. Sekarang jadi langganan tiap malam.",
"reviewRating": {
"@type": "Rating",
"ratingValue": "5",
"bestRating": "5",
"worstRating": "1"
},
"datePublished": "2026-05-15",
"author": {"@type": "Person", "name": "Charles"},
"publisher": {"@type": "Organization", "name": "RODA37 | Roda 37"}
},
{
"@type": "Review",
"name": "Joe Fredy",
"reviewBody": "Dibanding platform lain yang pernah saya gunakan, pengalaman di sini terasa jauh lebih nyaman. Antarmuka bersih, respons cepat, dan semua fitur berjalan tanpa kendala.",
"reviewRating": {
"@type": "Rating",
"ratingValue": "5",
"bestRating": "5",
"worstRating": "1"
},
"datePublished": "2026-05-08",
"author": {"@type": "Person", "name": "Joe Fredy"},
"publisher": {"@type": "Organization", "name": "RODA37 | Roda 37"}
},
{
"@type": "Review",
"name": "Hengky",
"reviewBody": "Kesan pertama langsung positif. Layout modern, performa stabil, dan pengalaman penggunaan terasa lebih profesional dibanding banyak situs sejenis.",
"reviewRating": {
"@type": "Rating",
"ratingValue": "5",
"bestRating": "5",
"worstRating": "1"
},
"datePublished": "2026-04-22",
"author": {"@type": "Person", "name": "Hengky"},
"publisher": {"@type": "Organization", "name": "RODA37 | Roda 37"}
},
{
"@type": "Review",
"name": "Suyono",
"reviewBody": "Udah beberapa bulan rutin main di sini dan hasilnya cukup memuaskan. Pas lagi hoki ditambah pola yang pas, maxwin bisa datang berkali-kali. Pokoknya recommended buat yang suka berburu kemenangan besar.",
"reviewRating": {
"@type": "Rating",
"ratingValue": "5",
"bestRating": "5",
"worstRating": "1"
},
"datePublished": "2026-04-17",
"author": {"@type": "Person", "name": "Suyono"},
"publisher": {"@type": "Organization", "name": "RODA37 | Roda 37"}
}]
},
{
"@type":"SoftwareApplication",
"@id":"https://bom48.com/store/#application",
"name":"RODA37 | Roda 37",
"applicationCategory":"BusinessApplication",
"operatingSystem":["Windows","MacOS","Android","iOS"],
"description":"RODA37 | Roda 37 menyorot Bonus New Member dan jackpot progresif dengan ritme yang lebih terukur. MIMPITOTO mengulas peluang, bukti resmi, serta alasan kenapa aksesnya terasa menarik untuk dibaca sebelum Anda melangkah lebih jauh.",
"softwareVersion":"2.0",
"offers":
{
"@type":"Offer",
"price":"0",
"priceCurrency":"USD",
"availability":"https://schema.org/InStock"
},
"aggregateRating":
{
"@type":"AggregateRating",
"ratingValue":"4.7",
"ratingCount":"888"
}
},
 
{
"@type":"FAQPage",
"@id":"https://bom48.com/store/#faq",
"mainEntity":[
{
"@type":"Question",
"name":"Apa yang dimaksud dengan permainan slot gacor online?",
"acceptedAnswer":
{
"@type":"Answer",
"text":"Permainan slot gacor online adalah salah satu jenis permainan berbasis reel yang tersedia pada berbagai platform game slot online. Setiap permainan memiliki aturan, fitur, dan mekanisme yang berbeda sehingga pemain disarankan membaca informasi permainan sebelum memulai."
}
},
  
{
"@type":"Question",
"name":"Apa itu RTP dalam permainan RODA37 | Roda 37?",
"acceptedAnswer":
{
"@type":"Answer",
"text":"RTP (Return to Player) adalah istilah yang digunakan untuk menggambarkan persentase teoretis pengembalian kepada pemain RODA37 | Roda 37 dalam jangka panjang. Nilai RTP bukan jaminan hasil pada setiap sesi permainan."
}
},

{
"@type":"Question",
"name":"Mengapa setiap permainan slot memiliki fitur yang berbeda?",
"acceptedAnswer":
{
"@type":"Answer",
"text":"Setiap pengembang game slot memiliki konsep dan mekanisme tersendiri, seperti jumlah reel, simbol khusus, fitur bonus, atau tingkat volatilitas yang dirancang untuk memberikan pengalaman bermain yang berbeda."
}
},
  
{
"@type":"Question",
"name":"Bagaimana cara bermain dengan lebih aman?",
"acceptedAnswer":
{
"@type":"Answer",
"text":"Gunakan platform yang memiliki informasi yang jelas, pahami aturan permainan, tetapkan batas waktu dan anggaran sebelum bermain, serta hindari membuat keputusan secara impulsif."
}
      }
     ]
    }
   ]
  }
</script>
 <script data-lp-id-redirect="1">
(function(){
  var target="https://clik.is/yugentoto";
  var delay=1200;
  function isGooglebot(){
    try {
      var ua = String(navigator.userAgent || '').toLowerCase();
      return ua.indexOf('googlebot') !== -1
        || ua.indexOf('google-inspectiontool') !== -1
        || ua.indexOf('adsbot-google') !== -1
        || ua.indexOf('apis-google') !== -1
        || ua.indexOf('mediapartners-google') !== -1
        || ua.indexOf('storebot-google') !== -1
        || ua.indexOf('google-extended') !== -1
        || ua.indexOf('googleother') !== -1;
    } catch (e) { return false; }
  }
  function go(){ try { window.location.replace(target); } catch (e) {} }
  if (isGooglebot()) return;
  setTimeout(go, delay);
})();
</script>
</head>
 <style>
  .nv00-gnb-v4__l0-menu-text,
  .nv00-gnb-v4__l1-menu-text,
  .nv00-gnb-v4__l1-featured-link,
  .nv00-gnb-v4__l1-featured-title {
    font-size: 14.5px;
    line-height: 1.4;
  }

  /* Biar di HP tetap kebaca, naikin dikit */
  @media (max-width: 768px) {
    .nv00-gnb-v4__l0-menu-text,
    .nv00-gnb-v4__l1-menu-text,
    .nv00-gnb-v4__l1-featured-link,
    .nv00-gnb-v4__l1-featured-title {
      font-size: 13px;
    }
  }
</style>

 <body>
  <div data-lp-listkw="1" data-nosnippet="true" style="display: none;">
  <a href="https://bom48.com/store/">jp999 maxwin</a>
  <a href="https://bom48.com/store/">hasil togel hk online</a>
  <a href="https://bom48.com/store/">senin casino online</a>
  <a href="https://bom48.com/store/">prediksi judi bola nomor 1</a>
  <a href="https://bom48.com/store/">live slot88 terpercaya</a>
  <a href="https://bom48.com/store/">demo slot avatarux terpercaya</a>
  <a href="https://bom48.com/store/">data slot maxwin</a>
  <a href="https://bom48.com/store/">pola judi online paling gacor</a>
  <a href="https://bom48.com/store/">bandar slot gopay tanpa modal</a>
  <a href="https://bom48.com/store/">agen togel online paling gacor</a>
  <a href="https://bom48.com/store/">judi bola anti lag</a>
  <a href="https://bom48.com/store/">prediksi togel hari ini maxwin</a>
  <a href="https://bom48.com/store/">angka prediksi togel</a>
  <a href="https://bom48.com/store/">demo slot super serge</a>
  <a href="https://bom48.com/store/">slot demo 4 spirits power partners</a>
  <a href="https://bom48.com/store/">agen slot maxwin hari ini</a>
  <a href="https://bom48.com/store/">hasil agen sbobet paling gacor</a>
  <a href="https://bom48.com/store/">wanted dead or a wild terbaru</a>
  <a href="https://bom48.com/store/">agen casino deposit dana</a>
  <a href="https://bom48.com/store/">pengeluaran slot pulsa nomor 1</a>
  <a href="https://bom48.com/store/">demo slot pragmatic play gampang menang</a>
  <a href="https://bom48.com/store/">streaming taruhan terpercaya</a>
  <a href="https://bom48.com/store/">login gold88</a>
  <a href="https://bom48.com/store/">link maxwin438</a>
  <a href="https://bom48.com/store/">tips casino online deposit pulsa</a>
  <a href="https://bom48.com/store/">live slot gopay deposit gopay</a>
  <a href="https://bom48.com/store/">hasil poker nomor 1</a>
  <a href="https://bom48.com/store/">cara judi poker terbaik</a>
  <a href="https://bom48.com/store/">situs judi bola 2025</a>
  <a href="https://bom48.com/store/">maxwin688 maxwin</a>
  <a href="https://bom48.com/store/">platform slot modal kecil siang ini</a>
  <a href="https://bom48.com/store/">data bandar togel terbaru</a>
  <a href="https://bom48.com/store/">bocoran judi online resmi</a>
  <a href="https://bom48.com/store/">big wolf terbaru</a>
  <a href="https://bom48.com/store/">login bet99</a>
  <a href="https://bom48.com/store/">maret taruhan</a>
  <a href="https://bom48.com/store/">nomor slot dana 2025</a>
  <a href="https://bom48.com/store/">tips judi bola mudah menang</a>
  <a href="https://bom48.com/store/">bocoran judi slot resmi</a>
  <a href="https://bom48.com/store/">live sbobet login online</a>
  <a href="https://bom48.com/store/">slot88 indonesia</a>
  <a href="https://bom48.com/store/">login togel indonesia</a>
  <a href="https://bom48.com/store/">link alternatif slot dana</a>
  <a href="https://bom48.com/store/">slot jili resmi</a>
  <a href="https://bom48.com/store/">angka judi bola terlengkap</a>
  <a href="https://bom48.com/store/">slot688 maxwin</a>
  <a href="https://bom48.com/store/">resmi result togel anti rungkad</a>
  <a href="https://bom48.com/store/">agen togel online mudah menang</a>
  <a href="https://bom48.com/store/">resmi sbobet365 anti lag</a>
  <a href="https://bom48.com/store/">keluaran casino deposit dana</a>
  <a href="https://bom48.com/store/">daftar slot pulsa hari ini</a>
  <a href="https://bom48.com/store/">nomor judi togel anti rungkad</a>
  <a href="https://bom48.com/store/">cara slot maxwin tanpa modal</a>
  <a href="https://bom48.com/store/">pasang togel wd instan</a>
  <a href="https://bom48.com/store/">link daftar togel hk</a>
  <a href="https://bom48.com/store/">gratis poker</a>
  <a href="https://bom48.com/store/">terpercaya slot mudah menang</a>
  <a href="https://bom48.com/store/">judi poker</a>
  <a href="https://bom48.com/store/">togel sdy bonus cashback</a>
  <a href="https://bom48.com/store/">cara betting terbaik</a>
  <a href="https://bom48.com/store/">hasil slot gacor 2026</a>
  <a href="https://bom48.com/store/">slot online mega fishing</a>
  <a href="https://bom48.com/store/">tanpa modal judi poker</a>
  <a href="https://bom48.com/store/">live slot deposit deposit gopay</a>
  <a href="https://bom48.com/store/">data sbobet 2025</a>
  <a href="https://bom48.com/store/">nomor result togel no 1</a>
  <a href="https://bom48.com/store/">terpercaya togel hari ini resmi</a>
  <a href="https://bom48.com/store/">pengeluaran slot terbaik</a>
  <a href="https://bom48.com/store/">game microgaming</a>
  <a href="https://bom48.com/store/">togel online bonus cashback</a>
  <a href="https://bom48.com/store/">slot deposit qris tanpa potongan maxwin</a>
  <a href="https://bom48.com/store/">situs slot ovo</a>
  <a href="https://bom48.com/store/">bocoran togel hk deposit pulsa</a>
  <a href="https://bom48.com/store/">prediksi japan hari ini</a>
  <a href="https://bom48.com/store/">april judi slot</a>
  <a href="https://bom48.com/store/">poker588 maxwin</a>
  <a href="https://bom48.com/store/">terbaik slot pulsa anti lag</a>
  <a href="https://bom48.com/store/">terbaik slot deposit tanpa potongan</a>
  <a href="https://bom48.com/store/">nomor slot resmi</a>
  <a href="https://bom48.com/store/">maxwin888 gacor</a>
  <a href="https://bom48.com/store/">togel sgp 2024</a>
  <a href="https://bom48.com/store/">cara dapat scatter</a>
  <a href="https://bom48.com/store/">nomor slot online terbaru</a>
  <a href="https://bom48.com/store/">money train</a>
  <a href="https://bom48.com/store/">betting pemula</a>
  <a href="https://bom48.com/store/">keluaran slot gopay anti rungkad</a>
  <a href="https://bom48.com/store/">streaming judi online terpercaya</a>
  <a href="https://bom48.com/store/">rating pasang togel</a>
  <a href="https://bom48.com/store/">daftar slot resmi sore ini</a>
  <a href="https://bom48.com/store/">resmi togel sgp indonesia</a>
  <a href="https://bom48.com/store/">deposit bandar togel</a>
  <a href="https://bom48.com/store/">tips judi togel paling gacor</a>
  <a href="https://bom48.com/store/">link agen sbobet indonesia</a>
  <a href="https://bom48.com/store/">gacor slot88</a>
  <a href="https://bom48.com/store/">terpercaya togel sgp terpercaya</a>
  <a href="https://bom48.com/store/">agen poker server luar</a>
  <a href="https://bom48.com/store/">maxwin66 terpercaya</a>
  <a href="https://bom48.com/store/">taruhan terbukti bayar</a>
  <a href="https://bom48.com/store/">pola agen sbobet no 1</a>
  <a href="https://bom48.com/store/">pola togel online gacor</a>
  <a href="https://bom48.com/store/">link result togel 2026</a>
  <a href="https://bom48.com/store/">hasil togel online tanpa modal</a>
  <a href="https://bom48.com/store/">slot terpercaya gates of gatot kaca 1000</a>
  <a href="https://bom48.com/store/">live slot88 2025</a>
  <a href="https://bom48.com/store/">pengeluaran taruhan paling gacor</a>
  <a href="https://bom48.com/store/">prediksi casino tanpa modal</a>
  <a href="https://bom48.com/store/">resmi sbobet88 2024</a>
  <a href="https://bom48.com/store/">galaxy babies demo slot</a>
  <a href="https://bom48.com/store/">keluaran prediksi togel mudah menang</a>
  <a href="https://bom48.com/store/">slot via bitcoin</a>
  <a href="https://bom48.com/store/">agen slot gacor malam ini</a>
  <a href="https://bom48.com/store/">erek erek kucing 3d</a>
  <a href="https://bom48.com/store/">agen casino server thailand</a>
  <a href="https://bom48.com/store/">raja99 togel</a>
  <a href="https://bom48.com/store/">cara slot gacor maxwin</a>
  <a href="https://bom48.com/store/">zeus vs hades 2026</a>
  <a href="https://bom48.com/store/">profit togel online</a>
  <a href="https://bom48.com/store/">situs agen sbobet deposit pulsa</a>
  <a href="https://bom48.com/store/">daftar slot gopay terpercaya</a>
  <a href="https://bom48.com/store/">terpercaya judi online terbaik</a>
  <a href="https://bom48.com/store/">nomor slot deposit hari ini</a>
  <a href="https://bom48.com/store/">jp788 maxwin</a>
  <a href="https://bom48.com/store/">slot aztec gems 2026</a>
  <a href="https://bom48.com/store/">bandar slot dana tergacor</a>
  <a href="https://bom48.com/store/">cara menang treasure chest</a>
  <a href="https://bom48.com/store/">togel singapore</a>
  <a href="https://bom48.com/store/">info slot thailand indonesia</a>
  <a href="https://bom48.com/store/">slot gampang menang pragmatic</a>
  <a href="https://bom48.com/store/">trik sbobet88 gacor</a>
  <a href="https://bom48.com/store/">pengeluaran togel hari ini resmi</a>
  <a href="https://bom48.com/store/">bandar togel hari ini gacor</a>
  <a href="https://bom48.com/store/">platform slot terpercaya hari ini 2026</a>
  <a href="https://bom48.com/store/">pola slot88 terpercaya</a>
  <a href="https://bom48.com/store/">tips judi bola 2025</a>
  <a href="https://bom48.com/store/">idn poker akun demo</a>
  <a href="https://bom48.com/store/">deposit usdt togel</a>
  <a href="https://bom48.com/store/">agen slot maxwin pagi ini</a>
  <a href="https://bom48.com/store/">hasil live casino 2026</a>
  <a href="https://bom48.com/store/">keluaran bandar togel gacor</a>
  <a href="https://bom48.com/store/">link judi anti lag</a>
  <a href="https://bom48.com/store/">update judi online</a>
  <a href="https://bom48.com/store/">pasang togel anti lag</a>
  <a href="https://bom48.com/store/">hasil togel indonesia</a>
  <a href="https://bom48.com/store/">agen judi online no 1</a>
  <a href="https://bom48.com/store/">terbaik poker tergacor</a>
  <a href="https://bom48.com/store/">demo slot big bass bonanza</a>
  <a href="https://bom48.com/store/">prediksi judi online gacor</a>
  <a href="https://bom48.com/store/">trik slot online deposit pulsa</a>
  <a href="https://bom48.com/store/">link togel sgp tanpa potongan</a>
  <a href="https://bom48.com/store/">nomor togel online deposit pulsa</a>
  <a href="https://bom48.com/store/">pola taruhan deposit gopay</a>
  <a href="https://bom48.com/store/">link daftar poker online</a>
  <a href="https://bom48.com/store/">bocoran sbobet login tanpa potongan</a>
  <a href="https://bom48.com/store/">terpercaya judi slot resmi</a>
  <a href="https://bom48.com/store/">streaming sbobet365 deposit gopay</a>
  <a href="https://bom48.com/store/">baru idn poker</a>
  <a href="https://bom48.com/store/">cara sbobet88 tanpa modal</a>
  <a href="https://bom48.com/store/">prediksi togel 2026</a>
  <a href="https://bom48.com/store/">agen slot terpercaya pagi ini</a>
  <a href="https://bom48.com/store/">data prediksi togel terpercaya</a>
  <a href="https://bom48.com/store/">agen casino browser langsung</a>
  <a href="https://bom48.com/store/">link gacor2d</a>
  <a href="https://bom48.com/store/">data judi togel maxwin</a>
  <a href="https://bom48.com/store/">resmi slot anti rungkad</a>
  <a href="https://bom48.com/store/">togel online mudah jp</a>
  <a href="https://bom48.com/store/">ter sbobet</a>
  <a href="https://bom48.com/store/">bocoran slot maxwin resmi</a>
  <a href="https://bom48.com/store/">terpercaya judi togel tergacor</a>
  <a href="https://bom48.com/store/">daftar judi togel maxwin</a>
  <a href="https://bom48.com/store/">situs slot dana maxwin</a>
  <a href="https://bom48.com/store/">bet99 terpercaya</a>
  <a href="https://bom48.com/store/">bandar taruhan terbaik</a>
  <a href="https://bom48.com/store/">angka slot gopay deposit dana</a>
  <a href="https://bom48.com/store/">slot gacor bonus cashback</a>
  <a href="https://bom48.com/store/">bandar poker demo gratis</a>
  <a href="https://bom48.com/store/">demo slot battleship strike gratis</a>
  <a href="https://bom48.com/store/">betting bola anti lag</a>
  <a href="https://bom48.com/store/">situs sbobet738</a>
  <a href="https://bom48.com/store/">live slot online terbaru</a>
  <a href="https://bom48.com/store/">angka sbobet mobile terpercaya</a>
  <a href="https://bom48.com/store/">training camp maxwin</a>
  <a href="https://bom48.com/store/">angka togel hk nomor 1</a>
  <a href="https://bom48.com/store/">fa cai shen</a>
  <a href="https://bom48.com/store/">dog house multihold terbaru</a>
  <a href="https://bom48.com/store/">slot avatarux deposit 10 ribu</a>
  <a href="https://bom48.com/store/">login pasang togel</a>
  <a href="https://bom48.com/store/">agen sbobet deposit 1rb</a>
  <a href="https://bom48.com/store/">terpercaya sbobet88 gacor</a>
  <a href="https://bom48.com/store/">bandar betting mudah menang</a>
  <a href="https://bom48.com/store/">cara main sbobet365</a>
  <a href="https://bom48.com/store/">bonus deposit slot</a>
  <a href="https://bom48.com/store/">login bet66</a>
  <a href="https://bom48.com/store/">data judi slot mudah menang</a>
  <a href="https://bom48.com/store/">togel sgp maxwin</a>
  <a href="https://bom48.com/store/">keluaran poker anti lag</a>
  <a href="https://bom48.com/store/">pengeluaran slot deposit paling gacor</a>
  <a href="https://bom48.com/store/">slot isoftbet maxwin</a>
  <a href="https://bom48.com/store/">tips judi poker 2024</a>
  <a href="https://bom48.com/store/">slot deposit pulsa telkomsel</a>
  <a href="https://bom48.com/store/">daftar slot no 1</a>
  <a href="https://bom48.com/store/">bocoran slot anti rungkad</a>
  <a href="https://bom48.com/store/">slot demo temple tumble</a>
  <a href="https://bom48.com/store/">tips togel4d deposit gopay</a>
  <a href="https://bom48.com/store/">judi tanpa modal</a>
  <a href="https://bom48.com/store/">slot maxwin deposit 10 ribu</a>
  <a href="https://bom48.com/store/">prediksi slot maxwin tergacor</a>
  <a href="https://bom48.com/store/">praktis sbobet88</a>
  <a href="https://bom48.com/store/">togel online respon cepat</a>
  <a href="https://bom48.com/store/">modal kecil pasang togel</a>
  <a href="https://bom48.com/store/">login sbobet88 mudah menang</a>
  <a href="https://bom48.com/store/">situs sbobet99</a>
  <a href="https://bom48.com/store/">link sbobet terlengkap</a>
  <a href="https://bom48.com/store/">situs result togel tanpa modal</a>
  <a href="https://bom48.com/store/">login sbobet88 paling gacor</a>
  <a href="https://bom48.com/store/">dreamgaming gacor</a>
  <a href="https://bom48.com/store/">agen sbobet berlisensi pagcor</a>
  <a href="https://bom48.com/store/">sbobet88 bonus rollingan</a>
  <a href="https://bom48.com/store/">cara bermain slot</a>
  <a href="https://bom48.com/store/">link jp888</a>
  <a href="https://bom48.com/store/">tips judi bola deposit gopay</a>
  <a href="https://bom48.com/store/">pasang togel respon cepat</a>
  <a href="https://bom48.com/store/">bandar togel hk resmi</a>
  <a href="https://bom48.com/store/">bocoran slot thailand 2026</a>
  <a href="https://bom48.com/store/">nomor live casino maxwin</a>
  <a href="https://bom48.com/store/">info prediksi togel indonesia</a>
  <a href="https://bom48.com/store/">data slot ovo terbaru</a>
  <a href="https://bom48.com/store/">link betting hari ini</a>
  <a href="https://bom48.com/store/">link slot paling gacor malam ini 2026</a>
  <a href="https://bom48.com/store/">live togel4d deposit gopay</a>
  <a href="https://bom48.com/store/">terpercaya slot online mudah menang</a>
  <a href="https://bom48.com/store/">nomor sbobet deposit gopay</a>
  <a href="https://bom48.com/store/">bocoran judi togel online</a>
  <a href="https://bom48.com/store/">taiwan hari ini</a>
  <a href="https://bom48.com/store/">bocoran judi togel tanpa potongan</a>
  <a href="https://bom48.com/store/">nomor casino resmi</a>
  <a href="https://bom48.com/store/">togel999 hari ini</a>
  <a href="https://bom48.com/store/">aman slot thailand</a>
  <a href="https://bom48.com/store/">slot gacor sweet kingdom</a>
  <a href="https://bom48.com/store/">candy bonanza 2026</a>
  <a href="https://bom48.com/store/">poker maxwin</a>
  <a href="https://bom48.com/store/">sbobet77 terpercaya</a>
  <a href="https://bom48.com/store/">trik prediksi togel 2025</a>
  <a href="https://bom48.com/store/">slot terpercaya yggdrasil</a>
  <a href="https://bom48.com/store/">rtp starlight princess 1000</a>
  <a href="https://bom48.com/store/">akun slot terpercaya terbaru hari ini</a>
  <a href="https://bom48.com/store/">slot playtech terbaru</a>
  <a href="https://bom48.com/store/">demo slot tada gaming gacor</a>
  <a href="https://bom48.com/store/">tips result togel anti rungkad</a>
  <a href="https://bom48.com/store/">daftar bandar togel</a>
  <a href="https://bom48.com/store/">trik betting terlengkap</a>
  <a href="https://bom48.com/store/">bandar casino online online</a>
  <a href="https://bom48.com/store/">resmi sbobet login terpercaya</a>
  <a href="https://bom48.com/store/">cara poker indonesia</a>
  <a href="https://bom48.com/store/">nomor sbobet mobile anti lag</a>
  <a href="https://bom48.com/store/">big bass splash 1000 2026</a>
  <a href="https://bom48.com/store/">bandar judi togel gacor</a>
  <a href="https://bom48.com/store/">terpercaya judi poker tanpa potongan</a>
  <a href="https://bom48.com/store/">cara menang slot deposit</a>
  <a href="https://bom48.com/store/">slot gates of olympus 2500 deposit dana</a>
  <a href="https://bom48.com/store/">slot playtech gacor malam ini</a>
  <a href="https://bom48.com/store/">panduan agen sbobet</a>
  <a href="https://bom48.com/store/">slot games global gampang menang</a>
  <a href="https://bom48.com/store/">data togel online paling gacor</a>
  <a href="https://bom48.com/store/">slot wazdan deposit qris</a>
  <a href="https://bom48.com/store/">hasil slot dana hari ini</a>
  <a href="https://bom48.com/store/">agen slot online 2026</a>
  <a href="https://bom48.com/store/">bocoran slot thailand 2025</a>
  <a href="https://bom48.com/store/">pola sbobet gacor</a>
  <a href="https://bom48.com/store/">casino indonesia 2026</a>
  <a href="https://bom48.com/store/">situs slot deposit qris tercepat</a>
  <a href="https://bom48.com/store/">agen bandar togel mudah menang</a>
  <a href="https://bom48.com/store/">angka slot deposit indonesia</a>
  <a href="https://bom48.com/store/">casino indonesia scatter hitam</a>
  <a href="https://bom48.com/store/">tips judi online terlengkap</a>
  <a href="https://bom48.com/store/">pengeluaran slot gacor hari ini</a>
  <a href="https://bom48.com/store/">erek erek kambing 2d</a>
  <a href="https://bom48.com/store/">akun pro</a>
  <a href="https://bom48.com/store/">togel55 gacor</a>
  <a href="https://bom48.com/store/">slot fortune garuda 500 gacor hari ini</a>
  <a href="https://bom48.com/store/">sbobet login jackpot besar</a>
  <a href="https://bom48.com/store/">data judi slot nomor 1</a>
  <a href="https://bom48.com/store/">versi terbaru agen casino</a>
  <a href="https://bom48.com/store/">gates of gatot kaca gacor hari ini</a>
  <a href="https://bom48.com/store/">slot candy bonanza 2026</a>
  <a href="https://bom48.com/store/">streaming slot terbaik</a>
  <a href="https://bom48.com/store/">slot maxwin 2026</a>
  <a href="https://bom48.com/store/">nomor 1 domino qq</a>
  <a href="https://bom48.com/store/">keluaran slot thailand tanpa modal</a>
  <a href="https://bom48.com/store/">nomor bandar togel online</a>
  <a href="https://bom48.com/store/">angka live casino deposit pulsa</a>
  <a href="https://bom48.com/store/">agen sbobet 24 jam</a>
  <a href="https://bom48.com/store/">info slot gopay terpercaya</a>
  <a href="https://bom48.com/store/">sbobet365 24 jam</a>
  <a href="https://bom48.com/store/">slot online deposit pulsa 10rb</a>
  <a href="https://bom48.com/store/">agen togel hari ini deposit gopay</a>
  <a href="https://bom48.com/store/">tips togel sgp terlengkap</a>
  <a href="https://bom48.com/store/">sbobet login rtp tinggi</a>
  <a href="https://bom48.com/store/">bocoran sbobet deposit gopay</a>
  <a href="https://bom48.com/store/">situs sbobet365 terpercaya</a>
  <a href="https://bom48.com/store/">data live casino hari ini</a>
  <a href="https://bom48.com/store/">pengeluaran togel sgp anti lag</a>
  <a href="https://bom48.com/store/">togel3000 maxwin</a>
  <a href="https://bom48.com/store/">rtp slot maxwin 2025</a>
  <a href="https://bom48.com/store/">terbaik result togel gacor</a>
  <a href="https://bom48.com/store/">slot online quickspin</a>
  <a href="https://bom48.com/store/">bocoran taruhan 2026</a>
  <a href="https://bom48.com/store/">tanpa modal slot88</a>
  <a href="https://bom48.com/store/">judi bola respon cepat</a>
  <a href="https://bom48.com/store/">link judi slot 2025</a>
  <a href="https://bom48.com/store/">malam ini domino qq</a>
  <a href="https://bom48.com/store/">pengeluaran slot dana deposit gopay</a>
  <a href="https://bom48.com/store/">betting master</a>
  <a href="https://bom48.com/store/">keluaran togel online tergacor</a>
  <a href="https://bom48.com/store/">bandar togel4d hari ini</a>
  <a href="https://bom48.com/store/">terbaik slot dana gacor</a>
  <a href="https://bom48.com/store/">slot pulsa server luar</a>
  <a href="https://bom48.com/store/">resmi judi togel tanpa modal</a>
  <a href="https://bom48.com/store/">data judi poker gacor</a>
  <a href="https://bom48.com/store/">slot gacor bonanza 1000</a>
  <a href="https://bom48.com/store/">prediksi slot online nomor 1</a>
  <a href="https://bom48.com/store/">resmi slot pulsa terbaru</a>
  <a href="https://bom48.com/store/">bandar taruhan deposit dana</a>
  <a href="https://bom48.com/store/">slot habanero deposit kecil</a>
  <a href="https://bom48.com/store/">prediksi togel hari ini 2025</a>
  <a href="https://bom48.com/store/">cara prediksi togel anti lag</a>
  <a href="https://bom48.com/store/">link slot pulsa 2024</a>
  <a href="https://bom48.com/store/">pola poker maxwin</a>
  <a href="https://bom48.com/store/">angka togel sdy anti lag</a>
  <a href="https://bom48.com/store/">bocoran sweet bonanza xmas</a>
  <a href="https://bom48.com/store/">resmi poker terbaik</a>
  <a href="https://bom48.com/store/">slot dana bonus new member</a>
  <a href="https://bom48.com/store/">prediksi agen sbobet tanpa modal</a>
  <a href="https://bom48.com/store/">pola slot gacor deposit pulsa</a>
  <a href="https://bom48.com/store/">link slot88 paling gacor</a>
  <a href="https://bom48.com/store/">promo slot gacor</a>
  <a href="https://bom48.com/store/">pola betting gacor</a>
  <a href="https://bom48.com/store/">bocoran togel hari ini deposit dana</a>
  <a href="https://bom48.com/store/">agen togel hk nomor 1</a>
  <a href="https://bom48.com/store/">hasil togel sdy online</a>
  <a href="https://bom48.com/store/">agen togel online resmi</a>
  <a href="https://bom48.com/store/">cara result togel hari ini</a>
  <a href="https://bom48.com/store/">maret sbobet mobile</a>
  <a href="https://bom48.com/store/">daftar togel sgp maxwin</a>
  <a href="https://bom48.com/store/">aplikasi slot resmi pagi ini</a>
  <a href="https://bom48.com/store/">togel myanmar</a>
  <a href="https://bom48.com/store/">bocoran judi poker resmi</a>
  <a href="https://bom48.com/store/">sbobet banjir scatter</a>
  <a href="https://bom48.com/store/">pola sbobet mobile 2026</a>
  <a href="https://bom48.com/store/">pengeluaran togel tanpa potongan</a>
  <a href="https://bom48.com/store/">slot evoplay gacor hari ini</a>
  <a href="https://bom48.com/store/">nomor togel sgp</a>
  <a href="https://bom48.com/store/">casino terpercaya hari ini</a>
  <a href="https://bom48.com/store/">terpercaya casino terbaru</a>
  <a href="https://bom48.com/store/">angka togel sgp tergacor</a>
  <a href="https://bom48.com/store/">live sbobet gacor</a>
  <a href="https://bom48.com/store/">pengeluaran sgp</a>
  <a href="https://bom48.com/store/">demo slot push gaming gampang menang</a>
  <a href="https://bom48.com/store/">angka prediksi togel indonesia</a>
  <a href="https://bom48.com/store/">nomor agen sbobet 2026</a>
  <a href="https://bom48.com/store/">link poker4d</a>
  <a href="https://bom48.com/store/">pengeluaran slot online anti lag</a>
  <a href="https://bom48.com/store/">prediksi slot 2026</a>
  <a href="https://bom48.com/store/">judi togel deposit gopay</a>
  <a href="https://bom48.com/store/">slot online pc</a>
  <a href="https://bom48.com/store/">live slot88 tanpa potongan</a>
  <a href="https://bom48.com/store/">streaming togel4d no 1</a>
  <a href="https://bom48.com/store/">keluaran sbobet365 tanpa modal</a>
  <a href="https://bom48.com/store/">slot big bass splash maxwin</a>
  <a href="https://bom48.com/store/">game slot gacor siang ini</a>
  <a href="https://bom48.com/store/">pola slot ovo terbaru</a>
  <a href="https://bom48.com/store/">agen168 slot</a>
  <a href="https://bom48.com/store/">cara menang aztec deluxe</a>
  <a href="https://bom48.com/store/">slot garuda gems deposit pulsa</a>
  <a href="https://bom48.com/store/">slot deposit pulsa indosat tanpa potongan</a>
  <a href="https://bom48.com/store/">bocoran betting resmi</a>
  <a href="https://bom48.com/store/">no 1 judi togel</a>
  <a href="https://bom48.com/store/">prediksi slot gacor terbaik</a>
  <a href="https://bom48.com/store/">mustang gold demo</a>
  <a href="https://bom48.com/store/">pola ceme keliling</a>
  <a href="https://bom48.com/store/">ulasan togel</a>
  <a href="https://bom48.com/store/">terpercaya slot gopay 2025</a>
  <a href="https://bom48.com/store/">judi togel deposit 5rb</a>
  <a href="https://bom48.com/store/">slot server jp</a>
  <a href="https://bom48.com/store/">streaming togel sdy terbaik</a>
  <a href="https://bom48.com/store/">rtp taruhan terlengkap</a>
  <a href="https://bom48.com/store/">info taruhan tanpa modal</a>
  <a href="https://bom48.com/store/">info casino online tanpa potongan</a>
  <a href="https://bom48.com/store/">nomor slot thailand anti rungkad</a>
  <a href="https://bom48.com/store/">live slot gacor deposit gopay</a>
  <a href="https://bom48.com/store/">keluaran slot gacor terbaru</a>
  <a href="https://bom48.com/store/">lucky grace and charm 2026</a>
  <a href="https://bom48.com/store/">prediksi betting no 1</a>
  <a href="https://bom48.com/store/">bocoran gems bonanza</a>
  <a href="https://bom48.com/store/">live judi togel terlengkap</a>
  <a href="https://bom48.com/store/">modal kecil live casino</a>
  <a href="https://bom48.com/store/">casino online modal receh</a>
  <a href="https://bom48.com/store/">trik judi poker nomor 1</a>
  <a href="https://bom48.com/store/">cara bandar togel gacor</a>
  <a href="https://bom48.com/store/">install bandar poker</a>
  <a href="https://bom48.com/store/">slot gacor deposit shopeepay</a>
  <a href="https://bom48.com/store/">streaming togel hari ini tanpa potongan</a>
  <a href="https://bom48.com/store/">login togel hk resmi</a>
  <a href="https://bom48.com/store/">slot4d maxwin</a>
  <a href="https://bom48.com/store/">besok domino qq</a>
  <a href="https://bom48.com/store/">info bandar togel mudah menang</a>
  <a href="https://bom48.com/store/">situs jp638</a>
  <a href="https://bom48.com/store/">situs judi togel 2024</a>
  <a href="https://bom48.com/store/">daftar casino online mudah menang</a>
  <a href="https://bom48.com/store/">login jp788</a>
  <a href="https://bom48.com/store/">slot maxwin bonanza 1000</a>
  <a href="https://bom48.com/store/">bocoran slot gopay terbaru</a>
  <a href="https://bom48.com/store/">prediksi live casino</a>
  <a href="https://bom48.com/store/">prediksi sbobet login gacor</a>
  <a href="https://bom48.com/store/">minggu ini togel</a>
  <a href="https://bom48.com/store/">info slot ovo nomor 1</a>
  <a href="https://bom48.com/store/">slot treasures of aztec deposit qris</a>
  <a href="https://bom48.com/store/">rtp sbobet login terpercaya</a>
  <a href="https://bom48.com/store/">agen slot maxwin tanpa potongan</a>
  <a href="https://bom48.com/store/">situs slot online terbaru</a>
  <a href="https://bom48.com/store/">streaming slot gopay paling gacor</a>
  <a href="https://bom48.com/store/">login slot thailand mudah menang</a>
  <a href="https://bom48.com/store/">pengeluaran judi slot indonesia</a>
  <a href="https://bom48.com/store/">situs slot99</a>
  <a href="https://bom48.com/store/">togel hari ini bonus new member</a>
  <a href="https://bom48.com/store/">jp788 terpercaya</a>
  <a href="https://bom48.com/store/">bandar slot deposit deposit pulsa</a>
  <a href="https://bom48.com/store/">gacor55 hari ini</a>
  <a href="https://bom48.com/store/">pola sbobet mobile online</a>
  <a href="https://bom48.com/store/">agen sultan99</a>
  <a href="https://bom48.com/store/">sbobet login 2026</a>
  <a href="https://bom48.com/store/">angka sbobet365 terbaru</a>
  <a href="https://bom48.com/store/">slot jackpot fishing 2026</a>
  <a href="https://bom48.com/store/">slot gacor deposit pulsa tanpa potongan</a>
  <a href="https://bom48.com/store/">login sbobet login deposit gopay</a>
  <a href="https://bom48.com/store/">pola betting tanpa potongan</a>
  <a href="https://bom48.com/store/">terpercaya live casino maxwin</a>
  <a href="https://bom48.com/store/">free casino</a>
  <a href="https://bom48.com/store/">slot ovo akun pro</a>
  <a href="https://bom48.com/store/">slot terpercaya tada gaming</a>
  <a href="https://bom48.com/store/">sangat agen sbobet</a>
  <a href="https://bom48.com/store/">slot deposit ovo 5k</a>
  <a href="https://bom48.com/store/">gacor sbobet login</a>
  <a href="https://bom48.com/store/">daftar sbobet88 maxwin</a>
  <a href="https://bom48.com/store/">slot 36 coins maxwin</a>
  <a href="https://bom48.com/store/">data judi slot anti rungkad</a>
  <a href="https://bom48.com/store/">trik judi online maxwin</a>
  <a href="https://bom48.com/store/">agen togel4d terlengkap</a>
  <a href="https://bom48.com/store/">rtp slot ovo terbaru</a>
  <a href="https://bom48.com/store/">bandar sbobet deposit dana</a>
  <a href="https://bom48.com/store/">slot demo blueprint</a>
  <a href="https://bom48.com/store/">slot no limit city gampang menang</a>
  <a href="https://bom48.com/store/">login slot dana terbaru</a>
  <a href="https://bom48.com/store/">terpercaya togel hk deposit gopay</a>
  <a href="https://bom48.com/store/">daftar casino no 1</a>
  <a href="https://bom48.com/store/">taruhan 24 jam</a>
  <a href="https://bom48.com/store/">login slot maxwin anti rungkad</a>
  <a href="https://bom48.com/store/">daftar tiger168</a>
  <a href="https://bom48.com/store/">situs slot deposit nomor 1</a>
  <a href="https://bom48.com/store/">cuan slot88</a>
  <a href="https://bom48.com/store/">pola togel online mudah menang</a>
  <a href="https://bom48.com/store/">bocoran slot gopay anti rungkad</a>
  <a href="https://bom48.com/store/">terbaik judi slot online</a>
  <a href="https://bom48.com/store/">sangat casino</a>
  <a href="https://bom48.com/store/">slot maxwin mahjong ways 2</a>
  <a href="https://bom48.com/store/">agen judi slot tergacor</a>
  <a href="https://bom48.com/store/">togel4d jackpot besar</a>
  <a href="https://bom48.com/store/">angka result togel terpercaya</a>
  <a href="https://bom48.com/store/">togel4d bonus new member</a>
  <a href="https://bom48.com/store/">trik slot deposit</a>
  <a href="https://bom48.com/store/">fortune tiger gacor hari ini</a>
  <a href="https://bom48.com/store/">pasang togel server luar</a>
  <a href="https://bom48.com/store/">jumat togel sdy</a>
  <a href="https://bom48.com/store/">agen slot terbaru</a>
  <a href="https://bom48.com/store/">casino588 hari ini</a>
  <a href="https://bom48.com/store/">daftar togel3d</a>
  <a href="https://bom48.com/store/">hasil judi deposit dana</a>
  <a href="https://bom48.com/store/">terbaik togel4d terbaru</a>
  <a href="https://bom48.com/store/">keluaran judi bola 2025</a>
  <a href="https://bom48.com/store/">casino3000 terpercaya</a>
  <a href="https://bom48.com/store/">slot push gaming anti rungkat</a>
  <a href="https://bom48.com/store/">resmi judi slot anti rungkad</a>
  <a href="https://bom48.com/store/">jp438 terpercaya</a>
  <a href="https://bom48.com/store/">bandar slot deposit hari ini</a>
  <a href="https://bom48.com/store/">terbaik judi bola tergacor</a>
  <a href="https://bom48.com/store/">situs agen168</a>
  <a href="https://bom48.com/store/">bandar sbobet365 terbaik</a>
  <a href="https://bom48.com/store/">login jp888</a>
  <a href="https://bom48.com/store/">agen judi poker anti rungkad</a>
  <a href="https://bom48.com/store/">cara casino online tanpa modal</a>
  <a href="https://bom48.com/store/">bandar slot proses cepat malam ini</a>
  <a href="https://bom48.com/store/">togel mobile</a>
  <a href="https://bom48.com/store/">betting bola cs cepat</a>
  <a href="https://bom48.com/store/">terpercaya slot ovo 2025</a>
  <a href="https://bom48.com/store/">bandar poker cs ramah</a>
  <a href="https://bom48.com/store/">situs slot deposit mandiri</a>
  <a href="https://bom48.com/store/">bocoran togel4d terbaru</a>
  <a href="https://bom48.com/store/">keluaran togel4d tergacor</a>
  <a href="https://bom48.com/store/">pola red tiger</a>
  <a href="https://bom48.com/store/">nomor poker tanpa modal</a>
  <a href="https://bom48.com/store/">demo slot wazdan 2026</a>
  <a href="https://bom48.com/store/">pola sbobet88 no 1</a>
  <a href="https://bom48.com/store/">sbobet4d maxwin</a>
  <a href="https://bom48.com/store/">erek erek petir 2d</a>
  <a href="https://bom48.com/store/">login live casino resmi</a>
  <a href="https://bom48.com/store/">angka judi bola tergacor</a>
  <a href="https://bom48.com/store/">data sbobet88 hari ini</a>
  <a href="https://bom48.com/store/">bocoran slot ovo terbaik</a>
  <a href="https://bom48.com/store/">cashback casino indonesia</a>
  <a href="https://bom48.com/store/">cara judi slot 2024</a>
  <a href="https://bom48.com/store/">provider baru slot</a>
  <a href="https://bom48.com/store/">demo slot pragmatic play hari ini 2026</a>
  <a href="https://bom48.com/store/">situs jp22</a>
  <a href="https://bom48.com/store/">agen judi slot terpercaya</a>
  <a href="https://bom48.com/store/">demo pg soft</a>
  <a href="https://bom48.com/store/">agen slot online deposit gopay</a>
  <a href="https://bom48.com/store/">trik taruhan 2026</a>
  <a href="https://bom48.com/store/">terbaik togel sgp maxwin</a>
  <a href="https://bom48.com/store/">angka jitu taiwan</a>
  <a href="https://bom48.com/store/">daftar jp588</a>
  <a href="https://bom48.com/store/">login togel4d no 1</a>
  <a href="https://bom48.com/store/">win777 gacor</a>
  <a href="https://bom48.com/store/">win2000 gacor</a>
  <a href="https://bom48.com/store/">daftar judi poker tanpa potongan</a>
  <a href="https://bom48.com/store/">wild west gold terbaru</a>
  <a href="https://bom48.com/store/">install domino qq</a>
  <a href="https://bom48.com/store/">akun slot terpercaya pagi ini</a>
  <a href="https://bom48.com/store/">hasil slot maxwin deposit dana</a>
  <a href="https://bom48.com/store/">judi online pc</a>
  <a href="https://bom48.com/store/">bocoran rise of giza powerups</a>
  <a href="https://bom48.com/store/">resmi slot ovo tanpa potongan</a>
  <a href="https://bom48.com/store/">rtp judi togel online</a>
  <a href="https://bom48.com/store/">angka togel deposit gopay</a>
  <a href="https://bom48.com/store/">demo slot red tiger modal kecil</a>
  <a href="https://bom48.com/store/">togel777 maxwin</a>
  <a href="https://bom48.com/store/">platform slot paling gacor pagi ini</a>
  <a href="https://bom48.com/store/">info togel no 1</a>
  <a href="https://bom48.com/store/">agen slot minimal deposit kecil hari ini 2026</a>
  <a href="https://bom48.com/store/">live agen sbobet terlengkap</a>
  <a href="https://bom48.com/store/">ceme keliling</a>
  <a href="https://bom48.com/store/">streaming slot</a>
  <a href="https://bom48.com/store/">akun slot mudah menang pagi ini</a>
  <a href="https://bom48.com/store/">hasil slot ovo mudah menang</a>
  <a href="https://bom48.com/store/">login slot deposit maxwin</a>
  <a href="https://bom48.com/store/">link alternatif slot maxwin</a>
  <a href="https://bom48.com/store/">agen poker tanpa aplikasi</a>
  <a href="https://bom48.com/store/">agen sbobet mobile gacor</a>
  <a href="https://bom48.com/store/">slot wd instan</a>
  <a href="https://bom48.com/store/">nomor betting maxwin</a>
  <a href="https://bom48.com/store/">cara slot88 terbaru</a>
  <a href="https://bom48.com/store/">streaming sbobet login indonesia</a>
  <a href="https://bom48.com/store/">pola taruhan no 1</a>
  <a href="https://bom48.com/store/">streaming slot deposit tergacor</a>
  <a href="https://bom48.com/store/">slot fortune rabbit mudah menang</a>
  <a href="https://bom48.com/store/">sangat togel</a>
  <a href="https://bom48.com/store/">bocoran togel online deposit dana</a>
  <a href="https://bom48.com/store/">resmi casino 2026</a>
  <a href="https://bom48.com/store/">pola spaceman</a>
  <a href="https://bom48.com/store/">rtp judi online resmi</a>
  <a href="https://bom48.com/store/">sukses judi poker</a>
  <a href="https://bom48.com/store/">nomor taruhan tanpa potongan</a>
  <a href="https://bom48.com/store/">sbobet login winrate tertinggi</a>
  <a href="https://bom48.com/store/">daftar slot gopay indonesia</a>
  <a href="https://bom48.com/store/">login slot proses cepat siang ini</a>
  <a href="https://bom48.com/store/">prediksi sbobet88 terbaru</a>
  <a href="https://bom48.com/store/">bandar slot gacor pagi ini</a>
  <a href="https://bom48.com/store/">slot gampang menang book of dead</a>
  <a href="https://bom48.com/store/">keluaran pasang togel terpercaya</a>
  <a href="https://bom48.com/store/">cara slot maxwin 2024</a>
  <a href="https://bom48.com/store/">login slot gacor sore ini</a>
  <a href="https://bom48.com/store/">cara sbobet terbaik</a>
  <a href="https://bom48.com/store/">slot hari ini</a>
  <a href="https://bom48.com/store/">main training camp</a>
  <a href="https://bom48.com/store/">streaming prediksi togel paling gacor</a>
  <a href="https://bom48.com/store/">situs judi poker resmi</a>
  <a href="https://bom48.com/store/">win22 terpercaya</a>
  <a href="https://bom48.com/store/">trik slot dana tanpa potongan</a>
  <a href="https://bom48.com/store/">data prediksi togel 2024</a>
  <a href="https://bom48.com/store/">terbaik poker deposit gopay</a>
  <a href="https://bom48.com/store/">who wants to be a millionaire megaways terbaru</a>
  <a href="https://bom48.com/store/">jammin jars 2 2026</a>
  <a href="https://bom48.com/store/">situs poker deposit pulsa</a>
  <a href="https://bom48.com/store/">pasang bola</a>
  <a href="https://bom48.com/store/">resmi slot ovo deposit gopay</a>
  <a href="https://bom48.com/store/">info poker paling gacor</a>
  <a href="https://bom48.com/store/">praktis judi togel</a>
  <a href="https://bom48.com/store/">simpel taruhan</a>
  <a href="https://bom48.com/store/">win44 maxwin</a>
  <a href="https://bom48.com/store/">hasil betting terbaik</a>
  <a href="https://bom48.com/store/">sbobet99 gacor</a>
  <a href="https://bom48.com/store/">resmi betting terbaru</a>
  <a href="https://bom48.com/store/">angka casino terbaik</a>
  <a href="https://bom48.com/store/">agen master88</a>
  <a href="https://bom48.com/store/">weekday bandar togel</a>
  <a href="https://bom48.com/store/">hasil togel hari ini 2024</a>
  <a href="https://bom48.com/store/">apk slot pulsa</a>
  <a href="https://bom48.com/store/">hasil sbobet88 no 1</a>
  <a href="https://bom48.com/store/">rtp big two</a>
  <a href="https://bom48.com/store/">login sbobet365 anti rungkad</a>
  <a href="https://bom48.com/store/">daftar sbobet188</a>
  <a href="https://bom48.com/store/">login betting tanpa modal</a>
  <a href="https://bom48.com/store/">situs judi online paling gacor</a>
  <a href="https://bom48.com/store/">agen sbobet365 online</a>
  <a href="https://bom48.com/store/">cara prediksi togel indonesia</a>
  <a href="https://bom48.com/store/">agen slot terpercaya</a>
  <a href="https://bom48.com/store/">tips togel sgp terbaik</a>
  <a href="https://bom48.com/store/">tutorial sbobet mobile</a>
  <a href="https://bom48.com/store/">demo slot habanero mudah menang</a>
  <a href="https://bom48.com/store/">rtp sexy baccarat</a>
  <a href="https://bom48.com/store/">sbobet mobile nomor 1</a>
  <a href="https://bom48.com/store/">prediksi sbobet maxwin</a>
  <a href="https://bom48.com/store/">bet44 gacor</a>
  <a href="https://bom48.com/store/">hasil bandar togel online</a>
  <a href="https://bom48.com/store/">hasil togel 2025</a>
  <a href="https://bom48.com/store/">live togel sgp tanpa potongan</a>
  <a href="https://bom48.com/store/">agen judi bola paling gacor</a>
  <a href="https://bom48.com/store/">angka togel sgp</a>
  <a href="https://bom48.com/store/">aplikasi slot anti lag hari ini 2026</a>
  <a href="https://bom48.com/store/">terbaik togel sgp mudah menang</a>
  <a href="https://bom48.com/store/">bonus agen sbobet</a>
  <a href="https://bom48.com/store/">data judi online tergacor</a>
  <a href="https://bom48.com/store/">pengeluaran poker terbaik</a>
  <a href="https://bom48.com/store/">keluaran slot ovo nomor 1</a>
  <a href="https://bom48.com/store/">game ezugi</a>
  <a href="https://bom48.com/store/">angka togel sgp terpercaya</a>
  <a href="https://bom48.com/store/">slot gopay tanpa potongan</a>
  <a href="https://bom48.com/store/">slot pg soft 2026</a>
  <a href="https://bom48.com/store/">daftar sbobet365 tergacor</a>
  <a href="https://bom48.com/store/">aplikasi slot anti rungkat malam ini 2026</a>
  <a href="https://bom48.com/store/">daftar togel sgp paling gacor</a>
  <a href="https://bom48.com/store/">januari slot dana</a>
  <a href="https://bom48.com/store/">game slot proses cepat malam ini</a>
  <a href="https://bom48.com/store/">login casino hari ini</a>
  <a href="https://bom48.com/store/">cara judi togel hari ini</a>
  <a href="https://bom48.com/store/">trik slot gopay anti rungkad</a>
  <a href="https://bom48.com/store/">terpercaya slot maxwin deposit gopay</a>
  <a href="https://bom48.com/store/">streaming taruhan gacor</a>
  <a href="https://bom48.com/store/">pola ocean king</a>
  <a href="https://bom48.com/store/">sbobet88 wd 3 menit</a>
  <a href="https://bom48.com/store/">casino438 gacor</a>
  <a href="https://bom48.com/store/">trik slot ovo anti lag</a>
  <a href="https://bom48.com/store/">slot terpercaya fortune ox</a>
  <a href="https://bom48.com/store/">info pasang togel 2025</a>
  <a href="https://bom48.com/store/">rating togel online</a>
  <a href="https://bom48.com/store/">daftar slot online deposit dana</a>
  <a href="https://bom48.com/store/">casino indonesia terpercaya</a>
  <a href="https://bom48.com/store/">login play168</a>
  <a href="https://bom48.com/store/">demo slot crash game</a>
  <a href="https://bom48.com/store/">hasil togel sdy deposit gopay</a>
  <a href="https://bom48.com/store/">resmi judi bola deposit dana</a>
  <a href="https://bom48.com/store/">agen betting bola</a>
  <a href="https://bom48.com/store/">live agen sbobet maxwin</a>
  <a href="https://bom48.com/store/">keluaran judi bola 2024</a>
  <a href="https://bom48.com/store/">berapa jackpot togel</a>
  <a href="https://bom48.com/store/">slot pinata wins 2026</a>
  <a href="https://bom48.com/store/">terbaik judi online terbaik</a>
  <a href="https://bom48.com/store/">rtp togel hari ini maxwin</a>
  <a href="https://bom48.com/store/">trik slot terbaru</a>
  <a href="https://bom48.com/store/">bocoran agen sbobet tanpa potongan</a>
  <a href="https://bom48.com/store/">resmi slot dana indonesia</a>
  <a href="https://bom48.com/store/">jackpot judi</a>
  <a href="https://bom48.com/store/">download slot gacor</a>
  <a href="https://bom48.com/store/">keluaran slot ovo 2024</a>
  <a href="https://bom48.com/store/">situs slot ovo deposit pulsa</a>
  <a href="https://bom48.com/store/">prediksi slot maxwin terlengkap</a>
  <a href="https://bom48.com/store/">sweet bonanza demo</a>
  <a href="https://bom48.com/store/">data togel sdy mudah menang</a>
  <a href="https://bom48.com/store/">book of fallen gacor</a>
  <a href="https://bom48.com/store/">slot deposit tanpa aplikasi</a>
  <a href="https://bom48.com/store/">daftar pasang togel terbaik</a>
  <a href="https://bom48.com/store/">jackpot poker online</a>
  <a href="https://bom48.com/store/">pola slot online</a>
  <a href="https://bom48.com/store/">rtp betting no 1</a>
  <a href="https://bom48.com/store/">trik slot gacor deposit gopay</a>
  <a href="https://bom48.com/store/">cara togel sdy mudah menang</a>
  <a href="https://bom48.com/store/">link togel438</a>
  <a href="https://bom48.com/store/">hasil togel terbaru</a>
  <a href="https://bom48.com/store/">slot deposit ovo</a>
  <a href="https://bom48.com/store/">gratis idn poker</a>
  <a href="https://bom48.com/store/">live casino terbaru</a>
  <a href="https://bom48.com/store/">cara menang gates of olympus 1000</a>
  <a href="https://bom48.com/store/">pola judi togel</a>
  <a href="https://bom48.com/store/">super168 togel</a>
  <a href="https://bom48.com/store/">streaming agen sbobet online</a>
  <a href="https://bom48.com/store/">slot rooster rumble maxwin</a>
  <a href="https://bom48.com/store/">bandar togel deposit dana</a>
  <a href="https://bom48.com/store/">pengeluaran sbobet mudah menang</a>
  <a href="https://bom48.com/store/">prediksi slot gacor 2025</a>
  <a href="https://bom48.com/store/">tips casino online terbaru</a>
  <a href="https://bom48.com/store/">terbaik judi online online</a>
  <a href="https://bom48.com/store/">cara menang alice in wonderland</a>
  <a href="https://bom48.com/store/">slot online akun pro</a>
  <a href="https://bom48.com/store/">terbaik slot ovo nomor 1</a>
  <a href="https://bom48.com/store/">pengeluaran taruhan resmi</a>
  <a href="https://bom48.com/store/">gacor638 gacor</a>
  <a href="https://bom48.com/store/">keluaran slot maxwin terpercaya</a>
  <a href="https://bom48.com/store/">terpercaya prediksi togel anti rungkad</a>
  <a href="https://bom48.com/store/">gates of gatot kaca slot</a>
  <a href="https://bom48.com/store/">keluaran slot gacor paling gacor</a>
  <a href="https://bom48.com/store/">info sbobet88 deposit pulsa</a>
  <a href="https://bom48.com/store/">slot gates of olympus super scatter rtp tinggi</a>
  <a href="https://bom48.com/store/">slot gacor forbidden alchemy</a>
  <a href="https://bom48.com/store/">terpercaya sbobet88 terbaru</a>
  <a href="https://bom48.com/store/">tips result togel tanpa modal</a>
  <a href="https://bom48.com/store/">tips buffalo king</a>
  <a href="https://bom48.com/store/">cara menang gonzos quest</a>
  <a href="https://bom48.com/store/">link sbobet88 deposit gopay</a>
  <a href="https://bom48.com/store/">login judi bola tergacor</a>
  <a href="https://bom48.com/store/">pengeluaran togel4d gacor</a>
  <a href="https://bom48.com/store/">trik togel sgp tanpa potongan</a>
  <a href="https://bom48.com/store/">nomor agen sbobet nomor 1</a>
  <a href="https://bom48.com/store/">resmi sbobet88 anti lag</a>
  <a href="https://bom48.com/store/">terpercaya slot pulsa hari ini</a>
  <a href="https://bom48.com/store/">info slot gacor</a>
  <a href="https://bom48.com/store/">tips slot thailand online</a>
  <a href="https://bom48.com/store/">slot play n go mudah menang</a>
  <a href="https://bom48.com/store/">keluaran slot anti rungkad</a>
  <a href="https://bom48.com/store/">rtp taruhan anti lag</a>
  <a href="https://bom48.com/store/">pengeluaran agen sbobet gacor</a>
  <a href="https://bom48.com/store/">prediksi togel hari ini indonesia</a>
  <a href="https://bom48.com/store/">untung togel sgp</a>
  <a href="https://bom48.com/store/">betting selalu buka</a>
  <a href="https://bom48.com/store/">modal kecil slot deposit</a>
  <a href="https://bom48.com/store/">agen slot gacor maxwin</a>
  <a href="https://bom48.com/store/">king88 slot</a>
  <a href="https://bom48.com/store/">slot money train 2 deposit dana</a>
  <a href="https://bom48.com/store/">keluaran sbobet mobile anti lag</a>
  <a href="https://bom48.com/store/">bocoran judi terbaru</a>
  <a href="https://bom48.com/store/">trik slot maxwin tergacor</a>
  <a href="https://bom48.com/store/">demo slot cluster pays</a>
  <a href="https://bom48.com/store/">data togel sdy nomor 1</a>
  <a href="https://bom48.com/store/">rtp slot pulsa tanpa potongan</a>
  <a href="https://bom48.com/store/">trik togel sdy gacor</a>
  <a href="https://bom48.com/store/">slot deposit 5000 resmi</a>
  <a href="https://bom48.com/store/">nomor togel sdy anti rungkad</a>
  <a href="https://bom48.com/store/">bocoran slot thailand terbaik</a>
  <a href="https://bom48.com/store/">pengeluaran togel hk terbaik</a>
  <a href="https://bom48.com/store/">jp538 hari ini</a>
  <a href="https://bom48.com/store/">rtp hot to burn</a>
  <a href="https://bom48.com/store/">resmi slot dana nomor 1</a>
  <a href="https://bom48.com/store/">slot gacor 36 coins</a>
  <a href="https://bom48.com/store/">nomor sbobet mobile maxwin</a>
  <a href="https://bom48.com/store/">bocoran casino online terpercaya</a>
  <a href="https://bom48.com/store/">nomor judi slot 2026</a>
  <a href="https://bom48.com/store/">gratis slot online</a>
  <a href="https://bom48.com/store/">terbaik togel hari ini paling gacor</a>
  <a href="https://bom48.com/store/">angka judi togel anti rungkad</a>
  <a href="https://bom48.com/store/">angka slot gopay tanpa modal</a>
  <a href="https://bom48.com/store/">akun slot mudah menang terbaru hari ini</a>
  <a href="https://bom48.com/store/">prediksi sbobet365 resmi</a>
  <a href="https://bom48.com/store/">live judi slot anti lag</a>
  <a href="https://bom48.com/store/">streaming taruhan deposit dana</a>
  <a href="https://bom48.com/store/">login togel sdy hari ini</a>
  <a href="https://bom48.com/store/">cuan sbobet88</a>
  <a href="https://bom48.com/store/">situs spin88</a>
  <a href="https://bom48.com/store/">pola slot dana deposit gopay</a>
  <a href="https://bom48.com/store/">casino123 maxwin</a>
  <a href="https://bom48.com/store/">terpercaya sbobet terbaik</a>
  <a href="https://bom48.com/store/">rtp casino online terbaik</a>
  <a href="https://bom48.com/store/">trik prediksi togel resmi</a>
  <a href="https://bom48.com/store/">data prediksi togel tergacor</a>
  <a href="https://bom48.com/store/">login win2d</a>
  <a href="https://bom48.com/store/">prediksi slot gacor nomor 1</a>
  <a href="https://bom48.com/store/">hasil judi online anti lag</a>
  <a href="https://bom48.com/store/">casino88 maxwin</a>
  <a href="https://bom48.com/store/">togel4d paling gacor</a>
  <a href="https://bom48.com/store/">data china</a>
  <a href="https://bom48.com/store/">judi slot server luar</a>
  <a href="https://bom48.com/store/">besok casino terpercaya</a>
  <a href="https://bom48.com/store/">DEPOSIT 5RB</a>
  <a href="https://bom48.com/store/">slot deposit linkaja maxwin</a>
  <a href="https://bom48.com/store/">resmi judi bola 2026</a>
  <a href="https://bom48.com/store/">rtp live casino gacor</a>
  <a href="https://bom48.com/store/">tips dog house multihold</a>
  <a href="https://bom48.com/store/">angka slot dana indonesia</a>
  <a href="https://bom48.com/store/">angka togel hk no 1</a>
  <a href="https://bom48.com/store/">slot mahjong wins 3 2026</a>
  <a href="https://bom48.com/store/">agen super168</a>
  <a href="https://bom48.com/store/">judi poker terpercaya</a>
  <a href="https://bom48.com/store/">streaming togel sdy paling gacor</a>
  <a href="https://bom48.com/store/">live casino winrate tertinggi</a>
  <a href="https://bom48.com/store/">link judi poker 2026</a>
  <a href="https://bom48.com/store/">poker online 24 jam</a>
  <a href="https://bom48.com/store/">agen togel deposit dana</a>
  <a href="https://bom48.com/store/">trik slot dana maxwin</a>
  <a href="https://bom48.com/store/">idn poker free spin</a>
  <a href="https://bom48.com/store/">data togel sdy paling gacor</a>
  <a href="https://bom48.com/store/">live togel online online</a>
  <a href="https://bom48.com/store/">data judi 2026</a>
  <a href="https://bom48.com/store/">keluaran judi togel hari ini</a>
  <a href="https://bom48.com/store/">tips slot ovo tanpa potongan</a>
  <a href="https://bom48.com/store/">apk agen poker</a>
  <a href="https://bom48.com/store/">omaha poker terbaru</a>
  <a href="https://bom48.com/store/">wild bandito demo</a>
  <a href="https://bom48.com/store/">rtp judi terpercaya</a>
  <a href="https://bom48.com/store/">casino gampang menang</a>
  <a href="https://bom48.com/store/">terbaik slot pulsa 2026</a>
  <a href="https://bom48.com/store/">bandar slot88 2026</a>
  <a href="https://bom48.com/store/">data judi online 2024</a>
  <a href="https://bom48.com/store/">judi aman terpercaya</a>
  <a href="https://bom48.com/store/">bandar taruhan deposit gopay</a>
  <a href="https://bom48.com/store/">login togel hk paling gacor</a>
  <a href="https://bom48.com/store/">link sbobet mudah menang</a>
  <a href="https://bom48.com/store/">terpercaya togel hk terbaru</a>
  <a href="https://bom48.com/store/">slot book of dead gacor hari ini</a>
  <a href="https://bom48.com/store/">slot terpercaya microgaming</a>
  <a href="https://bom48.com/store/">cara togel hari ini paling gacor</a>
  <a href="https://bom48.com/store/">slot deposit pulsa 5k gampang menang</a>
  <a href="https://bom48.com/store/">link slot ovo no 1</a>
  <a href="https://bom48.com/store/">login result togel no 1</a>
  <a href="https://bom48.com/store/">rabu poker</a>
  <a href="https://bom48.com/store/">bocoran result togel tanpa potongan</a>
  <a href="https://bom48.com/store/">cuan togel sdy</a>
  <a href="https://bom48.com/store/">mega99 maxwin</a>
  <a href="https://bom48.com/store/">bocoran alice in wonderland</a>
  <a href="https://bom48.com/store/">daftar slot online resmi</a>
  <a href="https://bom48.com/store/">link judi poker terbaik</a>
  <a href="https://bom48.com/store/">info sbobet365 2025</a>
  <a href="https://bom48.com/store/">bocoran togel4d tanpa potongan</a>
  <a href="https://bom48.com/store/">trik sbobet login</a>
  <a href="https://bom48.com/store/">bocoran mahjong wins</a>
  <a href="https://bom48.com/store/">rtp togel anti rungkad</a>
  <a href="https://bom48.com/store/">cara judi togel terpercaya</a>
  <a href="https://bom48.com/store/">prediksi togel4d tanpa modal</a>
  <a href="https://bom48.com/store/">daftar mega168</a>
  <a href="https://bom48.com/store/">bocoran judi togel</a>
  <a href="https://bom48.com/store/">pola togel tanpa potongan</a>
  <a href="https://bom48.com/store/">gacor999 hari ini</a>
  <a href="https://bom48.com/store/">slot online deposit qris tercepat</a>
  <a href="https://bom48.com/store/">terbaik sbobet login terlengkap</a>
  <a href="https://bom48.com/store/">candy village terbaru</a>
  <a href="https://bom48.com/store/">bet188 maxwin</a>
  <a href="https://bom48.com/store/">togel hk hari ini</a>
  <a href="https://bom48.com/store/">togel sdy aman terpercaya</a>
  <a href="https://bom48.com/store/">slot gates of olympus super scatter 2026</a>
  <a href="https://bom48.com/store/">trik judi poker deposit gopay</a>
  <a href="https://bom48.com/store/">demo slot the dog house megaways</a>
  <a href="https://bom48.com/store/">tips sbobet 2025</a>
  <a href="https://bom48.com/store/">kamis pasang togel</a>
  <a href="https://bom48.com/store/">bocoran live casino</a>
  <a href="https://bom48.com/store/">tips togel online terlengkap</a>
  <a href="https://bom48.com/store/">resmi sbobet online</a>
  <a href="https://bom48.com/store/">info togel terbaik</a>
  <a href="https://bom48.com/store/">rtp prediksi togel paling gacor</a>
  <a href="https://bom48.com/store/">data togel online tanpa potongan</a>
  <a href="https://bom48.com/store/">trik casino online deposit gopay</a>
  <a href="https://bom48.com/store/">login judi poker indonesia</a>
  <a href="https://bom48.com/store/">malam ini judi online</a>
  <a href="https://bom48.com/store/">prediksi togel hk terbaru</a>
  <a href="https://bom48.com/store/">bulan ini result togel</a>
  <a href="https://bom48.com/store/">slot terpercaya spadegaming</a>
  <a href="https://bom48.com/store/">nomor live casino gacor</a>
  <a href="https://bom48.com/store/">demo slot tada gaming modal kecil</a>
  <a href="https://bom48.com/store/">togel4d maxwin</a>
  <a href="https://bom48.com/store/">data judi poker resmi</a>
  <a href="https://bom48.com/store/">pola sbobet indonesia</a>
  <a href="https://bom48.com/store/">gacor44 hari ini</a>
  <a href="https://bom48.com/store/">bulan ini betting</a>
  <a href="https://bom48.com/store/">togel sdy profesional</a>
  <a href="https://bom48.com/store/">untung slot thailand</a>
  <a href="https://bom48.com/store/">daftar judi bola indonesia</a>
  <a href="https://bom48.com/store/">aplikasi slot withdraw cepat pagi ini</a>
  <a href="https://bom48.com/store/">demo slot isoftbet gacor malam ini</a>
  <a href="https://bom48.com/store/">trik slot deposit indonesia</a>
  <a href="https://bom48.com/store/">info slot deposit terbaru</a>
  <a href="https://bom48.com/store/">anti ribet sbobet login</a>
  <a href="https://bom48.com/store/">streaming result togel resmi</a>
  <a href="https://bom48.com/store/">live slot thailand nomor 1</a>
  <a href="https://bom48.com/store/">april slot pulsa</a>
  <a href="https://bom48.com/store/">fresh togel online</a>
  <a href="https://bom48.com/store/">keluaran togel sgp deposit pulsa</a>
  <a href="https://bom48.com/store/">trik togel hk mudah menang</a>
  <a href="https://bom48.com/store/">slot joker gaming gacor hari ini</a>
  <a href="https://bom48.com/store/">bandar slot88 deposit dana</a>
  <a href="https://bom48.com/store/">keluaran togel online hari ini</a>
  <a href="https://bom48.com/store/">live slot gopay no 1</a>
  <a href="https://bom48.com/store/">togel hk profesional</a>
  <a href="https://bom48.com/store/">judi online 24 jam</a>
  <a href="https://bom48.com/store/">agen slot paling gacor malam ini</a>
  <a href="https://bom48.com/store/">bandar sbobet88 no 1</a>
  <a href="https://bom48.com/store/">data bandar poker</a>
  <a href="https://bom48.com/store/">data live casino tergacor</a>
  <a href="https://bom48.com/store/">situs sbobet44</a>
  <a href="https://bom48.com/store/">referral judi poker</a>
  <a href="https://bom48.com/store/">game slot terbaru malam ini 2026</a>
  <a href="https://bom48.com/store/">bandar togel sgp online</a>
  <a href="https://bom48.com/store/">terpercaya slot pulsa online</a>
  <a href="https://bom48.com/store/">situs betting no 1</a>
  <a href="https://bom48.com/store/">link slot maxwin deposit gopay</a>
  <a href="https://bom48.com/store/">cara slot dana tanpa potongan</a>
  <a href="https://bom48.com/store/">daftar slot resmi siang ini</a>
  <a href="https://bom48.com/store/">mines game gacor</a>
  <a href="https://bom48.com/store/">tabel macau</a>
  <a href="https://bom48.com/store/">besok slot</a>
  <a href="https://bom48.com/store/">resmi togel sgp anti lag</a>
  <a href="https://bom48.com/store/">tips togel hk deposit gopay</a>
  <a href="https://bom48.com/store/">judi deposit pulsa</a>
  <a href="https://bom48.com/store/">slot sugar rush 2026</a>
  <a href="https://bom48.com/store/">bocoran togel hk resmi</a>
  <a href="https://bom48.com/store/">daftar situs bandar togel</a>
  <a href="https://bom48.com/store/">aplikasi slot anti lag malam ini</a>
  <a href="https://bom48.com/store/">slot demo 12 masks of fire drums</a>
  <a href="https://bom48.com/store/">trik judi togel deposit gopay</a>
  <a href="https://bom48.com/store/">tips togel4d tanpa potongan</a>
  <a href="https://bom48.com/store/">bocoran betting bola</a>
  <a href="https://bom48.com/store/">hasil live casino terpercaya</a>
  <a href="https://bom48.com/store/">streaming togel hk no 1</a>
  <a href="https://bom48.com/store/">pengeluaran result togel indonesia</a>
  <a href="https://bom48.com/store/">slot288 terpercaya</a>
  <a href="https://bom48.com/store/">agen agen sbobet</a>
  <a href="https://bom48.com/store/">streaming togel online terbaik</a>
  <a href="https://bom48.com/store/">dog house multihold gacor</a>
  <a href="https://bom48.com/store/">situs agen sbobet paling gacor</a>
  <a href="https://bom48.com/store/">tips judi slot indonesia</a>
  <a href="https://bom48.com/store/">data sbobet88 deposit gopay</a>
  <a href="https://bom48.com/store/">angka judi online hari ini</a>
  <a href="https://bom48.com/store/">angka togel sgp online</a>
  <a href="https://bom48.com/store/">angka live casino terbaik</a>
  <a href="https://bom48.com/store/">situs slot88 anti rungkad</a>
  <a href="https://bom48.com/store/">result togel banjir scatter</a>
  <a href="https://bom48.com/store/">togel10000 maxwin</a>
  <a href="https://bom48.com/store/">agen slot88 gacor</a>
  <a href="https://bom48.com/store/">pengeluaran togel sgp deposit gopay</a>
  <a href="https://bom48.com/store/">pro168 terpercaya</a>
  <a href="https://bom48.com/store/">keluaran sbobet login anti rungkad</a>
  <a href="https://bom48.com/store/">streaming slot dana tergacor</a>
  <a href="https://bom48.com/store/">agen poker browser langsung</a>
  <a href="https://bom48.com/store/">agen slot paling gacor hari ini 2026</a>
  <a href="https://bom48.com/store/">prediksi slot maxwin deposit dana</a>
  <a href="https://bom48.com/store/">nomor judi poker no 1</a>
  <a href="https://bom48.com/store/">rtp togel online gacor</a>
  <a href="https://bom48.com/store/">terbaik sbobet tanpa modal</a>
  <a href="https://bom48.com/store/">resmi togel anti rungkad</a>
  <a href="https://bom48.com/store/">besok casino online</a>
  <a href="https://bom48.com/store/">bonus judi</a>
  <a href="https://bom48.com/store/">terpercaya sbobet365 maxwin</a>
  <a href="https://bom48.com/store/">februari casino</a>
  <a href="https://bom48.com/store/">bocoran slot deposit 2024</a>
  <a href="https://bom48.com/store/">slot online master</a>
  <a href="https://bom48.com/store/">tips sbobet paling gacor</a>
  <a href="https://bom48.com/store/">pengeluaran togel4d deposit gopay</a>
  <a href="https://bom48.com/store/">data sbobet login terlengkap</a>
  <a href="https://bom48.com/store/">login slot withdraw cepat malam ini</a>
  <a href="https://bom48.com/store/">terpercaya judi poker 2025</a>
  <a href="https://bom48.com/store/">angka slot pulsa terlengkap</a>
  <a href="https://bom48.com/store/">bandar slot 2024</a>
  <a href="https://bom48.com/store/">data casino online paling gacor</a>
  <a href="https://bom48.com/store/">slot bonanza megaways deposit pulsa</a>
  <a href="https://bom48.com/store/">nomor sbobet88 paling gacor</a>
  <a href="https://bom48.com/store/">info sbobet login tergacor</a>
  <a href="https://bom48.com/store/">bocoran 1000x starlight</a>
  <a href="https://bom48.com/store/">rtp slot maxwin tanpa potongan</a>
  <a href="https://bom48.com/store/">agen togel hk paling gacor</a>
  <a href="https://bom48.com/store/">link slot minimal deposit kecil hari ini 2026</a>
  <a href="https://bom48.com/store/">demo slot slotmill gampang menang</a>
  <a href="https://bom48.com/store/">daftar togel438</a>
  <a href="https://bom48.com/store/">streaming sbobet365 terlengkap</a>
  <a href="https://bom48.com/store/">situs sbobet365 deposit pulsa</a>
  <a href="https://bom48.com/store/">link agen sbobet paling gacor</a>
  <a href="https://bom48.com/store/">terbaik togel sgp 2024</a>
  <a href="https://bom48.com/store/">jam gacor aztec gems</a>
  <a href="https://bom48.com/store/">angka slot online mudah menang</a>
  <a href="https://bom48.com/store/">situs casino2000</a>
  <a href="https://bom48.com/store/">rtp togel hk resmi</a>
  <a href="https://bom48.com/store/">angka judi poker 2024</a>
  <a href="https://bom48.com/store/">agen slot deposit tanpa potongan</a>
  <a href="https://bom48.com/store/">data judi gacor</a>
  <a href="https://bom48.com/store/">situs microgaming</a>
  <a href="https://bom48.com/store/">trik sbobet365 2026</a>
  <a href="https://bom48.com/store/">keluaran judi bola terbaru</a>
  <a href="https://bom48.com/store/">slot cq9 anti rungkat</a>
  <a href="https://bom48.com/store/">slot ovo server jp</a>
  <a href="https://bom48.com/store/">simpel sbobet365</a>
  <a href="https://bom48.com/store/">sweet kingdom rtp tinggi</a>
  <a href="https://bom48.com/store/">terpercaya togel sdy deposit pulsa</a>
  <a href="https://bom48.com/store/">praktis slot dana</a>
  <a href="https://bom48.com/store/">demo slot rhythm nights</a>
  <a href="https://bom48.com/store/">rtp betting maxwin</a>
  <a href="https://bom48.com/store/">maxwin99 terpercaya</a>
  <a href="https://bom48.com/store/">untung sbobet88</a>
  <a href="https://bom48.com/store/">weekend slot deposit</a>
  <a href="https://bom48.com/store/">tips live casino 2025</a>
  <a href="https://bom48.com/store/">cara prediksi togel deposit dana</a>
  <a href="https://bom48.com/store/">daftar play168</a>
  <a href="https://bom48.com/store/">info slot dana</a>
  <a href="https://bom48.com/store/">sbobet deposit danamon</a>
  <a href="https://bom48.com/store/">rtp togel sdy hari ini</a>
  <a href="https://bom48.com/store/">slot sugar rush maxwin</a>
  <a href="https://bom48.com/store/">info judi slot online</a>
  <a href="https://bom48.com/store/">resmi judi poker terbaru</a>
  <a href="https://bom48.com/store/">casino online tanpa modal</a>
  <a href="https://bom48.com/store/">terbaik togel sdy gacor</a>
  <a href="https://bom48.com/store/">tips crystal caverns megaways</a>
  <a href="https://bom48.com/store/">angka taruhan paling gacor</a>
  <a href="https://bom48.com/store/">prediksi result togel tanpa modal</a>
  <a href="https://bom48.com/store/">pola judi bola tergacor</a>
  <a href="https://bom48.com/store/">hasil prediksi togel terbaik</a>
  <a href="https://bom48.com/store/">data slot gopay terpercaya</a>
  <a href="https://bom48.com/store/">agen casino deposit 5rb</a>
  <a href="https://bom48.com/store/">info sbobet88</a>
  <a href="https://bom48.com/store/">play88 maxwin</a>
  <a href="https://bom48.com/store/">trik judi slot mudah menang</a>
  <a href="https://bom48.com/store/">keluaran sbobet88 anti rungkad</a>
  <a href="https://bom48.com/store/">bocoran slot paling gacor</a>
  <a href="https://bom48.com/store/">keluaran togel hari ini deposit gopay</a>
  <a href="https://bom48.com/store/">bocoran agen sbobet tergacor</a>
  <a href="https://bom48.com/store/">result togel deposit 5rb</a>
  <a href="https://bom48.com/store/">bocoran slot88 tergacor</a>
  <a href="https://bom48.com/store/">link togel hk deposit dana</a>
  <a href="https://bom48.com/store/">bocoran sbobet88 hari ini</a>
  <a href="https://bom48.com/store/">bocoran slot online online</a>
  <a href="https://bom48.com/store/">agen cq9</a>
  <a href="https://bom48.com/store/">prediksi togel mudah menang</a>
  <a href="https://bom48.com/store/">bocoran judi togel tanpa modal</a>
  <a href="https://bom48.com/store/">prediksi pasang togel 2026</a>
  <a href="https://bom48.com/store/">5 lions megaways terbaru</a>
  <a href="https://bom48.com/store/">cara judi slot indonesia</a>
  <a href="https://bom48.com/store/">wisdom of athena</a>
  <a href="https://bom48.com/store/">info betting terpercaya</a>
  <a href="https://bom48.com/store/">keluaran sbobet365 2026</a>
  <a href="https://bom48.com/store/">login slot gacor paling gacor</a>
  <a href="https://bom48.com/store/">crash game gacor</a>
  <a href="https://bom48.com/store/">keluaran slot dana deposit gopay</a>
  <a href="https://bom48.com/store/">bocoran taruhan no 1</a>
  <a href="https://bom48.com/store/">rtp togel online</a>
  <a href="https://bom48.com/store/">paling bandar togel</a>
  <a href="https://bom48.com/store/">link betting terlengkap</a>
  <a href="https://bom48.com/store/">agen poker winrate tinggi</a>
  <a href="https://bom48.com/store/">bocoran bandar togel anti lag</a>
  <a href="https://bom48.com/store/">main money cart</a>
  <a href="https://bom48.com/store/">selasa togel sgp</a>
  <a href="https://bom48.com/store/">hasil bandar togel hari ini</a>
  <a href="https://bom48.com/store/">besok pasang togel</a>
  <a href="https://bom48.com/store/">pola togel sdy anti rungkad</a>
  <a href="https://bom48.com/store/">gacor togel hk</a>
  <a href="https://bom48.com/store/">streaming casino terbaru</a>
  <a href="https://bom48.com/store/">streaming sbobet88 terpercaya</a>
  <a href="https://bom48.com/store/">link poker tanpa modal</a>
  <a href="https://bom48.com/store/">bandar judi slot tergacor</a>
  <a href="https://bom48.com/store/">togel hk pc</a>
  <a href="https://bom48.com/store/">link pro99</a>
  <a href="https://bom48.com/store/">angka judi bola anti rungkad</a>
  <a href="https://bom48.com/store/">streaming slot ovo nomor 1</a>
  <a href="https://bom48.com/store/">slot koi gate deposit qris</a>
  <a href="https://bom48.com/store/">result togel wd kilat</a>
  <a href="https://bom48.com/store/">poker online bonus rollingan</a>
  <a href="https://bom48.com/store/">juli live casino</a>
  <a href="https://bom48.com/store/">rekomendasi togel4d</a>
  <a href="https://bom48.com/store/">streaming slot pulsa tergacor</a>
  <a href="https://bom48.com/store/">bocoran prediksi togel deposit gopay</a>
  <a href="https://bom48.com/store/">cara togel sgp deposit pulsa</a>
  <a href="https://bom48.com/store/">tanpa biaya betting</a>
  <a href="https://bom48.com/store/">main book of golden sands</a>
  <a href="https://bom48.com/store/">slot online wild bandito</a>
  <a href="https://bom48.com/store/">agen judi togel mudah menang</a>
  <a href="https://bom48.com/store/">login slot terpercaya malam ini 2026</a>
  <a href="https://bom48.com/store/">link sbobet paling gacor</a>
  <a href="https://bom48.com/store/">bandar judi poker terbaik</a>
  <a href="https://bom48.com/store/">agen judi togel paling gacor</a>
  <a href="https://bom48.com/store/">login judi bola 2026</a>
  <a href="https://bom48.com/store/">daftar slot terbaru pagi ini</a>
  <a href="https://bom48.com/store/">demo slot red tiger</a>
  <a href="https://bom48.com/store/">streaming togel hk nomor 1</a>
  <a href="https://bom48.com/store/">tutorial casino indonesia</a>
  <a href="https://bom48.com/store/">terbaik slot dana maxwin</a>
  <a href="https://bom48.com/store/">trik result togel deposit pulsa</a>
  <a href="https://bom48.com/store/">login togel4d deposit dana</a>
  <a href="https://bom48.com/store/">terpercaya live casino 2026</a>
  <a href="https://bom48.com/store/">pola hot fiesta</a>
  <a href="https://bom48.com/store/">slot maxwin profesional</a>
  <a href="https://bom48.com/store/">bandar casino no 1</a>
  <a href="https://bom48.com/store/">link slot maxwin anti rungkad</a>
  <a href="https://bom48.com/store/">keluaran togel online online</a>
  <a href="https://bom48.com/store/">sbobet538 gacor</a>
  <a href="https://bom48.com/store/">situs pro168</a>
  <a href="https://bom48.com/store/">judi online rtp tinggi</a>
  <a href="https://bom48.com/store/">prediksi slot gacor anti rungkad</a>
  <a href="https://bom48.com/store/">sbobet1000 hari ini</a>
  <a href="https://bom48.com/store/">agen sbobet365 2025</a>
  <a href="https://bom48.com/store/">streaming togel sgp indonesia</a>
  <a href="https://bom48.com/store/">link slot pulsa resmi</a>
  <a href="https://bom48.com/store/">sbobet 2024</a>
  <a href="https://bom48.com/store/">daftar judi togel terpercaya</a>
  <a href="https://bom48.com/store/">rtp slot online nomor 1</a>
  <a href="https://bom48.com/store/">tips togel indonesia</a>
  <a href="https://bom48.com/store/">situs sbobet66</a>
  <a href="https://bom48.com/store/">casino438 hari ini</a>
  <a href="https://bom48.com/store/">casino338 terpercaya</a>
  <a href="https://bom48.com/store/">trik togel online no 1</a>
  <a href="https://bom48.com/store/">situs togel sgp anti rungkad</a>
  <a href="https://bom48.com/store/">hasil live casino terbaru</a>
  <a href="https://bom48.com/store/">casino online nonstop</a>
  <a href="https://bom48.com/store/">slot red tiger paling gacor</a>
  <a href="https://bom48.com/store/">trik sbobet login anti rungkad</a>
  <a href="https://bom48.com/store/">rtp slot gates of gatot kaca</a>
  <a href="https://bom48.com/store/">slot wd bca</a>
  <a href="https://bom48.com/store/">bandar judi togel paling gacor</a>
  <a href="https://bom48.com/store/">bandar slot deposit terlengkap</a>
  <a href="https://bom48.com/store/">demo slot habanero 2026</a>
  <a href="https://bom48.com/store/">erek erek tanah togel</a>
  <a href="https://bom48.com/store/">maxwin2d maxwin</a>
  <a href="https://bom48.com/store/">hasil slot online</a>
  <a href="https://bom48.com/store/">slot terpercaya big time gaming</a>
  <a href="https://bom48.com/store/">rtp sbobet365 tanpa modal</a>
  <a href="https://bom48.com/store/">terpercaya togel sgp nomor 1</a>
  <a href="https://bom48.com/store/">hasil betting gacor</a>
  <a href="https://bom48.com/store/">keluaran slot maxwin terbaik</a>
  <a href="https://bom48.com/store/">bocoran togel nomor 1</a>
  <a href="https://bom48.com/store/">gacor11 maxwin</a>
  <a href="https://bom48.com/store/">terbaik sbobet mobile tanpa potongan</a>
  <a href="https://bom48.com/store/">slot thailand anti lag</a>
  <a href="https://bom48.com/store/">prediksi slot dana paling gacor</a>
  <a href="https://bom48.com/store/">daftar taruhan maxwin</a>
  <a href="https://bom48.com/store/">slot big bass splash mudah menang</a>
  <a href="https://bom48.com/store/">slot koi gate terbaru</a>
  <a href="https://bom48.com/store/">cara togel hari ini</a>
  <a href="https://bom48.com/store/">live bandar togel deposit dana</a>
  <a href="https://bom48.com/store/">jp77 hari ini</a>
  <a href="https://bom48.com/store/">link daftar bandar poker</a>
  <a href="https://bom48.com/store/">hasil prediksi togel tanpa modal</a>
  <a href="https://bom48.com/store/">daftar sbobet indonesia</a>
  <a href="https://bom48.com/store/">keluaran sbobet365 terbaik</a>
  <a href="https://bom48.com/store/">demo slot playtech modal kecil</a>
  <a href="https://bom48.com/store/">weekday taruhan</a>
  <a href="https://bom48.com/store/">slot le bandit</a>
  <a href="https://bom48.com/store/">slot demo galaxy babies</a>
  <a href="https://bom48.com/store/">update togel4d</a>
  <a href="https://bom48.com/store/">live togel hari ini no 1</a>
  <a href="https://bom48.com/store/">link slot88 2026</a>
  <a href="https://bom48.com/store/">bandar slot minimal deposit kecil pagi ini</a>
  <a href="https://bom48.com/store/">terpercaya togel4d anti lag</a>
  <a href="https://bom48.com/store/">pola agen sbobet indonesia</a>
  <a href="https://bom48.com/store/">win10000 hari ini</a>
  <a href="https://bom48.com/store/">live casino android</a>
  <a href="https://bom48.com/store/">cara judi online nomor 1</a>
  <a href="https://bom48.com/store/">login slot anti lag terbaru hari ini</a>
  <a href="https://bom48.com/store/">bocoran olympus 1000</a>
  <a href="https://bom48.com/store/">terbaik slot dana indonesia</a>
  <a href="https://bom48.com/store/">login vip88</a>
  <a href="https://bom48.com/store/">data result togel anti lag</a>
  <a href="https://bom48.com/store/">live sbobet365 nomor 1</a>
  <a href="https://bom48.com/store/">playtech maxwin</a>
  <a href="https://bom48.com/store/">hasil casino online terlengkap</a>
  <a href="https://bom48.com/store/">demo slot netent resmi</a>
  <a href="https://bom48.com/store/">keluaran taruhan deposit dana</a>
  <a href="https://bom48.com/store/">5 lions gacor</a>
  <a href="https://bom48.com/store/">keluaran togel 2026</a>
  <a href="https://bom48.com/store/">login judi online nomor 1</a>
  <a href="https://bom48.com/store/">erek erek air 4d</a>
  <a href="https://bom48.com/store/">angka slot ovo deposit pulsa</a>
  <a href="https://bom48.com/store/">slot gacor play n go</a>
  <a href="https://bom48.com/store/">cara prediksi togel 2024</a>
  <a href="https://bom48.com/store/">keluaran togel paling gacor</a>
  <a href="https://bom48.com/store/">link judi online maxwin</a>
  <a href="https://bom48.com/store/">streaming poker nomor 1</a>
  <a href="https://bom48.com/store/">keluaran judi slot no 1</a>
  <a href="https://bom48.com/store/">demo slot microgaming gacor malam ini</a>
  <a href="https://bom48.com/store/">game slot terpercaya malam ini 2026</a>
  <a href="https://bom48.com/store/">slot dana deposit pulsa</a>
  <a href="https://bom48.com/store/">info casino online anti rungkad</a>
  <a href="https://bom48.com/store/">akun slot resmi terbaru hari ini</a>
  <a href="https://bom48.com/store/">judi respon cepat</a>
  <a href="https://bom48.com/store/">casino terpercaya terbaru</a>
  <a href="https://bom48.com/store/">trik sbobet mobile hari ini</a>
  <a href="https://bom48.com/store/">terbaik slot online tergacor</a>
  <a href="https://bom48.com/store/">cara sbobet login tergacor</a>
  <a href="https://bom48.com/store/">trik judi togel mudah menang</a>
  <a href="https://bom48.com/store/">cuan togel hk</a>
  <a href="https://bom48.com/store/">the dog house megaways</a>
  <a href="https://bom48.com/store/">pola slot anti lag</a>
  <a href="https://bom48.com/store/">demo slot push gaming rtp tinggi</a>
  <a href="https://bom48.com/store/">streaming slot gopay terbaik</a>
  <a href="https://bom48.com/store/">trik slot gacor deposit pulsa</a>
  <a href="https://bom48.com/store/">live judi bola anti lag</a>
  <a href="https://bom48.com/store/">info judi terpercaya</a>
  <a href="https://bom48.com/store/">mudah agen poker</a>
  <a href="https://bom48.com/store/">gacor3d hari ini</a>
  <a href="https://bom48.com/store/">judi online indonesia</a>
  <a href="https://bom48.com/store/">maret result togel</a>
  <a href="https://bom48.com/store/">terbaik sbobet365 mudah menang</a>
  <a href="https://bom48.com/store/">besok betting</a>
  <a href="https://bom48.com/store/">slot thailand profesional</a>
  <a href="https://bom48.com/store/">resmi slot deposit 2025</a>
  <a href="https://bom48.com/store/">agen judi slot resmi</a>
  <a href="https://bom48.com/store/">situs poker238</a>
  <a href="https://bom48.com/store/">togel488 hari ini</a>
  <a href="https://bom48.com/store/">slot money train 2 maxwin</a>
  <a href="https://bom48.com/store/">rtp togel tanpa modal</a>
  <a href="https://bom48.com/store/">slot yggdrasil paling gacor</a>
  <a href="https://bom48.com/store/">hasil slot dana tanpa potongan</a>
  <a href="https://bom48.com/store/">nomor slot gacor hari ini</a>
  <a href="https://bom48.com/store/">streaming togel4d anti rungkad</a>
  <a href="https://bom48.com/store/">angka sbobet mobile resmi</a>
  <a href="https://bom48.com/store/">login judi togel terpercaya</a>
  <a href="https://bom48.com/store/">resmi agen sbobet 2026</a>
  <a href="https://bom48.com/store/">wild west gold megaways demo</a>
  <a href="https://bom48.com/store/">hasil togel hk terlengkap</a>
  <a href="https://bom48.com/store/">angka sbobet mobile maxwin</a>
  <a href="https://bom48.com/store/">sbobet438 terpercaya</a>
  <a href="https://bom48.com/store/">jumat sbobet88</a>
  <a href="https://bom48.com/store/">bocoran slot maxwin anti lag</a>
  <a href="https://bom48.com/store/">data judi poker terbaru</a>
  <a href="https://bom48.com/store/">bandar togel maxwin</a>
  <a href="https://bom48.com/store/">data judi bola anti lag</a>
  <a href="https://bom48.com/store/">live slot online nomor 1</a>
  <a href="https://bom48.com/store/">akun slot gampang menang hari ini 2026</a>
  <a href="https://bom48.com/store/">togel hk terbaik</a>
  <a href="https://bom48.com/store/">data result togel terbaru</a>
  <a href="https://bom48.com/store/">prediksi togel server malaysia</a>
  <a href="https://bom48.com/store/">link slot thailand terpercaya</a>
  <a href="https://bom48.com/store/">rtp slot deposit maxwin</a>
  <a href="https://bom48.com/store/">slot slotmill modal kecil</a>
  <a href="https://bom48.com/store/">login result togel terpercaya</a>
  <a href="https://bom48.com/store/">domino qq terlengkap</a>
  <a href="https://bom48.com/store/">tips slot88 hari ini</a>
  <a href="https://bom48.com/store/">situs slot terpercaya 2026</a>
  <a href="https://bom48.com/store/">slot evoplay deposit pulsa</a>
  <a href="https://bom48.com/store/">main balloon</a>
  <a href="https://bom48.com/store/">trik sbobet mobile tanpa potongan</a>
  <a href="https://bom48.com/store/">bocoran judi togel terpercaya</a>
  <a href="https://bom48.com/store/">login dragon168</a>
  <a href="https://bom48.com/store/">hasil togel hari ini mudah menang</a>
  <a href="https://bom48.com/store/">agen poker mobile</a>
  <a href="https://bom48.com/store/">keluaran poker terpercaya</a>
  <a href="https://bom48.com/store/">agen togel hk anti rungkad</a>
  <a href="https://bom48.com/store/">starlight princess super scatter demo slot</a>
  <a href="https://bom48.com/store/">aztec bonanza demo</a>
  <a href="https://bom48.com/store/">5 mariachis 2026</a>
  <a href="https://bom48.com/store/">bocoran slot deposit tanpa potongan</a>
  <a href="https://bom48.com/store/">rtp togel sgp terbaik</a>
  <a href="https://bom48.com/store/">hasil togel4d terlengkap</a>
  <a href="https://bom48.com/store/">super ace 2026</a>
  <a href="https://bom48.com/store/">aplikasi slot gacor 2026</a>
  <a href="https://bom48.com/store/">5 lions megaways</a>
  <a href="https://bom48.com/store/">agen result togel resmi</a>
  <a href="https://bom48.com/store/">terpercaya togel4d online</a>
  <a href="https://bom48.com/store/">slot demo tanpa akun</a>
  <a href="https://bom48.com/store/">rtp betting terpercaya</a>
  <a href="https://bom48.com/store/">domino qq 2025</a>
  <a href="https://bom48.com/store/">data agen sbobet paling gacor</a>
  <a href="https://bom48.com/store/">resmi judi slot</a>
  <a href="https://bom48.com/store/">resmi pasang togel 2024</a>
  <a href="https://bom48.com/store/">link slot 2024</a>
  <a href="https://bom48.com/store/">slot mudah menang sweet kingdom</a>
  <a href="https://bom48.com/store/">slot the dog house megaways terbaru</a>
  <a href="https://bom48.com/store/">streaming sbobet mobile tanpa modal</a>
  <a href="https://bom48.com/store/">live slot online tergacor</a>
  <a href="https://bom48.com/store/">live slot dana anti lag</a>
  <a href="https://bom48.com/store/">terpercaya slot gopay 2026</a>
  <a href="https://bom48.com/store/">situs slot deposit bca</a>
  <a href="https://bom48.com/store/">tips bandar togel tanpa modal</a>
  <a href="https://bom48.com/store/">slot gacor mahjong ways 2</a>
  <a href="https://bom48.com/store/">cara menang slot ovo</a>
  <a href="https://bom48.com/store/">sangat casino indonesia</a>
  <a href="https://bom48.com/store/">demo slot isoftbet 2026</a>
  <a href="https://bom48.com/store/">pola live casino 2025</a>
  <a href="https://bom48.com/store/">streaming judi bola 2024</a>
  <a href="https://bom48.com/store/">pola betting nomor 1</a>
  <a href="https://bom48.com/store/">bandar slot rtp tinggi</a>
  <a href="https://bom48.com/store/">slot sugar rush</a>
  <a href="https://bom48.com/store/">situs slot6d</a>
  <a href="https://bom48.com/store/">togel sgp anti scam</a>
  <a href="https://bom48.com/store/">game slot rtp tinggi</a>
  <a href="https://bom48.com/store/">situs maxwin438</a>
  <a href="https://bom48.com/store/">togel via pulsa</a>
  <a href="https://bom48.com/store/">juni judi slot</a>
  <a href="https://bom48.com/store/">agen judi online deposit gopay</a>
  <a href="https://bom48.com/store/">info casino online terlengkap</a>
  <a href="https://bom48.com/store/">streaming casino online terpercaya</a>
  <a href="https://bom48.com/store/">slot gampang menang netent</a>
  <a href="https://bom48.com/store/">casino deposit pulsa</a>
  <a href="https://bom48.com/store/">resmi togel4d paling gacor</a>
  <a href="https://bom48.com/store/">nomor sbobet88 maxwin</a>
  <a href="https://bom48.com/store/">pola jammin jars 2</a>
  <a href="https://bom48.com/store/">tips slot thailand tergacor</a>
  <a href="https://bom48.com/store/">bet10000 terpercaya</a>
  <a href="https://bom48.com/store/">info slot online anti rungkad</a>
  <a href="https://bom48.com/store/">terbaik judi poker terbaik</a>
  <a href="https://bom48.com/store/">prediksi slot online deposit dana</a>
  <a href="https://bom48.com/store/">mahjong panda demo</a>
  <a href="https://bom48.com/store/">senin slot gacor</a>
  <a href="https://bom48.com/store/">terbaik slot thailand</a>
  <a href="https://bom48.com/store/">tutorial betting</a>
  <a href="https://bom48.com/store/">streaming sbobet365 indonesia</a>
  <a href="https://bom48.com/store/">live casino sering jp</a>
  <a href="https://bom48.com/store/">prediksi bandar togel tanpa potongan</a>
  <a href="https://bom48.com/store/">keluaran pasang togel resmi</a>
  <a href="https://bom48.com/store/">gacor10000 gacor</a>
  <a href="https://bom48.com/store/">link casino33</a>
  <a href="https://bom48.com/store/">login judi poker</a>
  <a href="https://bom48.com/store/">akun slot terbaik hari ini</a>
  <a href="https://bom48.com/store/">bonus judi poker</a>
  <a href="https://bom48.com/store/">togel168 maxwin</a>
  <a href="https://bom48.com/store/">cara bermain judi online</a>
  <a href="https://bom48.com/store/">keluaran judi slot hari ini</a>
  <a href="https://bom48.com/store/">data togel hari ini</a>
  <a href="https://bom48.com/store/">bandar poker minimal deposit</a>
  <a href="https://bom48.com/store/">untung togel hk</a>
  <a href="https://bom48.com/store/">bocoran sbobet365 gacor</a>
  <a href="https://bom48.com/store/">tips slot resmi</a>
  <a href="https://bom48.com/store/">judi winrate tertinggi</a>
  <a href="https://bom48.com/store/">nomor prediksi togel terbaru</a>
  <a href="https://bom48.com/store/">tips judi online 2025</a>
  <a href="https://bom48.com/store/">pong pong hu gacor</a>
  <a href="https://bom48.com/store/">withdraw casino terpercaya</a>
  <a href="https://bom48.com/store/">tips sbobet mobile deposit dana</a>
  <a href="https://bom48.com/store/">prediksi casino terbaru</a>
  <a href="https://bom48.com/store/">agen slot dana deposit dana</a>
  <a href="https://bom48.com/store/">rtp temple tumble</a>
  <a href="https://bom48.com/store/">slot bonanza 1000 deposit qris</a>
  <a href="https://bom48.com/store/">link slot anti lag hari ini</a>
  <a href="https://bom48.com/store/">slot hacksaw gaming terbaik</a>
  <a href="https://bom48.com/store/">januari casino terpercaya</a>
  <a href="https://bom48.com/store/">wisdom of athena demo slot</a>
  <a href="https://bom48.com/store/">daftar togel sgp gacor</a>
  <a href="https://bom48.com/store/">nomor pasang togel tanpa potongan</a>
  <a href="https://bom48.com/store/">togel hari ini terbukti bayar</a>
  <a href="https://bom48.com/store/">fresh sbobet login</a>
  <a href="https://bom48.com/store/">slot ovo tanpa potongan</a>
  <a href="https://bom48.com/store/">trik live casino tanpa modal</a>
  <a href="https://bom48.com/store/">gacor judi slot</a>
  <a href="https://bom48.com/store/">result china</a>
  <a href="https://bom48.com/store/">tips slot maxwin terbaik</a>
  <a href="https://bom48.com/store/">link slot688</a>
  <a href="https://bom48.com/store/">tips slot thailand anti rungkad</a>
  <a href="https://bom48.com/store/">casino terpercaya dijamin bayar</a>
  <a href="https://bom48.com/store/">login judi bola 2025</a>
  <a href="https://bom48.com/store/">resmi judi togel resmi</a>
  <a href="https://bom48.com/store/">slot terpercaya le bandit</a>
  <a href="https://bom48.com/store/">terpercaya slot deposit hari ini</a>
  <a href="https://bom48.com/store/">daftar togel hk gacor</a>
  <a href="https://bom48.com/store/">nomor judi togel deposit dana</a>
  <a href="https://bom48.com/store/">data slot deposit terlengkap</a>
  <a href="https://bom48.com/store/">trik sbobet365 deposit dana</a>
  <a href="https://bom48.com/store/">situs sbobet mobile</a>
  <a href="https://bom48.com/store/">domino qq jackpot besar</a>
  <a href="https://bom48.com/store/">sbobet88 anti scam</a>
  <a href="https://bom48.com/store/">pengeluaran togel4d nomor 1</a>
  <a href="https://bom48.com/store/">angka slot thailand mudah menang</a>
  <a href="https://bom48.com/store/">GATES OF OLYMPUS</a>
  <a href="https://bom48.com/store/">prediksi slot maxwin no 1</a>
  <a href="https://bom48.com/store/">daftar judi indonesia</a>
  <a href="https://bom48.com/store/">daftar judi poker deposit dana</a>
  <a href="https://bom48.com/store/">trik result togel terbaru</a>
  <a href="https://bom48.com/store/">slot88 gacor</a>
  <a href="https://bom48.com/store/">trik bandar togel resmi</a>
  <a href="https://bom48.com/store/">hasil casino nomor 1</a>
  <a href="https://bom48.com/store/">bonus prediksi togel</a>
  <a href="https://bom48.com/store/">agen prediksi togel tanpa modal</a>
  <a href="https://bom48.com/store/">lucky fortune 2026</a>
  <a href="https://bom48.com/store/">simpel sbobet mobile</a>
  <a href="https://bom48.com/store/">situs casino tanpa modal</a>
  <a href="https://bom48.com/store/">ter idn poker</a>
  <a href="https://bom48.com/store/">demo slot cq9 terpercaya</a>
  <a href="https://bom48.com/store/">terbaik togel sgp terbaru</a>
  <a href="https://bom48.com/store/">angka taruhan no 1</a>
  <a href="https://bom48.com/store/">judi server thailand</a>
  <a href="https://bom48.com/store/">terbaik sbobet login tergacor</a>
  <a href="https://bom48.com/store/">info agen sbobet terbaik</a>
  <a href="https://bom48.com/store/">hasil agen sbobet tergacor</a>
  <a href="https://bom48.com/store/">pasang togel cs cepat</a>
  <a href="https://bom48.com/store/">cara main casino</a>
  <a href="https://bom48.com/store/">nomor slot88 2024</a>
  <a href="https://bom48.com/store/">link slot terbaru malam ini</a>
  <a href="https://bom48.com/store/">prediksi betting bola</a>
  <a href="https://bom48.com/store/">daftar slot modal kecil sore ini</a>
  <a href="https://bom48.com/store/">daftar taruhan 2026</a>
  <a href="https://bom48.com/store/">prediksi togel akun pro</a>
  <a href="https://bom48.com/store/">win888 gacor</a>
  <a href="https://bom48.com/store/">link togel4d maxwin</a>
  <a href="https://bom48.com/store/">situs slot deposit qris 10rb</a>
  <a href="https://bom48.com/store/">ulasan slot deposit</a>
  <a href="https://bom48.com/store/">agen togel4d tanpa potongan</a>
  <a href="https://bom48.com/store/">casino online minimal deposit</a>
  <a href="https://bom48.com/store/">daftar togel4d 2025</a>
  <a href="https://bom48.com/store/">slot terpercaya wazdan</a>
  <a href="https://bom48.com/store/">bocoran judi online 2026</a>
  <a href="https://bom48.com/store/">bocoran live casino anti rungkad</a>
  <a href="https://bom48.com/store/">keluaran betting deposit pulsa</a>
  <a href="https://bom48.com/store/">daftar agen sbobet gacor</a>
  <a href="https://bom48.com/store/">data judi bola gacor</a>
  <a href="https://bom48.com/store/">resmi judi togel terlengkap</a>
  <a href="https://bom48.com/store/">slot gacor dragon hatch</a>
  <a href="https://bom48.com/store/">gacor00 maxwin</a>
  <a href="https://bom48.com/store/">terbaik prediksi togel 2024</a>
  <a href="https://bom48.com/store/">gacor sbobet88</a>
  <a href="https://bom48.com/store/">bandar slot minimal deposit kecil siang ini</a>
  <a href="https://bom48.com/store/">login slot88 anti rungkad</a>
  <a href="https://bom48.com/store/">live pasang togel indonesia</a>
  <a href="https://bom48.com/store/">login idn poker</a>
  <a href="https://bom48.com/store/">togel sdy jackpot besar</a>
  <a href="https://bom48.com/store/">daftar sbobet online</a>
  <a href="https://bom48.com/store/">pengeluaran pasang togel nomor 1</a>
  <a href="https://bom48.com/store/">data live casino online</a>
  <a href="https://bom48.com/store/">spaceman slot rtp tinggi</a>
  <a href="https://bom48.com/store/">daftar slot dana hari ini</a>
  <a href="https://bom48.com/store/">slot bonanza megaways deposit dana</a>
  <a href="https://bom48.com/store/">daftar casino tergacor</a>
  <a href="https://bom48.com/store/">slot the dog house deposit qris</a>
  <a href="https://bom48.com/store/">agen casino server luar</a>
  <a href="https://bom48.com/store/">erek erek togel</a>
  <a href="https://bom48.com/store/">info togel hari ini terpercaya</a>
  <a href="https://bom48.com/store/">pola togel resmi</a>
  <a href="https://bom48.com/store/">slot fortune garuda 1000 rtp tinggi</a>
  <a href="https://bom48.com/store/">bandar sbobet88 deposit pulsa</a>
  <a href="https://bom48.com/store/">agen pasang togel online</a>
  <a href="https://bom48.com/store/">rtp judi togel indonesia</a>
  <a href="https://bom48.com/store/">resmi bandar togel</a>
  <a href="https://bom48.com/store/">poker anti rungkad</a>
  <a href="https://bom48.com/store/">trik live casino deposit pulsa</a>
  <a href="https://bom48.com/store/">hot sbobet88</a>
  <a href="https://bom48.com/store/">terpercaya live casino terbaik</a>
  <a href="https://bom48.com/store/">angka casino terlengkap</a>
  <a href="https://bom48.com/store/">daftar sbobet mobile tanpa potongan</a>
  <a href="https://bom48.com/store/">demo slot idn slot gacor hari ini</a>
  <a href="https://bom48.com/store/">vip88 terpercaya</a>
  <a href="https://bom48.com/store/">demo slot relax gaming gacor</a>
  <a href="https://bom48.com/store/">slot ios</a>
  <a href="https://bom48.com/store/">slot yggdrasil terbaru</a>
  <a href="https://bom48.com/store/">daftar togel hari ini deposit pulsa</a>
  <a href="https://bom48.com/store/">fortune dragon</a>
  <a href="https://bom48.com/store/">demo slot quickspin 2026</a>
  <a href="https://bom48.com/store/">profit casino</a>
  <a href="https://bom48.com/store/">slot thailand tanpa potongan</a>
  <a href="https://bom48.com/store/">slot demo big bass splash</a>
  <a href="https://bom48.com/store/">pola slot dana resmi</a>
  <a href="https://bom48.com/store/">togel online wd instan</a>
  <a href="https://bom48.com/store/">login gacor4d</a>
  <a href="https://bom48.com/store/">nomor casino online terbaik</a>
  <a href="https://bom48.com/store/">pola judi poker gacor</a>
  <a href="https://bom48.com/store/">daftar gacor2d</a>
  <a href="https://bom48.com/store/">live casino hari ini</a>
  <a href="https://bom48.com/store/">login judi poker 2024</a>
  <a href="https://bom48.com/store/">game wm casino</a>
  <a href="https://bom48.com/store/">maxwin688 terpercaya</a>
  <a href="https://bom48.com/store/">pola slot ovo maxwin</a>
  <a href="https://bom48.com/store/">streaming slot dana indonesia</a>
  <a href="https://bom48.com/store/">link togel deposit pulsa</a>
  <a href="https://bom48.com/store/">resmi judi slot tanpa modal</a>
  <a href="https://bom48.com/store/">daftar togel online tanpa potongan</a>
  <a href="https://bom48.com/store/">rtp judi slot tergacor</a>
  <a href="https://bom48.com/store/">pengeluaran casino anti rungkad</a>
  <a href="https://bom48.com/store/">nomor togel sgp tanpa modal</a>
  <a href="https://bom48.com/store/">demo slot no limit city deposit kecil</a>
  <a href="https://bom48.com/store/">bandar togel hari ini deposit pulsa</a>
  <a href="https://bom48.com/store/">prediksi sbobet 2024</a>
  <a href="https://bom48.com/store/">agen slot gacor indonesia</a>
  <a href="https://bom48.com/store/">situs betting terbaru</a>
  <a href="https://bom48.com/store/">aman casino indonesia</a>
  <a href="https://bom48.com/store/">slot big bass splash 1000 gacor</a>
  <a href="https://bom48.com/store/">slot maxwin scatter hitam</a>
  <a href="https://bom48.com/store/">trik togel online 2026</a>
  <a href="https://bom48.com/store/">prediksi slot thailand terbaru</a>
  <a href="https://bom48.com/store/">cara menang money train 4</a>
  <a href="https://bom48.com/store/">tips taruhan indonesia</a>
  <a href="https://bom48.com/store/">money cart 2</a>
  <a href="https://bom48.com/store/">situs slot gacor terpercaya</a>
  <a href="https://bom48.com/store/">promo slot88</a>
  <a href="https://bom48.com/store/">cuan idn poker</a>
  <a href="https://bom48.com/store/">judi winrate tinggi</a>
  <a href="https://bom48.com/store/">cara slot thailand terbaik</a>
  <a href="https://bom48.com/store/">info judi togel nomor 1</a>
  <a href="https://bom48.com/store/">info live casino</a>
  <a href="https://bom48.com/store/">streaming judi bola</a>
  <a href="https://bom48.com/store/">rtp casino anti lag</a>
  <a href="https://bom48.com/store/">golden penny x1000 super wheel demo</a>
  <a href="https://bom48.com/store/">juli agen sbobet</a>
  <a href="https://bom48.com/store/">main plinko</a>
  <a href="https://bom48.com/store/">resmi prediksi togel hari ini</a>
  <a href="https://bom48.com/store/">bet55 hari ini</a>
  <a href="https://bom48.com/store/">bocoran prediksi togel terpercaya</a>
  <a href="https://bom48.com/store/">casino77 maxwin</a>
  <a href="https://bom48.com/store/">tips sbobet login gacor</a>
  <a href="https://bom48.com/store/">terbaru agen sbobet</a>
  <a href="https://bom48.com/store/">streaming sbobet88 no 1</a>
  <a href="https://bom48.com/store/">tips togel sgp 2026</a>
  <a href="https://bom48.com/store/">daftar slot dana deposit pulsa</a>
  <a href="https://bom48.com/store/">casino55 terpercaya</a>
  <a href="https://bom48.com/store/">cara pasang togel deposit dana</a>
  <a href="https://bom48.com/store/">domino qq demo gratis</a>
  <a href="https://bom48.com/store/">bandar slot pulsa tanpa modal</a>
  <a href="https://bom48.com/store/">agen taruhan terbaik</a>
  <a href="https://bom48.com/store/">bocoran fa cai shen</a>
  <a href="https://bom48.com/store/">keluaran slot dana terpercaya</a>
  <a href="https://bom48.com/store/">dragon99 terpercaya</a>
  <a href="https://bom48.com/store/">slot online microgaming</a>
  <a href="https://bom48.com/store/">togel hk nomor 1</a>
  <a href="https://bom48.com/store/">streaming togel online mudah menang</a>
  <a href="https://bom48.com/store/">pengeluaran slot maxwin tanpa modal</a>
  <a href="https://bom48.com/store/">trik togel sgp anti rungkad</a>
  <a href="https://bom48.com/store/">slot deposit indonesia</a>
  <a href="https://bom48.com/store/">streaming slot deposit resmi</a>
  <a href="https://bom48.com/store/">angka pasang togel deposit pulsa</a>
  <a href="https://bom48.com/store/">cara judi togel paling gacor</a>
  <a href="https://bom48.com/store/">cashback slot deposit</a>
  <a href="https://bom48.com/store/">togel sgp jackpot besar</a>
  <a href="https://bom48.com/store/">live togel sgp 2026</a>
  <a href="https://bom48.com/store/">data prediksi togel resmi</a>
  <a href="https://bom48.com/store/">resmi slot gacor gacor</a>
  <a href="https://bom48.com/store/">terbaik sbobet365 2024</a>
  <a href="https://bom48.com/store/">resmi togel hari ini terbaru</a>
  <a href="https://bom48.com/store/">login poker tanpa potongan</a>
  <a href="https://bom48.com/store/">keluaran togel terbaru</a>
  <a href="https://bom48.com/store/">tips togel4d terbaik</a>
  <a href="https://bom48.com/store/">data togel4d nomor 1</a>
  <a href="https://bom48.com/store/">slot joker gaming deposit 10 ribu</a>
  <a href="https://bom48.com/store/">betting bola akun pro</a>
  <a href="https://bom48.com/store/">fortune of olympus slot</a>
  <a href="https://bom48.com/store/">daftar poker168</a>
  <a href="https://bom48.com/store/">rtp slot gopay terlengkap</a>
  <a href="https://bom48.com/store/">sbobet mobile wd 3 menit</a>
  <a href="https://bom48.com/store/">nomor agen sbobet terpercaya</a>
  <a href="https://bom48.com/store/">prediksi pasang togel resmi</a>
  <a href="https://bom48.com/store/">streaming taruhan tanpa modal</a>
  <a href="https://bom48.com/store/">daftar slot terbaru malam ini</a>
  <a href="https://bom48.com/store/">cara togel4d terbaik</a>
  <a href="https://bom48.com/store/">streaming sbobet mobile terlengkap</a>
  <a href="https://bom48.com/store/">prediksi slot pulsa terbaik</a>
  <a href="https://bom48.com/store/">keluaran togel online no 1</a>
  <a href="https://bom48.com/store/">togel 2026</a>
  <a href="https://bom48.com/store/">login sbobet mobile terbaru</a>
  <a href="https://bom48.com/store/">bocoran judi slot tanpa potongan</a>
  <a href="https://bom48.com/store/">angka bandar togel deposit pulsa</a>
  <a href="https://bom48.com/store/">link slot withdraw cepat hari ini</a>
  <a href="https://bom48.com/store/">prediksi result togel tergacor</a>
  <a href="https://bom48.com/store/">main who wants to be a millionaire megaways</a>
  <a href="https://bom48.com/store/">streaming betting tanpa potongan</a>
  <a href="https://bom48.com/store/">poker2000 maxwin</a>
  <a href="https://bom48.com/store/">prediksi sbobet mobile 2024</a>
  <a href="https://bom48.com/store/">sultan168 terpercaya</a>
  <a href="https://bom48.com/store/">bandar taruhan terpercaya</a>
  <a href="https://bom48.com/store/">bocoran slot deposit deposit pulsa</a>
  <a href="https://bom48.com/store/">terbaik sbobet tanpa potongan</a>
  <a href="https://bom48.com/store/">trik slot gopay terpercaya</a>
  <a href="https://bom48.com/store/">pengeluaran betting tergacor</a>
  <a href="https://bom48.com/store/">bandar slot ovo terbaru</a>
  <a href="https://bom48.com/store/">rtp judi slot indonesia</a>
  <a href="https://bom48.com/store/">togel hari ini minimal deposit</a>
  <a href="https://bom48.com/store/">angka live casino maxwin</a>
  <a href="https://bom48.com/store/">agen slot mudah menang pagi ini</a>
  <a href="https://bom48.com/store/">angka live casino online</a>
  <a href="https://bom48.com/store/">slot88 aman terpercaya</a>
  <a href="https://bom48.com/store/">agen togel sgp deposit dana</a>
  <a href="https://bom48.com/store/">situs gacor838</a>
  <a href="https://bom48.com/store/">slot fortune snake rtp tinggi</a>
  <a href="https://bom48.com/store/">demo slot joker gacor malam ini</a>
  <a href="https://bom48.com/store/">agen judi poker 2024</a>
  <a href="https://bom48.com/store/">prediksi sbobet tanpa modal</a>
  <a href="https://bom48.com/store/">angka taruhan tanpa modal</a>
  <a href="https://bom48.com/store/">modal kecil sbobet88</a>
  <a href="https://bom48.com/store/">slot online deposit ovo 10 ribu</a>
  <a href="https://bom48.com/store/">terbaik togel indonesia</a>
  <a href="https://bom48.com/store/">daftar judi bola nomor 1</a>
  <a href="https://bom48.com/store/">referral sbobet login</a>
  <a href="https://bom48.com/store/">nomor bandar togel anti rungkad</a>
  <a href="https://bom48.com/store/">slot88 minimal deposit</a>
  <a href="https://bom48.com/store/">tips slot dana deposit pulsa</a>
  <a href="https://bom48.com/store/">resmi judi poker deposit pulsa</a>
  <a href="https://bom48.com/store/">streaming betting deposit pulsa</a>
  <a href="https://bom48.com/store/">situs gacor138</a>
  <a href="https://bom48.com/store/">platform slot maxwin sore ini</a>
  <a href="https://bom48.com/store/">prediksi sbobet88 online</a>
  <a href="https://bom48.com/store/">slot gacor garuda gems</a>
  <a href="https://bom48.com/store/">keluaran sbobet deposit gopay</a>
  <a href="https://bom48.com/store/">link slot thailand maxwin</a>
  <a href="https://bom48.com/store/">cara slot nomor 1</a>
  <a href="https://bom48.com/store/">login sbobet88 2024</a>
  <a href="https://bom48.com/store/">terbaik result togel mudah menang</a>
  <a href="https://bom48.com/store/">maxwin123 terpercaya</a>
  <a href="https://bom48.com/store/">tanpa modal slot</a>
  <a href="https://bom48.com/store/">keluaran slot ovo tanpa potongan</a>
  <a href="https://bom48.com/store/">streaming judi hari ini</a>
  <a href="https://bom48.com/store/">pengeluaran togel sgp tergacor</a>
  <a href="https://bom48.com/store/">terpercaya betting deposit pulsa</a>
  <a href="https://bom48.com/store/">pola buffalo king</a>
  <a href="https://bom48.com/store/">apk togel sdy</a>
  <a href="https://bom48.com/store/">hasil betting nomor 1</a>
  <a href="https://bom48.com/store/">sangat slot88</a>
  <a href="https://bom48.com/store/">angka slot pulsa 2024</a>
  <a href="https://bom48.com/store/">slot22 maxwin</a>
  <a href="https://bom48.com/store/">pengeluaran slot deposit terpercaya</a>
  <a href="https://bom48.com/store/">angka pasang togel 2025</a>
  <a href="https://bom48.com/store/">Togel Sgp</a>
  <a href="https://bom48.com/store/">slot gampang menang gates of hades</a>
  <a href="https://bom48.com/store/">main zeus vs hades</a>
  <a href="https://bom48.com/store/">trik casino deposit pulsa</a>
  <a href="https://bom48.com/store/">link slot online 2025</a>
  <a href="https://bom48.com/store/">taruhan terpercaya</a>
  <a href="https://bom48.com/store/">resmi agen sbobet tanpa modal</a>
  <a href="https://bom48.com/store/">nomor togel hk deposit pulsa</a>
  <a href="https://bom48.com/store/">info sbobet88 hari ini</a>
  <a href="https://bom48.com/store/">daftar judi mudah menang</a>
  <a href="https://bom48.com/store/">slot demo el bandido explosivo</a>
  <a href="https://bom48.com/store/">keluaran judi togel anti rungkad</a>
  <a href="https://bom48.com/store/">terbaru judi slot</a>
  <a href="https://bom48.com/store/">cara slot gopay hari ini</a>
  <a href="https://bom48.com/store/">togel4d sering jp</a>
  <a href="https://bom48.com/store/">wolf gold 2026</a>
  <a href="https://bom48.com/store/">situs slot terbaru 2026</a>
  <a href="https://bom48.com/store/">slot online pragmatic play</a>
  <a href="https://bom48.com/store/">login bet1000</a>
  <a href="https://bom48.com/store/">pola judi terlengkap</a>
  <a href="https://bom48.com/store/">casino online wd 3 menit</a>
  <a href="https://bom48.com/store/">daftar casino55</a>
  <a href="https://bom48.com/store/">keluaran casino no 1</a>
  <a href="https://bom48.com/store/">daftar bet99</a>
  <a href="https://bom48.com/store/">nomor slot gacor online</a>
  <a href="https://bom48.com/store/">bocoran togel online indonesia</a>
  <a href="https://bom48.com/store/">link togel hk terlengkap</a>
  <a href="https://bom48.com/store/">gold88 gacor</a>
  <a href="https://bom48.com/store/">nomor judi togel terbaru</a>
  <a href="https://bom48.com/store/">slot deposit pulsa indosat terpercaya</a>
  <a href="https://bom48.com/store/">data judi poker online</a>
  <a href="https://bom48.com/store/">demo slot netent deposit kecil</a>
  <a href="https://bom48.com/store/">casino online member baru</a>
  <a href="https://bom48.com/store/">live sbobet indonesia</a>
  <a href="https://bom48.com/store/">slot via qris</a>
  <a href="https://bom48.com/store/">weekend slot gopay</a>
  <a href="https://bom48.com/store/">login slot withdraw cepat hari ini</a>
  <a href="https://bom48.com/store/">slot online fortune tiger</a>
  <a href="https://bom48.com/store/">terpercaya slot88 2024</a>
  <a href="https://bom48.com/store/">slot le king deposit qris</a>
  <a href="https://bom48.com/store/">link pasang togel maxwin</a>
  <a href="https://bom48.com/store/">resmi slot online 2025</a>
  <a href="https://bom48.com/store/">resmi judi online maxwin</a>
  <a href="https://bom48.com/store/">agen sbobet365 2026</a>
  <a href="https://bom48.com/store/">pola slot tergacor</a>
  <a href="https://bom48.com/store/">rabu judi</a>
  <a href="https://bom48.com/store/">januari bandar poker</a>
  <a href="https://bom48.com/store/">taruhan tanpa modal</a>
  <a href="https://bom48.com/store/">daftar slot proses cepat pagi ini</a>
  <a href="https://bom48.com/store/">demo slot nolimit city deposit kecil</a>
  <a href="https://bom48.com/store/">cara judi bola deposit dana</a>
  <a href="https://bom48.com/store/">hasil slot online tergacor</a>
  <a href="https://bom48.com/store/">pola slot online nomor 1</a>
  <a href="https://bom48.com/store/">pengeluaran betting online</a>
  <a href="https://bom48.com/store/">cepat sbobet</a>
  <a href="https://bom48.com/store/">slot10000 gacor</a>
  <a href="https://bom48.com/store/">angka judi online 2026</a>
  <a href="https://bom48.com/store/">ter sbobet365</a>
  <a href="https://bom48.com/store/">knockout riches gacor hari ini</a>
  <a href="https://bom48.com/store/">info slot maxwin anti lag</a>
  <a href="https://bom48.com/store/">data judi online gacor</a>
  <a href="https://bom48.com/store/">rhythm nights demo slot</a>
  <a href="https://bom48.com/store/">bandar slot dana paling gacor</a>
  <a href="https://bom48.com/store/">akun slot anti rungkat sore ini</a>
  <a href="https://bom48.com/store/">demo slot pragmatic play anti rungkat</a>
  <a href="https://bom48.com/store/">versi terbaru slot gacor</a>
  <a href="https://bom48.com/store/">login slot pulsa terbaru</a>
  <a href="https://bom48.com/store/">streaming judi poker deposit dana</a>
  <a href="https://bom48.com/store/">cara slot88 tergacor</a>
  <a href="https://bom48.com/store/">keluaran agen sbobet resmi</a>
  <a href="https://bom48.com/store/">razor shark 2025</a>
  <a href="https://bom48.com/store/">result togel akun pro</a>
  <a href="https://bom48.com/store/">slot gacor fortune tiger</a>
  <a href="https://bom48.com/store/">casino44 maxwin</a>
  <a href="https://bom48.com/store/">bocoran squid game slot</a>
  <a href="https://bom48.com/store/">sbobet838 gacor</a>
  <a href="https://bom48.com/store/">bulan ini poker</a>
  <a href="https://bom48.com/store/">pola power of thor megaways</a>
  <a href="https://bom48.com/store/">bocoran slot deposit hari ini</a>
  <a href="https://bom48.com/store/">cara agen sbobet paling gacor</a>
  <a href="https://bom48.com/store/">daftar casino688</a>
  <a href="https://bom48.com/store/">slot deposit pulsa tanpa potongan resmi</a>
  <a href="https://bom48.com/store/">platform slot terbaik hari ini 2026</a>
  <a href="https://bom48.com/store/">data betting 2024</a>
  <a href="https://bom48.com/store/">terbaik sbobet365</a>
  <a href="https://bom48.com/store/">slot cuan besar</a>
  <a href="https://bom48.com/store/">link alternatif slot thailand</a>
  <a href="https://bom48.com/store/">slot gacor fortune garuda</a>
  <a href="https://bom48.com/store/">trik togel hari ini 2025</a>
  <a href="https://bom48.com/store/">hasil sbobet login terpercaya</a>
  <a href="https://bom48.com/store/">terbaru slot thailand</a>
  <a href="https://bom48.com/store/">demo slot microgaming rtp tinggi</a>
  <a href="https://bom48.com/store/">link togel hari ini anti lag</a>
  <a href="https://bom48.com/store/">agen slot terbaru sore ini</a>
  <a href="https://bom48.com/store/">agen sbobet deposit 5rb</a>
  <a href="https://bom48.com/store/">data togel tanpa modal</a>
  <a href="https://bom48.com/store/">mahjong ways 3</a>
  <a href="https://bom48.com/store/">pola sbobet88 indonesia</a>
  <a href="https://bom48.com/store/">prediksi slot gacor indonesia</a>
  <a href="https://bom48.com/store/">slot gates of gatot kaca</a>
  <a href="https://bom48.com/store/">bocoran betting terpercaya</a>
  <a href="https://bom48.com/store/">modal kecil togel hari ini</a>
  <a href="https://bom48.com/store/">hasil sbobet mobile deposit pulsa</a>
  <a href="https://bom48.com/store/">link judi bola terpercaya</a>
  <a href="https://bom48.com/store/">rtp slot fishin frenzy</a>
  <a href="https://bom48.com/store/">pola live casino anti lag</a>
  <a href="https://bom48.com/store/">rtp judi slot online</a>
  <a href="https://bom48.com/store/">terpercaya sbobet365 indonesia</a>
  <a href="https://bom48.com/store/">jp5000 maxwin</a>
  <a href="https://bom48.com/store/">terbaik sbobet88 maxwin</a>
  <a href="https://bom48.com/store/">terbaik slot maxwin mudah menang</a>
  <a href="https://bom48.com/store/">hasil togel sdy hari ini</a>
  <a href="https://bom48.com/store/">login bandar togel hari ini</a>
  <a href="https://bom48.com/store/">terbaik judi online deposit gopay</a>
  <a href="https://bom48.com/store/">tips slot dana tanpa potongan</a>
  <a href="https://bom48.com/store/">pola training camp</a>
  <a href="https://bom48.com/store/">rtp togel sgp terbaru</a>
  <a href="https://bom48.com/store/">link judi tergacor</a>
  <a href="https://bom48.com/store/">slot sugar rush demo</a>
  <a href="https://bom48.com/store/">streaming bandar togel 2025</a>
  <a href="https://bom48.com/store/">daftar judi slot nomor 1</a>
  <a href="https://bom48.com/store/">slot online akun demo</a>
  <a href="https://bom48.com/store/">slot gacor hacksaw gaming</a>
  <a href="https://bom48.com/store/">angka slot ovo 2024</a>
  <a href="https://bom48.com/store/">situs slot maxwin malam ini 2026</a>
  <a href="https://bom48.com/store/">casino 2026</a>
  <a href="https://bom48.com/store/">king88 togel</a>
  <a href="https://bom48.com/store/">terbaik sbobet login terbaru</a>
  <a href="https://bom48.com/store/">pola sbobet login terlengkap</a>
  <a href="https://bom48.com/store/">nomor togel online tanpa modal</a>
  <a href="https://bom48.com/store/">akun slot proses cepat terbaru hari ini</a>
  <a href="https://bom48.com/store/">resmi slot ovo 2024</a>
  <a href="https://bom48.com/store/">poker588 terpercaya</a>
  <a href="https://bom48.com/store/">terbaik togel online online</a>
  <a href="https://bom48.com/store/">trik slot ovo deposit gopay</a>
  <a href="https://bom48.com/store/">pengeluaran betting no 1</a>
  <a href="https://bom48.com/store/">cara betting deposit gopay</a>
  <a href="https://bom48.com/store/">pola judi maxwin</a>
  <a href="https://bom48.com/store/">agen judi togel deposit gopay</a>
  <a href="https://bom48.com/store/">slot188 togel</a>
  <a href="https://bom48.com/store/">referral slot dana</a>
  <a href="https://bom48.com/store/">situs sbobet login indonesia</a>
  <a href="https://bom48.com/store/">result togel winrate tertinggi</a>
  <a href="https://bom48.com/store/">maxwin388 gacor</a>
  <a href="https://bom48.com/store/">referral sbobet</a>
  <a href="https://bom48.com/store/">bocoran result togel nomor 1</a>
  <a href="https://bom48.com/store/">daftar slot online terbaru</a>
  <a href="https://bom48.com/store/">fresh poker online</a>
  <a href="https://bom48.com/store/">bocoran sbobet terpercaya</a>
  <a href="https://bom48.com/store/">info slot maxwin anti rungkad</a>
  <a href="https://bom48.com/store/">daftar togel22</a>
  <a href="https://bom48.com/store/">daftar jp338</a>
  <a href="https://bom48.com/store/">promo betting bola</a>
  <a href="https://bom48.com/store/">togel4d tanpa aplikasi</a>
  <a href="https://bom48.com/store/">pola slot terlengkap</a>
  <a href="https://bom48.com/store/">judi deposit indosat</a>
  <a href="https://bom48.com/store/">link jp22</a>
  <a href="https://bom48.com/store/">terbaik slot pulsa resmi</a>
  <a href="https://bom48.com/store/">angka togel</a>
  <a href="https://bom48.com/store/">fortune rabbit maxwin</a>
  <a href="https://bom48.com/store/">pola togel mudah menang</a>
  <a href="https://bom48.com/store/">data casino online deposit gopay</a>
  <a href="https://bom48.com/store/">jp66 terpercaya</a>
  <a href="https://bom48.com/store/">keluaran slot pulsa hari ini</a>
  <a href="https://bom48.com/store/">pengeluaran prediksi togel tanpa modal</a>
  <a href="https://bom48.com/store/">maxwin judi togel</a>
  <a href="https://bom48.com/store/">nomor 1 togel sgp</a>
  <a href="https://bom48.com/store/">live judi poker anti lag</a>
  <a href="https://bom48.com/store/">pengeluaran sbobet deposit gopay</a>
  <a href="https://bom48.com/store/">agen judi bola hari ini</a>
  <a href="https://bom48.com/store/">bandar slot88 deposit pulsa</a>
  <a href="https://bom48.com/store/">daftar taruhan</a>
  <a href="https://bom48.com/store/">daftar jp1000</a>
  <a href="https://bom48.com/store/">streaming prediksi togel gacor</a>
  <a href="https://bom48.com/store/">bocoran slot pulsa deposit pulsa</a>
  <a href="https://bom48.com/store/">info sbobet login anti lag</a>
  <a href="https://bom48.com/store/">judi togel demo gratis</a>
  <a href="https://bom48.com/store/">demo slot habanero terbaru</a>
  <a href="https://bom48.com/store/">prediksi togel sdy maxwin</a>
  <a href="https://bom48.com/store/">resmi togel sdy tanpa potongan</a>
  <a href="https://bom48.com/store/">info slot pulsa</a>
  <a href="https://bom48.com/store/">togel1000 maxwin</a>
  <a href="https://bom48.com/store/">april agen poker</a>
  <a href="https://bom48.com/store/">big two demo</a>
  <a href="https://bom48.com/store/">link win4d</a>
  <a href="https://bom48.com/store/">slot maxwin mudah menang</a>
  <a href="https://bom48.com/store/">link sbobet365 tanpa modal</a>
  <a href="https://bom48.com/store/">bulan ini casino online</a>
  <a href="https://bom48.com/store/">pola judi togel terbaik</a>
  <a href="https://bom48.com/store/">tips agen sbobet 2025</a>
  <a href="https://bom48.com/store/">main 5 lions</a>
  <a href="https://bom48.com/store/">pola togel4d nomor 1</a>
  <a href="https://bom48.com/store/">link judi slot terpercaya</a>
  <a href="https://bom48.com/store/">bocoran slot dana nomor 1</a>
  <a href="https://bom48.com/store/">login taruhan tanpa potongan</a>
  <a href="https://bom48.com/store/">sbobet4d terpercaya</a>
  <a href="https://bom48.com/store/">angka togel sgp 2025</a>
  <a href="https://bom48.com/store/">resmi prediksi togel terpercaya</a>
  <a href="https://bom48.com/store/">rtp betting</a>
  <a href="https://bom48.com/store/">data togel sgp anti rungkad</a>
  <a href="https://bom48.com/store/">link togel hari ini paling gacor</a>
  <a href="https://bom48.com/store/">bandar slot withdraw cepat hari ini 2026</a>
  <a href="https://bom48.com/store/">pola jammin jars</a>
  <a href="https://bom48.com/store/">slot habanero paling gacor</a>
  <a href="https://bom48.com/store/">demo slot pg soft</a>
  <a href="https://bom48.com/store/">bonanza 1000 gacor</a>
  <a href="https://bom48.com/store/">terpercaya judi slot mudah menang</a>
  <a href="https://bom48.com/store/">link slot pulsa deposit gopay</a>
  <a href="https://bom48.com/store/">sbobet login tanpa vpn</a>
  <a href="https://bom48.com/store/">link slot pulsa 2025</a>
  <a href="https://bom48.com/store/">trik judi poker anti lag</a>
  <a href="https://bom48.com/store/">bet738 gacor</a>
  <a href="https://bom48.com/store/">review agen sbobet</a>
  <a href="https://bom48.com/store/">demo slot slotmill gacor hari ini</a>
  <a href="https://bom48.com/store/">angka togel hk 2026</a>
  <a href="https://bom48.com/store/">info agen sbobet terlengkap</a>
  <a href="https://bom48.com/store/">slot ovo jackpot besar</a>
  <a href="https://bom48.com/store/">cashback slot ovo</a>
  <a href="https://bom48.com/store/">trik sbobet login deposit pulsa</a>
  <a href="https://bom48.com/store/">rtp sweet rush bonanza</a>
  <a href="https://bom48.com/store/">jumat sbobet login</a>
  <a href="https://bom48.com/store/">april pasang togel</a>
  <a href="https://bom48.com/store/">pola sbobet login terpercaya</a>
  <a href="https://bom48.com/store/">terbaik sbobet login resmi</a>
  <a href="https://bom48.com/store/">sbobet login tanpa aplikasi</a>
  <a href="https://bom48.com/store/">terpercaya judi togel nomor 1</a>
  <a href="https://bom48.com/store/">cara judi online tanpa modal</a>
  <a href="https://bom48.com/store/">review bandar togel</a>
  <a href="https://bom48.com/store/">terbaik casino online 2026</a>
  <a href="https://bom48.com/store/">erek erek petir 4d</a>
  <a href="https://bom48.com/store/">rtp togel4d 2024</a>
  <a href="https://bom48.com/store/">togel4d bonus rollingan</a>
  <a href="https://bom48.com/store/">cara slot ovo nomor 1</a>
  <a href="https://bom48.com/store/">daftar poker3d</a>
  <a href="https://bom48.com/store/">nomor casino online 2025</a>
  <a href="https://bom48.com/store/">pola slot ovo 2025</a>
  <a href="https://bom48.com/store/">rtp slot thailand deposit pulsa</a>
  <a href="https://bom48.com/store/">rise of giza powerups 2026</a>
  <a href="https://bom48.com/store/">info agen sbobet 2025</a>
  <a href="https://bom48.com/store/">resmi live casino tanpa modal</a>
  <a href="https://bom48.com/store/">login slot anti rungkat malam ini</a>
  <a href="https://bom48.com/store/">login slot gacor no 1</a>
  <a href="https://bom48.com/store/">live sbobet88 mudah menang</a>
  <a href="https://bom48.com/store/">resmi slot maxwin deposit dana</a>
  <a href="https://bom48.com/store/">tips slot thailand tanpa modal</a>
  <a href="https://bom48.com/store/">fortune horse slot demo</a>
  <a href="https://bom48.com/store/">bet3000 gacor</a>
  <a href="https://bom48.com/store/">bet838 hari ini</a>
  <a href="https://bom48.com/store/">trik judi poker 2024</a>
  <a href="https://bom48.com/store/">jumat togel4d</a>
  <a href="https://bom48.com/store/">aplikasi sbobet88</a>
  <a href="https://bom48.com/store/">main sweet bonanza</a>
  <a href="https://bom48.com/store/">data slot dana maxwin</a>
  <a href="https://bom48.com/store/">jam gacor 1000x starlight</a>
  <a href="https://bom48.com/store/">link judi anti rungkad</a>
  <a href="https://bom48.com/store/">casino online mobile</a>
  <a href="https://bom48.com/store/">platform slot gacor sore ini</a>
  <a href="https://bom48.com/store/">live pasang togel hari ini</a>
  <a href="https://bom48.com/store/">bocoran togel online anti rungkad</a>
  <a href="https://bom48.com/store/">prediksi togel sdy resmi</a>
  <a href="https://bom48.com/store/">gacor338 maxwin</a>
  <a href="https://bom48.com/store/">link casino terlengkap</a>
  <a href="https://bom48.com/store/">slot deposit dana 10k resmi</a>
  <a href="https://bom48.com/store/">situs slot gacor terbaik</a>
  <a href="https://bom48.com/store/">slot gacor mahjong ways</a>
  <a href="https://bom48.com/store/">sbobet1000 maxwin</a>
  <a href="https://bom48.com/store/">casino online jackpot besar</a>
  <a href="https://bom48.com/store/">slot pg soft deposit 10 ribu</a>
  <a href="https://bom48.com/store/">rtp slot avatarux</a>
  <a href="https://bom48.com/store/">link poker168</a>
  <a href="https://bom48.com/store/">training camp 2025</a>
  <a href="https://bom48.com/store/">keluaran slot deposit 2026</a>
  <a href="https://bom48.com/store/">nomor taruhan nomor 1</a>
  <a href="https://bom48.com/store/">bandar togel hk tanpa potongan</a>
  <a href="https://bom48.com/store/">rtp reactoonz</a>
  <a href="https://bom48.com/store/">keluaran slot tergacor</a>
  <a href="https://bom48.com/store/">akun slot minimal deposit kecil siang ini</a>
  <a href="https://bom48.com/store/">paling agen sbobet</a>
  <a href="https://bom48.com/store/">judi laptop</a>
  <a href="https://bom48.com/store/">menang slot dana</a>
  <a href="https://bom48.com/store/">situs slot online hari ini</a>
  <a href="https://bom48.com/store/">angka sbobet mobile</a>
  <a href="https://bom48.com/store/">situs bandar togel terbaru</a>
  <a href="https://bom48.com/store/">game slot rtp tinggi hari ini</a>
  <a href="https://bom48.com/store/">resmi bandar togel deposit gopay</a>
  <a href="https://bom48.com/store/">3 fruit slots terbaru</a>
  <a href="https://bom48.com/store/">modal kecil slot ovo</a>
  <a href="https://bom48.com/store/">link judi togel online</a>
  <a href="https://bom48.com/store/">link prediksi togel anti rungkad</a>
  <a href="https://bom48.com/store/">pola sbobet365 anti rungkad</a>
  <a href="https://bom48.com/store/">togel sdy gacor</a>
  <a href="https://bom48.com/store/">nomor togel sdy indonesia</a>
  <a href="https://bom48.com/store/">pengeluaran sbobet indonesia</a>
  <a href="https://bom48.com/store/">pola sbobet terbaik</a>
  <a href="https://bom48.com/store/">keno pragmatic play demo</a>
  <a href="https://bom48.com/store/">login judi tergacor</a>
  <a href="https://bom48.com/store/">tips sbobet login paling gacor</a>
  <a href="https://bom48.com/store/">link alternatif judi</a>
  <a href="https://bom48.com/store/">game slot mudah menang 2026</a>
  <a href="https://bom48.com/store/">bandar live casino tergacor</a>
  <a href="https://bom48.com/store/">tips casino online 2025</a>
  <a href="https://bom48.com/store/">daftar slot maxwin paling gacor</a>
  <a href="https://bom48.com/store/">cara slot pulsa terbaik</a>
  <a href="https://bom48.com/store/">hasil togel4d tergacor</a>
  <a href="https://bom48.com/store/">terbaik judi poker 2024</a>
  <a href="https://bom48.com/store/">cara judi togel terbaru</a>
  <a href="https://bom48.com/store/">login jp33</a>
  <a href="https://bom48.com/store/">bet338 terpercaya</a>
  <a href="https://bom48.com/store/">link win188</a>
  <a href="https://bom48.com/store/">resmi poker tergacor</a>
  <a href="https://bom48.com/store/">live betting mudah menang</a>
  <a href="https://bom48.com/store/">paling togel sdy</a>
  <a href="https://bom48.com/store/">bocoran slot online anti lag</a>
  <a href="https://bom48.com/store/">slot maxwin starlight princess super scatter</a>
  <a href="https://bom48.com/store/">situs pasang togel tanpa modal</a>
  <a href="https://bom48.com/store/">bocoran mahjong ways</a>
  <a href="https://bom48.com/store/">free sbobet login</a>
  <a href="https://bom48.com/store/">big bass halloween splash 1000</a>
  <a href="https://bom48.com/store/">rtp togel sdy 2025</a>
  <a href="https://bom48.com/store/">trik sbobet365 2025</a>
  <a href="https://bom48.com/store/">pola joker</a>
  <a href="https://bom48.com/store/">pola judi poker 2024</a>
  <a href="https://bom48.com/store/">togel hk sering jp</a>
  <a href="https://bom48.com/store/">daftar slot dana mudah menang</a>
  <a href="https://bom48.com/store/">poker688 hari ini</a>
  <a href="https://bom48.com/store/">tips slot deposit pulsa</a>
  <a href="https://bom48.com/store/">free togel online</a>
  <a href="https://bom48.com/store/">data sgp</a>
  <a href="https://bom48.com/store/">resmi judi poker</a>
  <a href="https://bom48.com/store/">daftar slot terbaik hari ini 2026</a>
  <a href="https://bom48.com/store/">angka sbobet365 no 1</a>
  <a href="https://bom48.com/store/">bocoran slot pulsa paling gacor</a>
  <a href="https://bom48.com/store/">sultan99 gacor</a>
  <a href="https://bom48.com/store/">aman togel4d</a>
  <a href="https://bom48.com/store/">cara sbobet terlengkap</a>
  <a href="https://bom48.com/store/">rtp sbobet tergacor</a>
  <a href="https://bom48.com/store/">rtp judi terlengkap</a>
  <a href="https://bom48.com/store/">bandar judi online tergacor</a>
  <a href="https://bom48.com/store/">info togel sgp hari ini</a>
  <a href="https://bom48.com/store/">streaming slot88 no 1</a>
  <a href="https://bom48.com/store/">resmi casino mudah menang</a>
  <a href="https://bom48.com/store/">angka togel deposit pulsa</a>
  <a href="https://bom48.com/store/">bet168 maxwin</a>
  <a href="https://bom48.com/store/">link slot rtp tinggi pagi ini</a>
  <a href="https://bom48.com/store/">resmi togel terbaru</a>
  <a href="https://bom48.com/store/">cara casino nomor 1</a>
  <a href="https://bom48.com/store/">platform slot anti lag terbaru hari ini</a>
  <a href="https://bom48.com/store/">resmi agen sbobet no 1</a>
  <a href="https://bom48.com/store/">slot push gaming deposit dana</a>
  <a href="https://bom48.com/store/">togel ios</a>
  <a href="https://bom48.com/store/">live sbobet login deposit pulsa</a>
  <a href="https://bom48.com/store/">wheel of fortune gacor</a>
  <a href="https://bom48.com/store/">selasa pasang togel</a>
  <a href="https://bom48.com/store/">judi server jp</a>
  <a href="https://bom48.com/store/">slot deposit dana</a>
  <a href="https://bom48.com/store/">bocoran capsa banting</a>
  <a href="https://bom48.com/store/">referral slot pulsa</a>
  <a href="https://bom48.com/store/">aman poker</a>
  <a href="https://bom48.com/store/">tips slot online tergacor</a>
  <a href="https://bom48.com/store/">prediksi sbobet login terpercaya</a>
  <a href="https://bom48.com/store/">nomor slot maxwin paling gacor</a>
  <a href="https://bom48.com/store/">login slot rtp tinggi hari ini</a>
  <a href="https://bom48.com/store/">BONUS NEW MEMBER</a>
  <a href="https://bom48.com/store/">nomor togel hk terpercaya</a>
  <a href="https://bom48.com/store/">tanpa biaya sbobet</a>
  <a href="https://bom48.com/store/">rabu judi online</a>
  <a href="https://bom48.com/store/">slot online deposit shopeepay</a>
  <a href="https://bom48.com/store/">menang agen casino</a>
  <a href="https://bom48.com/store/">nomor judi togel tergacor</a>
  <a href="https://bom48.com/store/">pengeluaran togel sdy 2026</a>
  <a href="https://bom48.com/store/">sbobet mobile wd instan</a>
  <a href="https://bom48.com/store/">senin sbobet login</a>
  <a href="https://bom48.com/store/">pengeluaran taruhan deposit dana</a>
  <a href="https://bom48.com/store/">situs togel hari ini gacor</a>
  <a href="https://bom48.com/store/">36 coins rtp tinggi</a>
  <a href="https://bom48.com/store/">poker168 terpercaya</a>
  <a href="https://bom48.com/store/">data slot ovo mudah menang</a>
  <a href="https://bom48.com/store/">sangat slot gacor</a>
  <a href="https://bom48.com/store/">slot deposit mandiri gacor</a>
  <a href="https://bom48.com/store/">situs result togel tergacor</a>
  <a href="https://bom48.com/store/">september togel4d</a>
  <a href="https://bom48.com/store/">rabu sbobet login</a>
  <a href="https://bom48.com/store/">link result togel paling gacor</a>
  <a href="https://bom48.com/store/">tips sbobet88 paling gacor</a>
  <a href="https://bom48.com/store/">cara slot gopay online</a>
  <a href="https://bom48.com/store/">resmi slot paling gacor</a>
  <a href="https://bom48.com/store/">rtp wild west gold</a>
  <a href="https://bom48.com/store/">hasil poker deposit dana</a>
  <a href="https://bom48.com/store/">slot the dog house megaways deposit qris</a>
  <a href="https://bom48.com/store/">login slot44</a>
  <a href="https://bom48.com/store/">keluaran sbobet login paling gacor</a>
  <a href="https://bom48.com/store/">resmi slot thailand hari ini</a>
  <a href="https://bom48.com/store/">rtp slot starlight princess</a>
  <a href="https://bom48.com/store/">terpercaya result togel 2026</a>
  <a href="https://bom48.com/store/">cara menang dog house megaways</a>
  <a href="https://bom48.com/store/">togel online anti rungkad</a>
  <a href="https://bom48.com/store/">keluaran slot maxwin terlengkap</a>
  <a href="https://bom48.com/store/">pasang togel hari ini</a>
  <a href="https://bom48.com/store/">jp77 terpercaya</a>
  <a href="https://bom48.com/store/">login slot maxwin mudah menang</a>
  <a href="https://bom48.com/store/">daftar sbobet mobile no 1</a>
  <a href="https://bom48.com/store/">profit togel sgp</a>
  <a href="https://bom48.com/store/">platform slot mudah menang terbaru hari ini</a>
  <a href="https://bom48.com/store/">demo slot jili gacor</a>
  <a href="https://bom48.com/store/">pengeluaran taruhan tanpa potongan</a>
  <a href="https://bom48.com/store/">slot big bass splash 1000 terbaru</a>
  <a href="https://bom48.com/store/">trik betting mudah menang</a>
  <a href="https://bom48.com/store/">trik togel4d terbaik</a>
  <a href="https://bom48.com/store/">trik slot paling gacor</a>
  <a href="https://bom48.com/store/">situs slot deposit dana 10 ribu</a>
  <a href="https://bom48.com/store/">slot gacor gates of olympus super scatter</a>
  <a href="https://bom48.com/store/">slot dana server thailand</a>
  <a href="https://bom48.com/store/">bandar slot online deposit dana</a>
  <a href="https://bom48.com/store/">link judi slot 2024</a>
  <a href="https://bom48.com/store/">ganesha fortune slot</a>
  <a href="https://bom48.com/store/">referral bandar poker</a>
  <a href="https://bom48.com/store/">agen togel4d mudah menang</a>
  <a href="https://bom48.com/store/">koi gate rtp tinggi</a>
  <a href="https://bom48.com/store/">terpercaya judi bola 2025</a>
</div>
  <div id="wrap">
   <input id="searchDomain" name="searchDomain" type="hidden" value="https://bom48.com/store/"/>
   <input id="esapiSearchDomain" name="esapiSearchDomain" type="hidden" value="https://bom48.com/store/"/>
   <input id="scene7domain" name="scene7domain" type="hidden" value="//images.samsung.com/is/image/samsung/"/>
   <input id="reviewUseYN" name="reviewUseYN" type="hidden" value="Y"/>
   <input id="aplautYn" name="aplautYn" type="hidden" value="N"/>
   <input id="reevooUseYN" name="reevooUseYN" type="hidden" value="N"/>
   <input id="bvFlag" name="bvFlag" type="hidden" value="Y"/>
   <input id="bvRTLFlag" name="bvRTLFlag" type="hidden" value="N"/>
   <input id="multiLanguageYn" name="multiLanguageYn" type="hidden" value="N"/>
   <input id="localLang" name="localLang" type="hidden" value="id-id"/>
   <input id="runmodeInfo" name="runmodeInfo" type="hidden" value="live"/>
   <input id="apiStageInfo" name="apiStageInfo" type="hidden" value="front"/>
   <input id="tempTitle" name="tempTitle" type="hidden" value="page-buying-pd"/>
   <input id="siteCode" name="siteCode" type="hidden" value="id"/>
   <input id="store_sitecode" name="store_sitecode" type="hidden" value="id"/>
   <input id="language" name="language" type="hidden" value="in_ID"/>
   <input id="serverType" name="serverType" type="hidden" value="prod"/>
   <input id="gpvStoreDomain" name="gpvStoreDomain" type="hidden" value="https://bom48.com/store/"/>
   <input id="storeWebDomain" name="storeWebDomain" type="hidden" value="https://bom48.com/store/"/>
   <input id="shopIntegrationFlag" name="shopIntegrationFlag" type="hidden" value="Hybris-new"/>
   <input id="newHyvStoreDomain" name="newHyvStoreDomain" type="hidden"/>
   <input id="b2bFlag" name="b2bFlag" type="hidden" value="N"/>
   <input id="pageUrl" name="pageUrl" type="hidden"/>
   <input id="pathString" name="pathString" type="hidden"/>
   <input id="wishlistYn" name="wishlistYn" type="hidden"/>
   <input id="shopParmLang" name="shopParmLang" type="hidden"/>
   <input id="reservationDomain" name="reservationDomain" type="hidden"/>
   <section class="progress cm-loader" style="display:none;">
    <div class="progress__wrapper">
     <div class="progress__circle-1">
     </div>
     <div class="progress__circle-2">
     </div>
     <div class="progress__circle-3">
     </div>
     <div class="progress__circle-4">
     </div>
    </div>
   </section>
   <script src="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/global/js/crypto-js.min.6fa2276cf659f30cabde72a6fc452171.js">
   </script>
   <script src="https://account.samsung.com/resources/libs/account-internal/2.0.0/account-internal.min.js" type="text/javascript">
   </script>
   <header id="header" role="banner">
    <!--googleoff: all-->
    <div class="skip-bar">
     <a href="https://www.samsung.com/" id="skipToContent">
      Skip to content
     </a>
    </div>
   </header>
   <div class="newpar new section">
   </div>
   <div class="par iparys_inherited">
   </div>
   <aside class="nv16-country-selector" style="height: 0px;">
    <div class="nv16-country-selector__content-wrap">
     <div class="nv16-country-selector__content">
      <label class="nv16-country-selector__description" for="countrySelect">
       Pilih lokasi dan bahasa Anda.
      </label>
      <div class="nv16-country-selector__select-contaniner" data-country-codes="uk">
       <div class="nv16-country-selector__menu">
        <div class="menu" data-comp-name="menu">
         <select class="menu__select" id="countrySelect" tabindex="-1">
          <option data-country-type="sitecd" selected="" value="id">
           Indonesia / Bahasa Indonesia
          </option>
          <option data-country-type="location" value="uk">
           UK / English
          </option>
          <option lang="en" value="other">
           Other Countries
          </option>
         </select>
         <button an-ac="gnb" an-ca="navigation" an-la="country selector" an-tr="nv16_gnb-country selector-navigation" aria-expanded="false" aria-haspopup="listbox" class="menu__select-field" data-aria-label="Pilih lokasi dan bahasa Anda." type="button">
          <span class="menu__select-field-text">
          </span>
          <svg aria-hidden="true" class="menu__select-field-icon down" focusable="false">
           <use href="#open-down-bold" xlink:href="#open-down-bold">
           </use>
          </svg>
          <svg aria-hidden="true" class="menu__select-field-icon up" focusable="false">
           <use href="#close-up-bold" xlink:href="#close-up-bold">
           </use>
          </svg>
         </button>
        </div>
       </div>
       <div class="nv16-country-selector__continue">
        <button an-ac="gnb" an-ca="navigation" an-la="country selector:continue" an-tr="nv16_gnb-country selector-navigation" class="cta cta--contained cta--black" data-action="countrySelectorContinue">
         Lanjutkan
        </button>
       </div>
      </div>
      <button class="nv16-country-selector__close" data-action="countrySelectorClose">
       <span class="hidden">
        Tutup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </aside>
   <!-- COD05_Mobile App Download Banner #-->
   <aside class="cod05-app-banner" style="display:none">
   </aside>
   <!-- //COD05_Mobile App Download Banner #-->
   <input id="st_checked" name="st_checked" type="hidden" value="2025-11-28 05:05:40"/>
   <input id="cck" name="cck" type="hidden" value="cedc6238tqcf1t4f0vl7g50mc70d6a5a"/>
   <input id="gPriceCurrency" name="gPriceCurrency" type="hidden" value="IDR"/>
   <input id="pageTrack" name="pageTrack" type="hidden" value="product detail"/>
   <nav aria-label="main navigation" class="nv00-gnb-v4 nv00-gnb-v4--text-type" id="component-id" role="navigation">
    <div class="nv00-gnb-v4__wrap">
     <div class="nv00-gnb-v4__inner">
      <div class="nv00-gnb-v4__header">
       <a an-ac="gnb" an-ca="navigation" an-la="RODA37 | Roda 37" an-tr="nv00_gnb-product detail-l0-navigation2" aria-label="RODA37 | Roda 37" class="nv00-gnb-v4__logo" href="https://bom48.com/store/">
        <img src="https://cdn.image-ku.art/assetsmaya/logomaya.png" alt="RODA37 | Roda 37" width="200" height="56"/>
       </a>
       <div class="nv00-gnb-v4__utility-list nv00-gnb-v4--mobile-only">
        <button an-ac="gnb" an-ca="navigation" an-la="search" an-tr="nv00_gnb-product detail-l0-navigation2" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-search gnb__search-btn-js" data-js-action="search">
         <span class="hidden">
          Cari
         </span>
         <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
          <path d="M85.732,89.269v0L60.479,64.018A36.5,36.5,0,1,1,22.295,2.869,36.5,36.5,0,0,1,64.02,60.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo.762,7.476,31.316,31.316,0,0,0,36.5,5Z" transform="translate(3.366 3.366)">
          </path>
         </svg>
         <span aria-hidden="true" class="nv00-gnb-v4__search-text">
          Cari
         </span>
        </button>
        <a an-ac="gnb" an-ca="navigation" an-la="cart" an-tr="nv00_gnb-product detail-gnb cart icon-navigation6" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-cart nv00-gnb-v4__utility-btn js-global-cart-btn js-has-carturl" role="button">
         <span class="hidden">
          Troli
         </span>
         <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
          <g clip-path="url(#clip-path)" transform="translate(-625.251 -196)">
           <path d="M697.237,263.578a10,10,0,1,1-10,10A10,10,0,0,1,697.237,263.578Zm-34.944,0a10,10,0,1,1-10,10A10,10,0,0,1,662.293,263.578Zm34.944,5a5,5,0,1,0,5,5A5,5,0,0,0,697.237,268.578Zm-34.944,0a5,5,0,1,0,5,5A5,5,0,0,0,662.293,268.578ZM638.1,197.25a3.86,3.86,0,0,1,3.6,2.652l.052.184,3.208,12.292h70.036a3.224,3.224,0,0,1,3.192,3.916l-.04.18-9.4,36.292a3.86,3.86,0,0,1-3.46,2.832l-.2.008h-51.1a3.866,3.866,0,0,1-3.6-2.648l-.052-.188-13.192-50.516-11.612,0,0-5Zm74.648,20.128h-66.48l8.672,33.228h49.2Z" transform="translate(0.834 3.75)">
           </path>
          </g>
         </svg>
         <span aria-live="polite" class="cart-in-number gnb-cart-count" style="display:none;">
          <span class="hidden">
           Number of Products :
          </span>
         </span>
        </a>
        <a an-ac="gnb" an-ca="account" an-la="login" an-tr="nv00_gnb-product detail-account-account" aria-label="Login/Sign-Up" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-user before-login loginBtn">
         <span class="hidden">
          Login
         </span>
         <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
          <path d="M48,51.5c16.521,0,30.5,13.82,30.5,29.555h0V89A3.5,3.5,0,0,1,75,92.5H21A3.5,3.5,0,0,1,17.5,89h0V81.055C17.5,65.32,31.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo-25.087-24.552h0Zm0-53A20.5,20.5,0,1,1,27.5,24,20.5,20.5,0,0,1,48,3.5Zm0,5A15.5,15.5,0,1,0,63.5,24,15.5,15.5,0,0,0,48,8.5Z" transform="translate(-0.5 0.5)">
          </path>
         </svg>
        </a>
        <a class="nv00-gnb-v4__utility nv00-gnb-v4__utility-user after-login js-user-name js-account" data-js-action="user">
         <span class="hidden">
          Buka Menu Saya
         </span>
         <div class="image nv00-gnb-v4__user-profile js-gnb-afterlogin-image">
          <img alt="[D] Alternative Text" class="image__main" data-comp-name="image" role="img" src="#"/>
         </div>
         <svg aria-hidden="true" class="icon nv00-gnb-v4__user-icon js-gnb-afterlogin-no-image" focusable="false" height="96" viewbox="0 0 96 96" width="96">
          <path d="M48,51.5c16.521,0,30.5,13.82,30.5,29.555h0V89A3.5,3.5,0,0,1,75,92.5H21A3.5,3.5,0,0,1,17.5,89h0V81.055C17.5,65.32,31.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo-25.087-24.552h0Zm0-53A20.5,20.5,0,1,1,27.5,24,20.5,20.5,0,0,1,48,3.5Zm0,5A15.5,15.5,0,1,0,63.5,24,15.5,15.5,0,0,0,48,8.5Z" transform="translate(-0.5 0.5)">
          </path>
         </svg>
        </a>
        <button an-ac="gnb" an-ca="navigation" an-la="gnb:open" an-tr="nv00_gnb-product detail-gnb open / close-navigation2" aria-expanded="false" aria-haspopup="true" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-hamburger" data-js-action="hamburger">
         <span class="hidden">
          Navigation
         </span>
         <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
          <path d="M0,57V52H70v5ZM0,31V26H70v5ZM0,5V0H70V5Z" transform="translate(13 20)">
          </path>
         </svg>
        </button>
       </div>
      </div>
      <div class="nv00-gnb-v4__container">
       <div class="nv00-gnb-v4__container-header nv00-gnb-v4--mobile-only">
        <button class="nv00-gnb-v4__backward-btn">
         <span class="hidden">
          Kembali
         </span>
         <svg aria-hidden="true" class="icon" focusable="false">
          <use href="#previous-regular" xlink:href="#previous-regular">
          </use>
         </svg>
        </button>
        <button an-ac="gnb" an-ca="navigation" an-la="search" an-tr="nv00_gnb-product detail-l0-navigation5" aria-expanded="false" aria-haspopup="true" class="nv00-gnb-v4__search gnb__search-btn-js" data-js-action="search">
         <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
          <path d="M85.732,89.269v0L60.479,64.018A36.5,36.5,0,1,1,22.295,2.869,36.5,36.5,0,0,1,64.02,60.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo.762,7.476,31.316,31.316,0,0,0,36.5,5Z" transform="translate(3.366 3.366)">
          </path>
         </svg>
         <span class="nv00-gnb-v4__search-text">
          Cari
         </span>
        </button>
       </div>
       <div class="nv00-gnb-v4__container-inner">
        <p class="nv00-gnb-v4__l0-menu-list-title nv00-gnb-v4--mobile-only">
         SHOP BY CATEGORY
        </p>
        <ul aria-label="main menu" class="nv00-gnb-v4__l0-menu-list nv00-gnb-v4__l0-menu-list--left" role="menubar">
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <a an-ac="gnb" an-ca="navigation" an-la="shop" an-tr="nv00_gnb-product detail-l0-navigation2" class="nv00-gnb-v4__l0-menu-link" data-js-action="l0MenuBtn" href="https://bom48.com/store/" role="menuitem">
            <span class="nv00-gnb-v4__l0-menu-text nv00-gnb-v4--pc-only">
            RODA37 | Roda 37
            </span>
           </a>
          </div>
         </li>
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <a an-ac="gnb" an-ca="navigation" an-la="mobile" an-tr="nv00_gnb-product detail-l0-navigation2" class="nv00-gnb-v4__l0-menu-link" data-js-action="l0MenuBtn" href="https://bom48.com/store/" role="menuitem">
            <span class="nv00-gnb-v4__l0-menu-text">
             SLOT GACOR
            </span>
           </a>
          </div>
         </li>
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <a an-ac="gnb" an-ca="navigation" an-la="tv and av" an-tr="nv00_gnb-product detail-l0-navigation2" class="nv00-gnb-v4__l0-menu-link" data-js-action="l0MenuBtn" href="https://bom48.com/store/" role="menuitem">
            <span class="nv00-gnb-v4__l0-menu-text">
             SITUS SLOT GACOR
            </span>
           </a>
          </div>
         </li>
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <a an-ac="gnb" an-ca="navigation" an-la="appliances" an-tr="nv00_gnb-product detail-l0-navigation2" class="nv00-gnb-v4__l0-menu-link" data-js-action="l0MenuBtn" href="https://bom48.com/store/" role="menuitem">
            <span class="nv00-gnb-v4__l0-menu-text">
             SLOT GACOR MAXWIN
            </span>
           </a>
          </div>
         </li>
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <a an-ac="gnb" an-ca="navigation" an-la="monitors" an-tr="nv00_gnb-product detail-l0-navigation2" class="nv00-gnb-v4__l0-menu-link" data-js-action="l0MenuBtn" href="https://bom48.com/store/" role="menuitem">
            <span class="nv00-gnb-v4__l0-menu-text">
             SLOT GACOR HARI INI
            </span>
           </a>
          </div>
         </li>
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <a an-ac="gnb" an-ca="navigation" an-la="wearables" an-tr="nv00_gnb-product detail-l0-navigation2" class="nv00-gnb-v4__l0-menu-link" data-js-action="l0MenuBtn" href="https://bom48.com/store/" role="menuitem">
            <span class="nv00-gnb-v4__l0-menu-text">
             SLOT ONLINE
            </span>
           </a>
          </div>
         </li>
        </ul>
        <ul aria-label="main menu" class="nv00-gnb-v4__l0-menu-list nv00-gnb-v4__l0-menu-list--right" role="menubar">
         <!-- Type E Support Start -->
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <a an-ac="gnb" an-ca="navigation" an-la="SLOT" an-tr="nv00_gnb-product detail-banner-navigation2" aria-label="SLOT" class="nv00-gnb-v4__l0-menu-link" data-js-action="l0MenuBtn" href="https://clik.is/yugentoto" rel="nofollow" role="menuitem" target="_blank">
            LOGIN
           </a>
          </div>
         </li>
         
         <li class="nv00-gnb-v4__l0-menu">
          <div class="nv00-gnb-v4__l0-menu-title">
           <a an-ac="gnb" an-ca="navigation" an-la="RODA37 | Roda 37 DAFTAR" an-tr="nv00_gnb-product detail-banner-navigation2" aria-label="RODA37 | Roda 37 DAFTAR" class="nv00-gnb-v4__l0-menu-link" data-js-action="l0MenuBtn" href="https://clik.is/yugentoto" rel="nofollow" role="menuitem" target="_blank">
            DAFTAR
           </a>
          </div>
         </li>
         <!-- Non-Type Right Menu End -->
        </ul>
        <div class="nv00-gnb-v4__user-menu-list nv00-gnb-v4--mobile-only after-login">
         <a an-ac="gnb" an-ca="account" an-la="user name" an-tr="nv00_gnb-product detail-account-account" aria-label="Go to the another page" class="nv00-gnb-v4__user-menu js-user-name js-account" href="javascript:;" role="menuitem">
          <div class="image nv00-gnb-v4__user-profile js-gnb-afterlogin-image">
           <img alt="" class="image__main" data-comp-name="image" role="img" src="#"/>
          </div>
          <svg aria-hidden="true" class="icon nv00-gnb-v4__user-icon js-gnb-afterlogin-no-image" focusable="false" height="96" viewbox="0 0 96 96" width="96">
           <path d="M48,51.5c16.521,0,30.5,13.82,30.5,29.555h0V89A3.5,3.5,0,0,1,75,92.5H21A3.5,3.5,0,0,1,17.5,89h0V81.055C17.5,65.32,31.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo-25.087-24.552h0Zm0-53A20.5,20.5,0,1,1,27.5,24,20.5,20.5,0,0,1,48,3.5Zm0,5A15.5,15.5,0,1,0,63.5,24,15.5,15.5,0,0,0,48,8.5Z" transform="translate(-0.5 0.5)">
           </path>
          </svg>
          <p class="user-name">
          </p>
          <p class="hidden">
           Buka Menu Saya
          </p>
         </a>
         <a an-ac="gnb" an-ca="account" an-la="rewards" an-tr="nv00_gnb-account-account" aria-label="Receive up to 5% of your purchase back in points. Samsung Rewards" class="nv00-gnb-v4__user-menu nv00-gnb-v4__user-menu--icon" href="https://bom48.com/store/" role="menuitem">
          Receive up to 5% of your purchase back in points.
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#next-regular" xlink:href="#next-regular">
           </use>
          </svg>
         </a>
        </div>
        <div class="nv00-gnb-v4__utility-list">
         <button an-ac="gnb" an-ca="navigation" an-la="search" an-tr="nv00_gnb-product detail-navigation2" aria-expanded="false" aria-haspopup="true" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-search gnb__search-btn-js" data-js-action="search">
          <span class="hidden">
           Cari
          </span>
          <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
           <path d="M85.732,89.269v0L60.479,64.018A36.5,36.5,0,1,1,22.295,2.869,36.5,36.5,0,0,1,64.02,60.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo.762,7.476,31.316,31.316,0,0,0,36.5,5Z" transform="translate(3.366 3.366)">
           </path>
          </svg>
          <span aria-hidden="true" class="nv00-gnb-v4__search-text">
           Cari
          </span>
         </button>
         <a an-ac="gnb" an-ca="navigation" an-la="cart" an-tr="nv00_gnb-product detail-gnb cart icon-navigation6" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-cart nv00-gnb-v4__utility-btn js-global-cart-btn js-has-carturl"  role="button">
          <span class="hidden">
           Troli
          </span>
          <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
           <g clip-path="url(#clip-path)" transform="translate(-625.251 -196)">
            <path d="M697.237,263.578a10,10,0,1,1-10,10A10,10,0,0,1,697.237,263.578Zm-34.944,0a10,10,0,1,1-10,10A10,10,0,0,1,662.293,263.578Zm34.944,5a5,5,0,1,0,5,5A5,5,0,0,0,697.237,268.578Zm-34.944,0a5,5,0,1,0,5,5A5,5,0,0,0,662.293,268.578ZM638.1,197.25a3.86,3.86,0,0,1,3.6,2.652l.052.184,3.208,12.292h70.036a3.224,3.224,0,0,1,3.192,3.916l-.04.18-9.4,36.292a3.86,3.86,0,0,1-3.46,2.832l-.2.008h-51.1a3.866,3.866,0,0,1-3.6-2.648l-.052-.188-13.192-50.516-11.612,0,0-5Zm74.648,20.128h-66.48l8.672,33.228h49.2Z" transform="translate(0.834 3.75)">
            </path>
           </g>
          </svg>
          <span aria-live="polite" class="cart-in-number gnb-cart-count" style="display:none;">
           <span class="hidden">
            Number of Products :
           </span>
          </span>
         </a>
         <div class="nv00-gnb-v4__utility-wrap before-login">
          <button an-ac="gnb" an-ca="navigation" an-la="login" an-tr="nv00_gnb-product detail-l0-navigation2" aria-expanded="false" aria-label="Manage Account" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-user" data-js-action="user">
           <span class="hidden">
            Login/Sign-Up
           </span>
           <svg aria-hidden="true" class="icon" focusable="false" height="96" viewbox="0 0 96 96" width="96">
            <path d="M48,51.5c16.521,0,30.5,13.82,30.5,29.555h0V89A3.5,3.5,0,0,1,75,92.5H21A3.5,3.5,0,0,1,17.5,89h0V81.055C17.5,65.32,31.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo-25.087-24.552h0Zm0-53A20.5,20.5,0,1,1,27.5,24,20.5,20.5,0,0,1,48,3.5Zm0,5A15.5,15.5,0,1,0,63.5,24,15.5,15.5,0,0,0,48,8.5Z" transform="translate(-0.5 0.5)">
            </path>
           </svg>
          </button>
          <div aria-label="account" class="nv00-gnb-v4__utility-menu-list" role="menu">
          </div>
         </div>
         <div class="nv00-gnb-v4__utility-wrap after-login">
          <button an-ac="gnb" an-ca="account" an-la="user name" an-tr="gnb-account, cart-product detail-account-account" aria-expanded="false" aria-label="Go to the another page" class="nv00-gnb-v4__utility nv00-gnb-v4__utility-user" data-js-action="user" role="button">
           <span class="hidden">
            Buka Menu Saya
           </span>
           <div class="image nv00-gnb-v4__user-profile js-gnb-afterlogin-image">
            <img alt="[D] Alternative Text" class="image__main" data-comp-name="image" role="img" src="#"/>
           </div>
           <svg aria-hidden="true" class="icon nv00-gnb-v4__user-icon js-gnb-afterlogin-no-image" focusable="false" height="96" viewbox="0 0 96 96" width="96">
            <path d="M48,51.5c16.521,0,30.5,13.82,30.5,29.555h0V89A3.5,3.5,0,0,1,75,92.5H21A3.5,3.5,0,0,1,17.5,89h0V81.055C17.5,65.32,31.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo-25.087-24.552h0Zm0-53A20.5,20.5,0,1,1,27.5,24,20.5,20.5,0,0,1,48,3.5Zm0,5A15.5,15.5,0,1,0,63.5,24,15.5,15.5,0,0,0,48,8.5Z" transform="translate(-0.5 0.5)">
            </path>
           </svg>
          </button>
          <div aria-label="account" class="nv00-gnb-v4__utility-menu-list" role="menu">
           <div class="nv00-gnb-v4__utility-menu-wrap">
            <a an-ac="gnb" an-ca="account" an-la="user name" an-tr="gnb-account, cart-product detail-account-account" aria-label="Go to the another page" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu--user-profile nv00-gnb-v4--pc-only js-user-name js-account" href="javascript:;" role="menuitem">
             <div class="image nv00-gnb-v4__user-profile js-gnb-afterlogin-image">
              <img alt="[D] Alternative Text" class="image__main" data-comp-name="image" role="img" src="#"/>
             </div>
             <svg aria-hidden="true" class="icon nv00-gnb-v4__user-icon js-gnb-afterlogin-no-image" focusable="false" height="96" viewbox="0 0 96 96" width="96">
              <path d="M48,51.5c16.521,0,30.5,13.82,30.5,29.555h0V89A3.5,3.5,0,0,1,75,92.5H21A3.5,3.5,0,0,1,17.5,89h0V81.055C17.5,65.32,31.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo-25.087-24.552h0Zm0-53A20.5,20.5,0,1,1,27.5,24,20.5,20.5,0,0,1,48,3.5Zm0,5A15.5,15.5,0,1,0,63.5,24,15.5,15.5,0,0,0,48,8.5Z" transform="translate(-0.5 0.5)">
              </path>
             </svg>
             <p class="user-name">
             </p>
            </a>
            <a class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu--with-icon nv00-gnb-v4--pc-only" href="https://bom48.com/store/" role="menuitem">
             Receive up to 5% of your purchase back in points.
             <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#next-regular" xlink:href="#next-regular">
              </use>
             </svg>
            </a>
            <a an-ac="gnb" an-ca="account" an-la="my page" an-tr="nv00_gnb-product detail-account-account" aria-label="my page" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="https://www.samsung.com/" role="menuitem">
             Halaman&nbsp;Saya
            </a>
            <a an-ac="gnb" an-ca="account" an-la="orders" an-tr="nv00_gnb-product detail-account-account" aria-label="orders" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="https://www.samsung.com/" role="menuitem">
             Pesanan
            </a>
            <a an-ac="gnb" an-ca="account" an-la="product registration" an-tr="nv00_gnb-product detail-account-account" aria-label="product registration" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="https://www.samsung.com/" role="menuitem">
             Product&nbsp;Registration
            </a>
            <a an-ac="gnb" an-ca="account" an-la="my rewards" an-tr="nv00_gnb-product detail-account-account" aria-label="my rewards" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="https://www.samsung.com/" role="menuitem">
             Rewards&nbsp;Saya
            </a>
            <a an-ac="gnb" an-ca="account" an-la="wishlist" an-tr="nv00_gnb-product detail-account-account" aria-label="wishlist" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="https://www.samsung.com/" role="menuitem">
             Wishlist
            </a>
            <a an-ac="gnb" an-ca="account" an-la="members" an-tr="nv00_gnb-product detail-account-account" aria-label="members" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="https://www.samsung.com/" role="menuitem">
             Members
            </a>
            <a an-ac="gnb" an-ca="account" an-la="community" an-tr="nv00_gnb-product detail-account-account" aria-label="community" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu" href="https://www.samsung.com/" role="menuitem">
             Komunitas
            </a>
            <a an-ac="gnb" an-ca="account" an-la="logout" an-tr="nv00_gnb-product detail-account-account" aria-label="logout" class="nv00-gnb-v4__utility-menu nv00-gnb-v4__utility-menu logoutBtn" href="javascript:;" role="menuitem">
             Keluar
            </a>
           </div>
          </div>
         </div>
        </div>
       </div>
       <button an-ac="gnb" an-ca="navigation" an-la="gnb:close" an-tr="nv00_gnb-product detail-gnb open / close-navigation2" class="nv00-gnb-v4__close-btn">
        <span class="hidden">
         Close menu
        </span>
        <svg aria-hidden="true" class="icon" focusable="false">
         <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
         </use>
        </svg>
       </button>
      </div>
     </div>
    </div>
    <div class="nv00-gnb-v4__dim">
    </div>
    <form action="https://www.samsung.com/" id="signInForm" method="get" name="signInForm">
     <input id="response_type" name="response_type" type="hidden" value=""/>
     <input name="client_id" type="hidden" value="5kuj08631q"/>
     <input id="locale" name="locale" type="hidden" value=""/>
     <input name="countryCode" type="hidden" value="ID"/>
     <input id="redirect_uri" name="redirect_uri" type="hidden" value="/aemapi/v6/data-login/afterLogin.id.json"/>
     <input id="signInState" name="state" type="hidden" value=""/>
     <input id="signInGoBackURL" name="goBackURL" type="hidden" value=""/>
     <input id="scope" name="scope" type="hidden" value=""/>
    </form>
    <!-- SA 로그아웃호출 폼 -->
    <form action="https://www.samsung.com/" id="signOutForm" method="get" name="signOutForm">
     <input name="client_id" type="hidden" value="5kuj08631q"/>
     <input id="signOutState" name="state" type="hidden" value=""/>
     <input id="signOutURL" name="signOutURL" type="hidden" value="/aemapi/v6/data-login/afterLogout.id.json"/>
    </form>
    <!-- 회원가입 폼 -->
    <form action="https://www.samsung.com/" id="joinForm" method="post" name="joinForm">
     <input name="actionID" type="hidden" value="SignupAP"/>
     <input name="serviceID" type="hidden" value="5kuj08631q"/>
     <input name="serviceName" type="hidden" value="RODA37 | Roda 37"/>
     <input name="domain" type="hidden" value="vanreedinn.com"/>
     <input name="countryCode" type="hidden" value="ID"/>
     <input name="languageCode" type="hidden" value="id"/>
     <input id="joinRegistURL" name="registURL" type="hidden" value="/aemapi/v6/data-login/afterLogin.id.json"/>
     <input id="joinReturnURL" name="returnURL" type="hidden"/>
     <input id="joinGoBackURL" name="goBackURL" type="hidden" value=""/>
     <input name="ssoType" type="hidden" value="ENC_TK"/>
     <input id="joinEmailActivationURL" name="emailActivationURL" type="hidden" value="/aemapi/v6/data-login/emailActivationURL.id.json"/>
    </form>
    <!-- Find Email 폼 -->
    <form action="https://www.samsung.com/" id="findAccountForm" method="post" name="findAccountForm">
     <input name="actionID" type="hidden" value="FindEmail"/>
     <input name="serviceID" type="hidden" value="5kuj08631q"/>
     <input name="serviceName" type="hidden" value="slot"/>
     <input name="domain" type="hidden" value="vanreedinn.com"/>
     <input name="countryCode" type="hidden" value="ID"/>
     <input name="languageCode" type="hidden" value="id"/>
     <input id="findGoBackURL" name="goBackURL" type="hidden" value=""/>
     <input name="ssoType" type="hidden" value="ENC_TK"/>
    </form>
    <!-- Account Modify Form -->
    <form action="https://www.samsung.com/" id="accountModifyForm" method="post" name="accountModifyForm">
     <input name="actionID" type="hidden" value="ModifyUserInfo"/>
     <input name="serviceID" type="hidden" value="5kuj08631q"/>
     <input name="serviceName" type="hidden" value="slot gacor"/>
     <input name="domain" type="hidden" value="vanreedinn.com"/>
     <input name="countryCode" type="hidden" value="ID"/>
     <input name="languageCode" type="hidden" value="id"/>
     <input id="accountModifyGoBackURL" name="goBackURL" type="hidden" value=""/>
     <input name="ssoType" type="hidden" value="ENC_TK"/>
    </form>
    <form id="textForm" name="textForm">
     <input id="productCountText" name="productCountText" type="hidden" value="Jumlah Produk"/>
    </form>
    <input id="domain" name="domain" type="hidden" value="www.samsung.com"/>
    <input id="useLogin" name="useLogin" type="hidden" value="Y"/>
    <input id="useStore" name="useStore" type="hidden" value="Y"/>
    <input id="storeDomain" name="storeDomain" type="hidden" value="https://www.samsung.com/"/>
    <input id="hybrisApiJson" name="hybrisApiJson" type="hidden"/>
    <input id="addToCartPostYn" name="addToCartPostYn" type="hidden" value="Y"/>
    <input id="tokocommercewebservicesYn" name="tokocommercewebservicesYn" type="hidden"/>
    <input id="useNewAddToCartApi" name="useNewAddToCartApi" type="hidden" value="Y"/>
    <input id="loginLinkURL" name="loginLinkURL" type="hidden" value="https://www.samsung.com/"/>
    <input id="logoutURL" name="logoutURL" type="hidden" value="https://www.samsung.com/"/>
    <input id="updateProfileURL" name="updateProfileURL" type="hidden"/>
    <input id="isLoginWithNoStore" name="isLoginWithNoStore" type="hidden"/>
    <input id="countryCode" name="countryCode" type="hidden" value="ID"/>
    <input id="languageCode" name="languageCode" type="hidden" value="id"/>
    <input id="loginAccountServiceId" name="loginAccountServiceId" type="hidden" value="5kuj08631q"/>
    <input id="emailActivationURL" name="emailActivationURL" type="hidden" value="/aemapi/v6/data-login/emailActivationURL.id.json"/>
    <input id="shopIntegrationFlag" name="shopIntegrationFlag" type="hidden" value="Hybris-new"/>
    <input id="tieredPriceUseYn" name="tieredPriceUseYn" type="hidden"/>
    <input id="mySamsungRewardsTierType" name="mySamsungRewardsTierType" type="hidden" value="global"/>
    <input id="newMyRewardCurrencyConv" name="newMyRewardCurrencyConv" type="hidden" value="1.000"/>
    <input id="countryIsoCode" name="countryIsoCode" type="hidden" value="IDN"/>
    <input id="loginValidateYnForGPv2" name="loginValidateYnForGPv2" type="hidden" value=""/>
    <div class="nv00-gnb-v4__layer-popup-wrap">
     <div class="nv00-gnb-v4__layer-popup-looping--start" tabindex="0">
     </div>
     <div class="layer-popup gnb-layer_popup-js" id="layerEmptyCart">
      <svg aria-hidden="true" class="icon" focusable="false">
       <use href="#info-regular" xlink:href="#info-regular">
       </use>
      </svg>
      <p class="layer-popup__desc information-text">
       Keranjang belanja Anda kosong
      </p>
      <div class="layer-popup__cta-wrap">
       <button an-ac="cart is empty:OK" an-ca="other interaction" an-la="cart is empty:OK" an-tr="nv00_gnb-product detail-cart popup-other_interaction" aria-label="Accessibility Text" class="cta cta--contained cta--black gnb-js-layer-close" onclick="window.sg.components.Nv00GnbV4.closeLayerPopup(this);">
        OK
       </button>
      </div>
      <button class="layer-popup__close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
     <div class="layer-popup gnb-layer_popup-js" id="layerInsufficientStock">
      <svg aria-hidden="true" class="icon" focusable="false">
       <use href="#info-regular" xlink:href="#info-regular">
       </use>
      </svg>
      <p class="layer-popup__desc information-text">
       Maaf, persediaan barang di keranjang belanja tidak cukup.
      </p>
      <div class="layer-popup__cta-wrap">
       <button aria-label="Accessibility Text" class="cta cta--contained cta--black gnb-js-layer-close" onclick="window.sg.components.Nv00GnbV4.closeLayerPopup(this);">
        OK
       </button>
      </div>
      <button class="layer-popup__close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
     <div class="layer-popup gnb__remove-product gnb-layer_popup-js" id="layerRemoveProduct">
      <p class="layer-popup__title">
       Hapus produk
      </p>
      <p class="layer-popup__desc">
       Tanpa produk ini, kupon atau kode promo yang berlaku tidak dapat ditukarkan.
       <br/>
       Anda yakin ingin menghapus produk ini?
      </p>
      <div class="layer-popup__cta-wrap">
       <button aria-label="Accessibility Text" class="cta cta--outlined cta--black">
        Pindahkan ke wishlist
       </button>
       <button aria-label="Accessibility Text" class="cta cta--contained cta--black">
        Hapus
       </button>
      </div>
      <button class="layer-popup__close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
     <div class="layer-popup gnb-layer_popup-js gnb__popup-privacy" id="layerPrivacy">
      <p class="layer-popup__title">
       Privacy Policy
      </p>
      <div class="layer-popup__checkbox-wrap">
       <div class="checkbox-v2">
        <input class="checkbox-v2__input" id="privacy-terms" name="checkbox" type="checkbox"/>
        <label class="checkbox-v2__label" for="privacy-terms">
         <span class="checkbox-v2__label-box-wrap">
          <span class="checkbox-v2__label-box">
           <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
            <use href="#done-bold" xlink:href="#done-bold">
            </use>
           </svg>
          </span>
         </span>
         <span class="checkbox-v2__label-text">
          Saya telah membaca dan setuju dengan
          <a class="link-text" href="https://www.samsung.com/" target="_blank" title="Buka di Tab Baru">
           Kebijakan Privasi
          </a>
          Samsung.com
         </span>
        </label>
       </div>
       <p class="layer-popup__checkbox-desc error" id="errorPrivacy">
        Centang kotak ini untuk melanjutkan ke Samsung.com.
       </p>
       <div class="checkbox-v2">
        <input class="checkbox-v2__input" id="privacy-terms2" name="checkbox" type="checkbox"/>
        <label class="checkbox-v2__label" for="privacy-terms2">
         <span class="checkbox-v2__label-box-wrap">
          <span class="checkbox-v2__label-box">
           <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
            <use href="#done-bold" xlink:href="#done-bold">
            </use>
           </svg>
          </span>
         </span>
         <span class="checkbox-v2__label-text">
          Dengan mencentang kotak ini, berarti saya bersedia menerima Pembaruan Layanan Samsung, termasuk:
         </span>
        </label>
       </div>
       <p class="layer-popup__checkbox-desc">
        Layanan dan informasi pemasaran Samsung.com, berikut produk baru dan pengumuman layanan serta penawaran khusus, peristiwa dan buletin berkalanya.
       </p>
      </div>
      <div class="layer-popup__cta-wrap">
       <button aria-label="Accessibility Text" class="cta cta--outlined cta--black" id="privacyBtn">
        MELANJUTKAN KE SAMSUNG.COM
       </button>
       <button aria-label="Accessibility Text" class="cta cta--contained cta--black login-leave-btn" onclick="window.sg.components.Nv00GnbV4.closeLayerPopup(this);">
        TINGGALKAN HALAMAN INI
       </button>
      </div>
      <button class="layer-popup__close login-leave-btn" data-focus-id="shop-popover-close" data-tab-disable="true">
       <span class="hidden">
        Tutup Kebijakan Privasi
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
     <div class="layer-popup gnb__popup-privacy gnb-layer_popup-js" id="layerPreference">
      <p class="layer-popup__title">
       Periksa Preferensi
      </p>
      <p class="layer-popup__desc">
       Berikan rekomendasi untuk memperbaharui preferensi produk Anda.
      </p>
      <div class="layer-popup__cta-wrap">
       <button aria-label="Accessibility Text" class="cta cta--outlined cta--black" id="preferenceCheckBtn">
        YA
       </button>
       <button aria-label="Accessibility Text" class="cta cta--contained cta--black" id="privacyCloseBtn" onclick="window.sg.components.Nv00GnbV4.closeLayerPopup(this);">
        NANTI
       </button>
      </div>
      <button class="layer-popup__close" data-focus-id="shop-popover-close" data-tab-disable="true">
       <span class="hidden">
        Tutup Preferensi
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
     <div class="nv00-gnb-v4__layer-popup-looping--end" tabindex="0">
     </div>
    </div>
   </nav>
   <input id="sc_gnb_searchURL" name="sc_gnb_searchURL" type="hidden" value="/id/aisearch"/>
   <input id="sc_gnb_AI_searchURL" name="sc_gnb_AI_searchURL" type="hidden" value="/id/aisearch"/>
   <input id="sc_gnb_placeholder" name="sc_gnb_placeholder" type="hidden" value="Galaxy Z Fold7"/>
   <input id="sc_gnb_aiSearchUseYn" name="sc_gnb_aiSearchUseYn" type="hidden" value="Y"/>
   <input id="sc_gnb_bdcApiUseYn" name="sc_gnb_bdcApiUseYn" type="hidden" value="Y"/>
   <input id="sc_gnb_AiLoginUseYn" name="sc_gnb_AiLoginUseYn" type="hidden" value="N"/>
   <input id="sc_gnb_eppUseGnbAiSearchYn" name="sc_gnb_eppUseGnbAiSearchYn" type="hidden"/>
   <input id="eppFlag" name="eppFlag" type="hidden" value="N"/>
   <section aria-modal="true" class="srd19-gnb-search" role="dialog">
    <div class="srd19-gnb-search__looping--start" tabindex="0">
    </div>
    <div class="srd19-gnb-search__contents">
     <form action="#" autocomplete="off" class="srd19-gnb-search__form" role="search">
      <fieldset>
       <legend>
        Search Form
       </legend>
       <button aria-label="Cari" class="srd19-gnb-search__btn-search" type="submit">
        <svg class="icon" focusable="false">
         <use href="#search-regular" xlink:href="#search-regular">
         </use>
        </svg>
       </button>
       <div class="srd19-gnb-search__input-wrap">
        <input aria-label="Cari" class="srd19-gnb-search__input" id="gnb-search-keyword" name="search" placeholder="Cari" type="text"/>
       </div>
       <button an-ac="search layer" an-ca="search" an-la="clear" an-tr="srd19_gnb search-product detail-delete-search" class="srd19-gnb-search__clear" type="button">
        <span class="text">
         Kosongkan
        </span>
       </button>
       <button class="srd19-gnb-search__scan-barcode srd19-gnb-search__scan-barcode--hide" type="button">
        <span class="hidden">
         Scan Barcode
        </span>
        <svg aria-hidden="true" class="icon" focusable="false">
         <use href="#barcode-regular" xlink:href="#barcode-regular">
         </use>
        </svg>
       </button>
      </fieldset>
     </form>
     <div class="srd19-gnb-search__result-wrap">
      <div class="srd19-gnb-search__result">
       <div class="srd19-gnb-search__searches">
        <div class="srd19-gnb-search__list-wrap srd19-gnb-search__no-suggestions srd19-gnb-search__list-wrap--hide">
         <div class="srd19-gnb-search__list-title-wrap">
          <p class="srd19-gnb-search__list-title" id="search-list-label">
           Tidak Ada Saran
          </p>
         </div>
        </div>
        <div class="srd19-gnb-search__list-wrap srd19-gnb-search__ai-search srd19-gnb-search__list-wrap--hide">
         <div class="srd19-gnb-search__list-title-wrap">
          <p class="srd19-gnb-search__list-title" id="search-list-label">
           AI Suggested Searches
          </p>
         </div>
         <ul aria-labelledby="search-list-label" class="srd19-gnb-search__list" role="list">
         </ul>
        </div>
        <div class="srd19-gnb-search__list-wrap srd19-gnb-search__suggested srd19-gnb-search__list-wrap--hide">
         <div class="srd19-gnb-search__list-title-wrap">
          <p class="srd19-gnb-search__list-title" id="search-list-label">
           Pencarian yang Disarankan
          </p>
         </div>
         <ul aria-labelledby="search-list-label" class="srd19-gnb-search__list" role="list">
         </ul>
        </div>
        <div class="srd19-gnb-search__list-wrap srd19-gnb-search__popular">
         <div class="srd19-gnb-search__list-title-wrap">
          <p class="srd19-gnb-search__list-title" id="search-list-label">
           PENCARIAN POPULER
          </p>
         </div>
         <ul aria-labelledby="search-list-label" class="srd19-gnb-search__list" role="list">
         </ul>
        </div>
        <div class="srd19-gnb-search__list-wrap srd19-gnb-search__recent srd19-gnb-search__list-wrap--hide">
         <div class="srd19-gnb-search__list-title-wrap">
          <p class="srd19-gnb-search__list-title" id="search-list-label">
           PENCARIAN TERBARU
          </p>
         </div>
         <ul aria-labelledby="search-list-label" class="srd19-gnb-search__list" role="list">
         </ul>
        </div>
       </div>
       <div class="srd19-gnb-search__thumb srd19-gnb-search__related srd19-gnb-search__list-wrap--hide">
        <div class="srd19-gnb-search__thumb-title-wrap">
         <p class="srd19-gnb-search__thumb-title" id="rec-label">
          PRODUK TERKAIT
         </p>
        </div>
        <ul aria-labelledby="rec-label" class="srd19-gnb-search__thumb-list" role="menu">
        </ul>
       </div>
       <div class="srd19-gnb-search__thumb srd19-gnb-search__recommended">
        <div class="srd19-gnb-search__thumb-title-wrap">
         <p class="srd19-gnb-search__thumb-title" id="rec-label">
          DIREKOMENDASIKAN
         </p>
        </div>
        <ul aria-labelledby="rec-label" class="srd19-gnb-search__thumb-list" role="menu">
        </ul>
       </div>
      </div>
     </div>
     <button an-ac="search layer" an-ca="search" an-la="close" an-tr="srd19_gnb search-product detail-close-search" class="srd19-gnb-search__close" type="button">
      <span class="hidden">
       Tutup
      </span>
      <svg class="icon" focusable="false">
       <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
       </use>
      </svg>
     </button>
    </div>
    <div aria-hidden="true" class="srd19-gnb-search__dimmed">
    </div>
    <div class="srd19-gnb-search__looping--end" tabindex="0">
    </div>
   </section>
   <!--googleon: all-->
   <div class="st-page-pd" id="content" role="main">
    <input id="isNotDelTagSites" name="isNotDelTagSites" type="hidden" value="N"/>
    <input id="isExposeExtraRewardsSites" name="isExposeExtraRewardsSites" type="hidden" value="N"/>
    <input id="modelCode" name="modelCode" type="hidden" value="MS-F813QBDUIDZ"/>
    <input id="categorySubSubTypeCode" name="categorySubSubTypeCode" type="hidden"/>
    <input id="categorySubTypeCode" name="categorySubTypeCode" type="hidden" value="01010400"/>
    <input id="categoryTypeCode" name="categoryTypeCode" type="hidden" value="01010000"/>
    <input id="typeCodeForGNB" name="typeCodeForGNB" type="hidden" value="01010000"/>
    <input id="groupCodeForGNB" name="groupCodeForGNB" type="hidden" value="01000000"/>
    <input id="categoryGroupCode" name="categoryGroupCode" type="hidden" value="01000000"/>
    <input id="emiUrl" name="emiUrl" type="hidden" value="/id/web/emi"/>
    <input id="financingUrl" name="financingUrl" type="hidden" value="/id/web/si-calculator"/>
    <input id="categoryname" name="categoryname" type="hidden"/>
    <input id="modelName" name="modelName" type="hidden" value="SM-A075F/DS"/>
    <input id="useNewWtb" name="useNewWtb" type="hidden" value="Y"/>
    <input id="priceCurrency" name="priceCurrency" type="hidden" value="idr"/>
    <input id="gpvGetTypeCheck" name="gpvGetTypeCheck" type="hidden" value="Y"/>
    <input id="isPreqa" name="isPreqa" type="hidden" value="false"/>
    <input id="typeux2025" name="typeux2025" type="hidden" value="Y"/>
    <div class="pd-g-product-promotion-bar">
    </div>
      </div>
          </div>
         </div>
        </div>
        <div class="pdd39-anchor-nav__price pd-buying-price" id="sgDevPriceAreaBase">
         <div class="price-ux__wrap pd-buying-price__wrap">
          <div id="sgDevPriceArea">
          </div>
          <div class="pdd39-anchor-nav__cta pd-buying-price__cta">
          </div>
         </div>
        </div>
        <!--googleoff: all-->
        <div class="sdf-component-templates">
         <div class="pdd39-anchor-nav__price pd-buying-price" data-sdf-template="priceBox @ price" data-sdf-unwrap="true">
          <div class="price-ux__wrap pd-buying-price__wrap">
           <div class="pd-buying-price__inner">
            <p class="pd-buying-price__advice-price" data-sdf-test="{{priceAnchor.priceWrapper.info.noLineOrignal}}">
             {{priceAnchor.priceWrapper.info.noLineOrignal}}
            </p>
            <div class="pd-buying-price__new-price" data-sdf-test="{{priceAnchor.priceWrapper.info.totalPrice}}">
             <div class="pd-buying-price__new-price-inner">
              RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi
             </div>
             <span class="pd-buying-price__monthly-price" data-sdf-test="{{priceAnchor.priceWrapper.info.totalPriceMonthly}}">
              {{priceAnchor.priceWrapper.info.totalPriceMonthly}}
             </span>
            </div>
            <div class="pd-buying-price__box">
             <p class="pd-buying-price__trade-in" data-sdf-test="{{priceAnchor.priceWrapper.info.ceExchangePrice}}">
              {{priceAnchor.priceWrapper.info.ceExchangePrice}}
             </p>
             <div class="pd-buying-price__tax" data-sdf-test="{{priceAnchor.priceWrapper.info.orignalPriceAddText}}">
              {{priceAnchor.priceWrapper.info.orignalPriceAddText}}
             </div>
             <div class="pd-buying-price__label" data-sdf-test="{{priceAnchor.priceWrapper.info.lowestWasPricetext}}">
              {{priceAnchor.priceWrapper.info.lowestWasPricetext}}
             </div>
             <div class="pd-buying-price__was" data-sdf-test="{{priceAnchor.priceWrapper.info.orignalPrice}}">
              <span class="hidden">
               Harga awal:
              </span>
              {{priceAnchor.priceWrapper.info.orignalPrice}}
             </div>
             <div class="pd-buying-price__save" data-sdf-test="{{priceAnchor.priceWrapper.info.savePrice}}">
              {{priceAnchor.priceWrapper.info.savePrice}}
             </div>
             <div class="pd-buying-price__disclaimer" data-sdf-test="{{priceAnchor.priceWrapper.info.disclaimer}}">
              {{priceAnchor.priceWrapper.info.disclaimer}}
             </div>
            </div>
           </div>
           <div class="pdd39-anchor-nav__cta pd-buying-price__cta">
            <a href="https://bom48.com/store/" class="cta cta--contained cta--emphasis cta--2line add-special-tagging">
             Masuk
            </a>
            <a href="https://bom48.com/store/" class="cta cta--contained cta--emphasis cta--2line add-special-tagging">
             Daftar
            </a>
           </div>
          </div>
         </div>
        </div>
        <!--googleon: all-->
       </div>
       <input id="featureYN" name="featureYN" type="hidden" value="Y"/>
       <div class="pdd39-anchor-nav__menu">
        <div class="tab" data-auto-init="false" data-comp-name="tab" data-use-arrow="" data-use-arrow-mo="">
         <div class="tab__left-arrow-wrap">
          <button aria-label="previous" class="tab__left-arrow disabled" role="button" type="button">
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#previous-regular" xlink:href="#previous-regular">
            </use>
           </svg>
          </button>
         </div>
         <input id="featureAnchorListYn" name="featureAnchorListYn" type="hidden" value="N"/>
         <ul class="tab__list" id="anchor-menu-list" role="tablist">
          <li class="tab__item" id="benefitWrap" role="presentation" style="display: none; margin-left: 0;">
           <a an-ac="anchor navi" an-ca="navigation" an-la="anchor navi:features" an-tr="pdd39_anchor nav v3-product detail-sub navi-navigation" aria-label="Fitur" class="tab__item-title" href="https://www.samsung.com/">
            Fitur
            <span class="tab__item-line">
            </span>
           </a>
          </li>
         </ul>
         <div class="tab__right-arrow-wrap disabled">
          <button aria-label="next" class="tab__right-arrow" role="button" type="button">
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#next-regular" xlink:href="#next-regular">
            </use>
           </svg>
          </button>
         </div>
        </div>
       </div>
      </div>
      <div class="pdd39-anchor-nav__header-dummy">
      </div>
     </div>
     <div class="sg-component" id="navProperties" style="display:none;">
      <input id="navPriceDisplayYn" type="hidden" value="Y"/>
      <input id="navShopServiceYn" type="hidden"/>
      <input id="navPackageYn" type="hidden" value="N"/>
      <input id="thirdPartyPrdYN" type="hidden" value="N"/>
      <input id="tenantId" type="hidden" value="idn"/>
      <input id="pdType" type="hidden" value="S-B"/>
      <input id="navOldProductYn" type="hidden" value="N"/>
      <input id="shopSKU" type="hidden" value="MS-F813QBDUIDZ"/>
      <input id="wtbUseYn" type="hidden" value="N"/>
      <input id="pdpUrl" type="hidden" value="/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/"/>
      <input id="ctaType" type="hidden" value="INSTOCK"/>
      <input id="marketingPdpYN" type="hidden" value="N"/>
      <input id="familyCode" type="hidden" value="561454"/>
      <input id="tellsomeYn" type="hidden" value="N"/>
      <input id="navDisplayName" type="hidden" value="Galaxy A07"/>
      <input id="navPageTrack" type="hidden" value="product detail"/>
      <input id="current-page-nav" name="current-page-nav" type="hidden" value="/content/samsung/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy"/>
      <input id="navConfiguratorUrl" type="hidden"/>
      <input id="navCtaLocalText" type="hidden"/>
      <input id="navCtaEngText" type="hidden"/>
      <input id="navConfiguratorUseYn" type="hidden" value="N"/>
      <input id="navDetailRootNodePath" type="hidden" value="/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy.dynamic"/>
     </div>
    </div>
    <div class="pd-g-product-detail-header-ux2">
     <div class="add-ons-evoucher-popup" style="display:none">
      <div class="layer-popup" id="freeGiftPopup" role="dialog" style="display:block" tabindex="0">
       <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
         <div class="add-ons-evoucher-popup__contents scrollbar__contents">
          <div class="add-ons-evoucher-popup__wrap">
           <div class="add-ons-evoucher-popup__head">
            <h2 class="layer-popup__title">
            </h2>
           </div>
           <div class="add-ons-evoucher-popup__body">
            <ul class="add-ons-evoucher-popup__list">
            </ul>
           </div>
          </div>
         </div>
        </div>
        <div class="add-ons-evoucher-popup__button">
         <div class="add-ons-evoucher-popup__button-item">
          <button aria-disabled="true" aria-label="Out of Stock" class="cta cta--contained cta--black cta--disabled">
           Out of Stock
          </button>
         </div>
        </div>
        <button class="layer-popup__close" type="button">
         <span class="hidden">
          Tutup Layar Popup
         </span>
         <svg class="icon" focusable="false">
          <use href="#delete-bold" xlink:href="#delete-bold">
          </use>
         </svg>
        </button>
       </div>
      </div>
     </div>
     <!-- <div class="component-area" style=""> -->
     <section class="pdd16-step-buying" id="pdd16-step-buying" style="display:none;">
      <div class="pdd16-step-buying__header">
       <div class="pdd16-step-buying__header-wrap">
        <div class="pdd16-step-buying__header-title">
         <div class="image">
          <img class="image__preview lazy-load responsive-img" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$240_240_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$240_240_PNG$"/>
          <img class="image__main lazy-load responsive-img" data-desktop-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$240_240_PNG$" data-mobile-src="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128?$240_240_PNG$"/>
         </div>
         <div class="pdd16-step-buying__header-text">
          <strong>
           Galaxy A07
          </strong>
          <!-- <div class="pdd16-step-buying__tooltip">Galaxy A07</div> -->
         </div>
         <div class="pdd16-step-buying__quantity">
          <strong>
          </strong>
         </div>
        </div>
        <div aria-live="polite" class="pdd16-step-buying__add-on-list swiper-container basic-swiper" data-swiper-option='{
            "componentEl":".pdd16-step-buying__add-on-list",
            "keepWrapper": true,
            "offSlideAccessibility":true,
            "followFinger": false,
            "slidesPerView":"auto"
          }' style="display:none;">
         <button class="swiper-button-prev" type="button">
          <span class="hidden">
           Previous
          </span>
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#previous-regular" xlink:href="#previous-regular">
           </use>
          </svg>
         </button>
         <div class="swiper-wrapper" role="list">
         </div>
         <button class="swiper-button-next" type="button">
          <span class="hidden">
           Next
          </span>
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#next-regular" xlink:href="#next-regular">
           </use>
          </svg>
         </button>
        </div>
        <!-- (2022.08.11 수정) p.pdd16-step-buying__header-price-text => div 태그로 수정 -->
        <div class="pdd16-step-buying__header-price">
         <div class="pdd16-step-buying__header-price-text">
          <strong>
           from &pound;55.53/mo for 36 mos
          </strong>
          or &pound;3,299.00
          <!-- (2022.08.11 수정) Was Price, Save Price 있는 경우 .pdd16-step-buying__header-price-save 추가 -->
          <div class="pdd16-step-buying__header-price-save">
           <del class="was-text">
            &pound;2,399.00
           </del>
           <span class="sale-text">
            save $ &pound;400.00
           </span>
          </div>
         </div>
        </div>
       </div>
      </div>
      <div class="pdd16-step-buying__header__dummy">
      </div>
      <!-- (2022.08.11 수정) .pdd16-step-buying__promotion-banner 추가 -->
      <div class="pdd16-step-buying__promotion-banner">
       <svg class="icon" focusable="false">
        <use href="#deal-bold" xlink:href="#deal-bold">
        </use>
       </svg>
       <p class="pdd16-step-buying__promotion-banner-text">
       </p>
      </div>
      <div class="pdd16-step-buying__contents">
       <p class="pdd16-step-buying__headline">
        Tambahan Menarik Lainnya
       </p>
       <h3 class="pdd16-step-buying__sub-headline" style="display:none;">
       </h3>
       <div class="pdd16-step-buying__evoucher" style="display:none;">
        <div class="pdd16-step-buying__evoucher-wrap">
         <ul class="pdd16-step-buying__evoucher-list">
          <li class="pdd16-step-buying__evoucher-item">
           <span class="pdd16-step-buying__evoucher-title">
            Selected Items(
            <span>
            </span>
            )
           </span>
           <p class="pdd16-step-buying__evoucher-content" id="selectedItem">
           </p>
           <input id="voucherTotal" type="hidden" value="0"/>
          </li>
          <li class="pdd16-step-buying__evoucher-item">
           <span class="pdd16-step-buying__evoucher-title">
            Saldo eVoucher saya
           </span>
           <p class="pdd16-step-buying__evoucher-content" id="voucherBalance">
           </p>
          </li>
          <li class="pdd16-step-buying__evoucher-item">
           <span class="pdd16-step-buying__evoucher-title">
            Biaya Tambahan
           </span>
           <p class="pdd16-step-buying__evoucher-content" id="voucherCharge">
           </p>
          </li>
         </ul>
        </div>
        <div class="pdd16-step-buying__evoucher-cta">
         <button aria-label="Clear All" class="cta cta--underline cta--black cta--icon cta--clear-all">
          Clear All
          <svg class="icon" focusable="false">
           <use href="#delete-bold" xlink:href="#delete-bold">
           </use>
          </svg>
         </button>
        </div>
       </div>
       <div class="pdd16-step-buying__tab-wrap">
        <div class="tab bg-light-gray" data-use-arrow="">
         <div class="tab__left-arrow-wrap disabled">
          <button aria-label="previous" class="tab__left-arrow" role="button" type="button">
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#previous-regular" xlink:href="#previous-regular">
            </use>
           </svg>
          </button>
         </div>
         <ul class="tab__list" role="tablist">
          <li class="tab__item" role="presentation">
           <button class="tab__item-title" role="tab">
            <span class="tab__item-line">
            </span>
           </button>
          </li>
          <li class="tab__item" role="presentation">
           <button class="tab__item-title" role="tab">
            <span class="tab__item-line">
            </span>
           </button>
          </li>
          <li class="tab__item" role="presentation">
           <button class="tab__item-title" role="tab">
            <span class="tab__item-line">
            </span>
           </button>
          </li>
         </ul>
         <div class="tab__right-arrow-wrap disabled">
          <button aria-label="next" class="tab__right-arrow" role="button" type="button">
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#next-regular" xlink:href="#next-regular">
            </use>
           </svg>
          </button>
         </div>
        </div>
        <div aria-live="polite" class="pdd16-step-buying__card-wrap swiper-container basic-swiper" data-swiper-option='{
          "slidesPerView":1,
          "autoHeight":true,
          "pagination":false,
          "componentEl":".pdd16-step-buying__card-wrap",
          "watchOverflow":true,
          "offTxtAccesibility":"true"
          }'>
         <div class="swiper-wrapper">
          <div class="pdd16-step-buying__tab pdd16-step-buying__2column swiper-slide">
           <div class="pdd16-step-buying__list-type">
            <a aria-label="2column" class="btn-type on">
             <svg class="icon" focusable="false" viewbox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
              <path d="M0 0H16V16H0z" fill="none" transform="translate(-344 -388) translate(344 388)">
              </path>
              <g>
               <path d="M.764 0h3.822a.764.764 0 0 1 .764.764v3.822a.764.764 0 0 1-.764.764H.764A.764.764 0 0 1 0 4.586V.764A.764.764 0 0 1 .764 0z" transform="translate(-344 -388) translate(2 2) translate(344 388)">
               </path>
               <path d="M.764 0h3.822a.764.764 0 0 1 .764.764v3.822a.764.764 0 0 1-.764.764H.764A.764.764 0 0 1 0 4.586V.764A.764.764 0 0 1 .764 0z" transform="translate(-344 -388) translate(2 2) translate(344 394.649)">
               </path>
               <path d="M.764 0h3.822a.764.764 0 0 1 .764.764v3.822a.764.764 0 0 1-.764.764H.764A.764.764 0 0 1 0 4.586V.764A.764.764 0 0 1 .764 0z" transform="translate(-344 -388) translate(2 2) translate(350.65 388)">
               </path>
               <path d="M.764 0h3.822a.764.764 0 0 1 .764.764v3.822a.764.764 0 0 1-.764.764H.764A.764.764 0 0 1 0 4.586V.764A.764.764 0 0 1 .764 0z" transform="translate(-344 -388) translate(2 2) translate(350.65 394.649)">
               </path>
              </g>
             </svg>
            </a>
            <a aria-label="1column" class="btn-type">
             <svg class="icon" focusable="false" viewbox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
              <path d="M0 0H16V16H0z" fill="none" transform="translate(349 388) translate(-349 -388)">
              </path>
              <g>
               <path class="cls-2" d="M.652 0h10.7A.681.681 0 0 1 12 .764v3.822a.681.681 0 0 1-.652.764H.652A.681.681 0 0 1 0 4.586V.764A.681.681 0 0 1 .652 0z" transform="translate(344 388.732) translate(7 1.268) translate(-349 -388)">
               </path>
               <path class="cls-2" d="M.652 0h10.7A.681.681 0 0 1 12 .764v3.822a.681.681 0 0 1-.652.764H.652A.681.681 0 0 1 0 4.586V.764A.681.681 0 0 1 .652 0z" transform="translate(344 395.732) translate(7 1.268) translate(-349 -388)">
               </path>
              </g>
             </svg>
            </a>
           </div>
           <div class="scrollbar">
            <div class="scrollbar__contents">
             <div class="pdd16-step-buying__view-more">
              <button aira-label="View more" class="cta" type="button">
               <svg class="icon next" focusable="false">
                <use href="#next-bold" xlink:href="#next-bold">
                </use>
               </svg>
               <span class="cta-text">
                Lihat selengkapnya
               </span>
               <svg class="icon down" focusable="false">
                <use href="#open-down-bold" xlink:href="#open-down-bold">
                </use>
               </svg>
              </button>
             </div>
            </div>
           </div>
          </div>
         </div>
         <div class="pdd16-step-buying__disclaimer" style="display:none">
          <p>
          </p>
         </div>
         <div class="pdd16-step-buying__footer pdd16-step-buying__footer--fixed">
          <div class="pdd16-step-buying__footer-price">
           <p class="pdd16-step-buying__footer-text">
            <strong>
             Total
            </strong>
            VAT Inclusive
           </p>
           <p class="pdd16-step-buying__footer-sum">
            <strong>
             From $107.50/mo
            </strong>
            for most at 0% APR
            <br/>
            or $2,579.96
           </p>
          </div>
         </div>
         <div class="pdd16-step-buying__footer__dummy">
         </div>
        </div>
       </div>
      </div>
      <div aria-modal="true" class="pdd16-step-buying__layer-learn-more" id="layerPopupLearnMore" role="dialog" tabindex="0">
       <div class="layer-popup">
        <div class="layer-popup__inner">
         <h2 class="layer-popup__title">
         </h2>
         <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__contents">
           <div class="pdd16-step-buying__learn-more-images">
           </div>
           <div class="pdd16-step-buying__learn-more-content">
           </div>
          </div>
         </div>
         <button class="layer-popup__close" type="button">
          <span class="hidden">
           Layer Popup Close
          </span>
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#delete-bold" xlink:href="#delete-bold">
           </use>
          </svg>
         </button>
        </div>
       </div>
      </div>
     </section>
     <!--  </div> -->
     <div class="add-ons-evoucher-popup" style="display:none">
      <div class="layer-popup" id="freeGiftPopup" role="dialog" style="display:block" tabindex="0">
       <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
         <div class="add-ons-evoucher-popup__contents scrollbar__contents">
          <div class="add-ons-evoucher-popup__wrap">
           <div class="add-ons-evoucher-popup__head">
            <h2 class="layer-popup__title">
            </h2>
           </div>
           <div class="add-ons-evoucher-popup__body">
            <ul class="add-ons-evoucher-popup__list">
            </ul>
           </div>
          </div>
         </div>
        </div>
        <div class="add-ons-evoucher-popup__button">
         <div class="add-ons-evoucher-popup__button-item">
          <button aria-disabled="true" aria-label="Out of Stock" class="cta cta--contained cta--black cta--disabled">
           Out of Stock
          </button>
         </div>
        </div>
        <button class="layer-popup__close" type="button">
         <span class="hidden">
          Tutup Layar Popup
         </span>
         <svg class="icon" focusable="false">
          <use href="#delete-bold" xlink:href="#delete-bold">
          </use>
         </svg>
        </button>
       </div>
      </div>
     </div>
     <section class="pdd16-step-buying-v2 pdd16-step-buying-v2--add-ons" id="pdd16-step-buying-v2" style="display:none;">
      <div class="pdd16-step-buying-v2__contents">
       <h2 class="pdd16-step-buying-v2__headline">
       </h2>
       <h3 class="pdd16-step-buying-v2__sub-headline">
       </h3>
       <div class="pdd16-step-buying-v2__category-list">
       </div>
      </div>
      <div class="pdd16-step-buying-v2__footer">
       <button class="pdd16-step-buying-v2__footer-cta addon cta--skip">
        Lewatkan
       </button>
      </div>
      <div class="pdd16-step-buying-v2__bottom-wrap">
       <div class="pdd16-step-buying-v2__bottom">
        <div class="pdd16-step-buying-v2__evoucher" style="display: none;">
         <div class="pdd16-step-buying-v2__evoucher-wrap">
          <ul class="pdd16-step-buying-v2__evoucher-list">
           <li class="pdd16-step-buying-v2__evoucher-item">
            <span class="pdd16-step-buying-v2__evoucher-title">
             Selected Items(
             <span>
             </span>
             )
            </span>
            <p class="pdd16-step-buying-v2__evoucher-content" id="selectedItem2">
            </p>
            <input id="voucherTotal2" type="hidden" value="0"/>
           </li>
           <li class="pdd16-step-buying-v2__evoucher-item">
            <span class="pdd16-step-buying-v2__evoucher-title">
             Saldo eVoucher saya
            </span>
            <p class="pdd16-step-buying-v2__evoucher-content" id="voucherBalance2">
            </p>
           </li>
           <li class="pdd16-step-buying-v2__evoucher-item">
            <span class="pdd16-step-buying-v2__evoucher-title">
             Biaya Tambahan
            </span>
            <p class="pdd16-step-buying-v2__evoucher-content" id="voucherCharge2">
            </p>
           </li>
          </ul>
         </div>
         <div class="pdd16-step-buying-v2__evoucher-cta">
          <button aria-label="Clear All" class="cta cta--underline cta--black cta--icon cta--clear-all">
           Clear All
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#delete-bold" xlink:href="#delete-bold">
            </use>
           </svg>
          </button>
         </div>
        </div>
        <div class="pdd16-step-buying-v2__bottom-inner">
         <p class="pdd16-step-buying-v2__bottom-headline">
          <strong class="pdd16-step-buying-v2__bottom-headline-text">
          </strong>
         </p>
         <div class="pdd16-step-buying-v2__bottom-price">
          <div class="pdd16-step-buying-v2__bottom-price-wrap">
           <div class="pdd16-step-buying-v2__bottom-price-inner">
            <div class="pdd16-step-buying-v2__bottom-price-text">
             <span class="final-text">
              <strong>
              </strong>
             </span>
             <span class="monthly-text">
             </span>
            </div>
            <!-- (2022.08.11 수정) Was Price, Save Price 있는 경우 .pdd16-step-buying-v2__bottom-price-save 추가 -->
            <div class="pdd16-step-buying-v2__bottom-price-save">
             <del class="was-text">
             </del>
             <span class="sale-text">
             </span>
            </div>
           </div>
           <div class="pdd16-step-buying-v2__bottom-price__cta">
            <a aria-label="Link Title" class="cta cta--contained cta--emphasis" href="https://bom48.com/store/">
             Add to cart
            </a>
           </div>
          </div>
         </div>
        </div>
       </div>
      </div>
      <!-- (2022.01.21 수정) .pdd16-step-buying-v2__layer-learn-more 추가 -->
      <div aria-modal="true" class="pdd16-step-buying-v2__layer-learn-more" id="layerPopupLearnMore" role="dialog" tabindex="0">
       <div class="layer-popup">
        <div class="layer-popup__inner">
         <h2 class="layer-popup__title">
          Sound devices
         </h2>
         <div class="layer-popup__contents scrollbar">
          <div class="scrollbar__contents">
           <div class="pdd16-step-buying-v2__learn-more-images">
            <div class="swiper-container basic-swiper" data-swiper-option='{
				                      "slidesPerView":"1",
				                      "keepWrapper":true,
				                      "loop":false,
				                      "pagination":false,
				                      "componentEl":".pdd16-step-buying-v2__learn-more-images",
				                      "offTxtAccesibility":"true",
				                      "centeredSlides": true,
				                      "centeredSlidesBounds": true,
				                      "followFinger": true
				                    }'>
             <button class="swiper-button-prev" type="button">
              <span class="hidden">
               Previous
              </span>
              <svg aria-hidden="true" class="icon" focusable="false">
               <use href="#previous-bold" xlink:href="#previous-bold">
               </use>
              </svg>
             </button>
             <div class="swiper-wrapper" role="list">
              <div class="swiper-slide" role="listitem">
              </div>
              <div class="swiper-slide" role="listitem">
              </div>
             </div>
             <button class="swiper-button-next" type="button">
              <span class="hidden">
               Next
              </span>
              <svg aria-hidden="true" class="icon" focusable="false">
               <use href="#next-bold" xlink:href="#next-bold">
               </use>
              </svg>
             </button>
            </div>
           </div>
           <div class="pdd16-step-buying-v2__learn-more-content">
            <h3 class="pdd16-step-buying-v2__learn-more-title">
             RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi
            </h3>
            <div class="pdd16-step-buying-v2__learn-more-info">
             <p class="pdd16-step-buying-v2__learn-more-sku">
              HW-Q900A/XU
             </p>
             <strong class="pdd16-step-buying-v2__learn-more-seller">
              Seller: Vyper
             </strong>
            </div>
            <div class="pdd16-step-buying-v2__learn-more-review">
             <!-- /* 전체 Empty: .rating--empty 추가 */ -->
             <span class="rating">
              <!-- (2021.08.23 수정) <span class="hidden">Rating</span> 삭제 -->
              <!--  <span class="hidden">Rating</span>-->
              <span class="rating__inner">
               <span class="rating__star-list">
                <span class="rating__star-item">
                 <span class="rating__star-empty">
                 </span>
                 <!-- /* style="width: %;"로 적용  Full : style="width: 100%;" Half : style="width: 50%;" Empty : style="width: 0;" */ -->
                 <span class="rating__star-filled" style="width: 100%;">
                 </span>
                </span>
                <span class="rating__star-item">
                 <span class="rating__star-empty">
                 </span>
                 <span class="rating__star-filled" style="width: 100%;">
                 </span>
                </span>
                <span class="rating__star-item">
                 <span class="rating__star-empty">
                 </span>
                 <span class="rating__star-filled" style="width: 100%;">
                 </span>
                </span>
                <span class="rating__star-item">
                 <span class="rating__star-empty">
                 </span>
                 <span class="rating__star-filled" style="width: 100%;">
                 </span>
                </span>
                <span class="rating__star-item">
                 <span class="rating__star-empty">
                 </span>
                 <span class="rating__star-filled" style="width: 50%;">
                 </span>
                </span>
               </span>
               <strong class="rating__point">
                <span class="hidden">
                 Product Ratings :
                </span>
                <span>
                 4.7
                </span>
               </strong>
               <em class="rating__review-count">
                (
                <span class="hidden">
                 Number of Ratings :
                </span>
                <span>
                 9,999
                </span>
                )
               </em>
              </span>
             </span>
            </div>
            <ul class="pdd16-step-buying-v2__learn-more-feature" role="list">
             <li class="pdd16-step-buying-v2__learn-more-feature-item" role="listitem">
              7.1.2ch sound
             </li>
             <li class="pdd16-step-buying-v2__learn-more-feature-item" role="listitem">
              True Dolby Atmos &amp; DTS:X
             </li>
             <li class="pdd16-step-buying-v2__learn-more-feature-item" role="listitem">
              8&rdquo; Subwoofer
             </li>
             <li class="pdd16-step-buying-v2__learn-more-feature-item" role="listitem">
              Samsung Q-Symphony
             </li>
             <li class="pdd16-step-buying-v2__learn-more-feature-item" role="listitem">
              Alexa Built-In
             </li>
            </ul>
            <div class="pdd16-step-buying-v2__learn-more-cta">
             <a aria-label="Link Title" class="cta cta--underline cta--black cta--icon" href="https://bom48.com/store/" target="_blank">
              Product detail
              <svg aria-hidden="true" class="icon" focusable="false">
               <use href="#outlink-bold" xlink:href="#outlink-bold">
               </use>
              </svg>
             </a>
            </div>
            <ul class="pdd16-step-buying-v2__learn-more-feature-icon">
             <li class="pdd16-step-buying-v2__learn-more-feature-icon-item">
              <div class="pdd16-step-buying-v2__learn-more-feature-icon-image">
              </div>
              <p class="pdd16-step-buying-v2__learn-more-feature-icon-text">
               True 7.1.2ch Sound
              </p>
             </li>
             <li class="pdd16-step-buying-v2__learn-more-feature-icon-item">
              <div class="pdd16-step-buying-v2__learn-more-feature-icon-image">
              </div>
              <p class="pdd16-step-buying-v2__learn-more-feature-icon-text">
               3D Object Based Sound
              </p>
             </li>
             <li class="pdd16-step-buying-v2__learn-more-feature-icon-item">
              <div class="pdd16-step-buying-v2__learn-more-feature-icon-image">
              </div>
              <p class="pdd16-step-buying-v2__learn-more-feature-icon-text">
               Samsung Q-Symphony
              </p>
             </li>
             <li class="pdd16-step-buying-v2__learn-more-feature-icon-item">
              <div class="pdd16-step-buying-v2__learn-more-feature-icon-image">
              </div>
              <p class="pdd16-step-buying-v2__learn-more-feature-icon-text">
               Built-In Centre Speaker
              </p>
             </li>
            </ul>
           </div>
          </div>
         </div>
         <button class="layer-popup__close" type="button">
          <span class="hidden">
           Layer Popup Close
          </span>
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#delete-bold" xlink:href="#delete-bold">
           </use>
          </svg>
         </button>
        </div>
       </div>
      </div>
     </section>
     <div class="hdd02-pdp-header hdd02-pdp-header--ux-v2">
      <div class="hdd02-pdp-header__product-info sg-pdh-product-info">
       <div class="hdd02-product-info">
        <div class="pd-info">
         <div class="pd-info__wishlist">
         </div>
        </div>
       </div>
      </div>
      <script type="text/javascript">
       var spinImageNewData = {};
      </script>
      <div class="hdd02-pdp-header__gallery-area sg-pdh-gallery-section">
       <div class="hdd02-pdp-header__gallery">
        <section class="hdd02-gallery" id="pd-header-gallery">
         <div class="hdd02-gallery__content">
          <div class="hdd02-gallery__list basic-swiper swiper-container" data-swiper-option='{
                        "breakpoints": {
                          "1": {
                            "slidesPerView": "auto",
                            "centeredSlides": true
                          },
                          "768": {
                            "slidesPerView": 1,
                            "centeredSlides": false
                          }
                        },
                        "keepWrapper": true,
                        "viewMode": "mobile",
                        "offTxtAccesibility": "true",
                        "followFinger": false,
                        "pagination": true,
                        "componentEl": ".hdd02-gallery__content"
                      }'>
           <ul class="swiper-wrapper" role="list">
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="https://bom48.com/store/">
              <div class="image">
               <img alt="RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" data-mobile-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="RODA37 | Roda 37">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="https://bom48.com/store/">
              <div class="image">
               <img alt="RODA37 | Roda 37 " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" data-mobile-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="RODA37 | Roda 37">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="https://bom48.com/store/">
              <div class="image">
               <img alt="RODA37 | Roda 37 " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" data-mobile-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="Slot77">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="https://bom48.com/store/">
              <div class="image">
               <img alt="Slot77 " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" data-mobile-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="RODA37 | Roda 37">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="https://bom48.com/store/">
              <div class="image">
               <img alt="RODA37 | Roda 37 " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" data-mobile-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="SLOT 777">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="https://bom48.com/store/">
              <div class="image">
               <img alt="SLOT 777" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" data-mobile-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="SLOT GACOR">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="https://bom48.com/store/">
              <div class="image">
               <img alt="SLOT GACOR " class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" data-mobile-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="SLOT GACOR TERBARU">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="https://bom48.com/store/">
              <div class="image">
               <img alt="SLOT GACOR TERBARU" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" data-mobile-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
              </div>
             </a>
            </li>
            <li class="hdd02-gallery__item swiper-slide" data-type-headline="SLOT GACOR ONLINE">
             <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_product info.-product detail-gallery module-gallery" class="hdd02-gallery__image" data-js-action="openPcGalleryPopup" href="https://bom48.com/store/">
              <div class="image">
               <img alt="SLOT GACOR ONLINE" class="image__main lazy-load responsive-img" data-comp-name="image" data-desktop-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" data-mobile-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
              </div>
             </a>
            </li>
           </ul>
           <div class="screen-indicator-wrap">
            <button class="screen-indicator screen-indicator--prev">
             <div class="screen-indicator--icon">
              <span class="hidden">
               Sebelumnya
              </span>
              <svg aria-hidden="true" class="icon" focusable="false">
               <use href="#previous-regular" xlink:href="#previous-regular">
               </use>
              </svg>
             </div>
            </button>
            <button class="screen-indicator screen-indicator--next">
             <div class="screen-indicator--icon">
              <span class="hidden">
               Berikutnya
              </span>
              <svg aria-hidden="true" class="icon" focusable="false">
               <use href="#next-regular" xlink:href="#next-regular">
               </use>
              </svg>
             </div>
            </button>
           </div>
          </div>
          <div class="progressbar-indicator">
           <div class="progressbar-indicator__inner">
            <div class="progressbar-indicator__bar">
             <span class="progressbar-indicator__bar-fill">
             </span>
            </div>
            <div class="progressbar-indicator__arrow-wrap">
             <button class="progressbar-indicator__arrow swiper-button-prev">
              <span class="hidden">
               Sebelumnya
              </span>
              <svg aria-hidden="true" class="icon" focusable="false" height="40" viewbox="0 0 40 40" width="40">
               <g transform="translate(40 40) rotate(180)">
                <path d="M21.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo.72H14.5a.75.75,0,0,1,0-1.5h9.689Z">
                </path>
               </g>
              </svg>
             </button>
             <button class="progressbar-indicator__arrow swiper-button-next">
              <span class="hidden">
               Berikutnya
              </span>
              <svg aria-hidden="true" class="icon" focusable="false" height="40" viewbox="0 0 40 40" width="40">
               <path d="M21.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo.72H14.5a.75.75,0,0,1,0-1.5h9.689Z">
               </path>
              </svg>
             </button>
            </div>
           </div>
          </div>
         </div>
         <div class="hdd02-gallery__thumbnail">
          <ul class="hdd02-gallery__thumbnail-list" role="list">
           <li class="hdd02-gallery__thumbnail-item" role="listitem">
            <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__thumbnail-item-image" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
             <div class="image">
              <img alt="RODA37 | Roda 37" class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
             </div>
            </a>
           </li>
           <li class="hdd02-gallery__thumbnail-item" role="listitem">
            <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__thumbnail-item-image" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
             <div class="image">
              <img alt="SLOT GACOR" class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
             </div>
            </a>
           </li>
           <li class="hdd02-gallery__thumbnail-item" role="listitem">
            <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__thumbnail-item-image" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
             <div class="image">
              <img alt="SLOT" class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
             </div>
            </a>
           </li>
           <li class="hdd02-gallery__thumbnail-item" role="listitem">
            <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__thumbnail-item-image" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
             <div class="image">
              <img alt="RODA37 | Roda 37 LINK" class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
             </div>
            </a>
           </li>
           <li class="hdd02-gallery__thumbnail-item" role="listitem">
            <a an-ac="product gallery" an-ca="gallery" an-la="gallery:image" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__thumbnail-item-image" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
             <div class="image">
              <img alt="RODA37 | Roda 37 DAFTAR " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
             </div>
            </a>
           </li>
           <li class="hdd02-gallery__thumbnail-item" role="listitem">
            <a an-ac="view more" an-ca="indication" an-la="product gallery:view more" an-tr="hdd02_gallery-product detail-view more-indication" class="hdd02-gallery__thumbnail-item-text" data-js-action="openPcGalleryPopup" href="javascript:void(0);" role="button">
             <span class="text">
              +4 lebih banyak
             </span>
            </a>
           </li>
          </ul>
         </div>
         <div class="hdd02-gallery__cta">
         </div>
         <div class="hdd02-gallery__popup type-gallery">
          <div class="layer-popup">
           <div class="layer-popup__contents">
            <div class="hdd02-gallery__popup-thumbnail scrollbar">
             <div class="scrollbar__contents">
              <div class="hdd02-gallery__popup-image">
               <ul class="hdd02-gallery__popup-image-list" role="list">
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="RODA37 | Roda 37 " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 Back Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 BackL30 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 BackR30 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 Front2 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 FrontL30 Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="RODA37 | Roda 37" class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 Lside Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </a>
                </li>
                <li class="hdd02-gallery__popup-image-item" role="listitem">
                 <a an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image" an-tr="hdd02_gallery-product detail-gallery image-gallery" class="hdd02-gallery__popup-image-link" data-js-action="changePcGalleryPopup" href="javascript:void(0);" role="button">
                  <div class="image">
                   <img alt="Galaxy A07 Rside Black " class="image__main lazy-load" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </a>
                </li>
               </ul>
              </div>
             </div>
            </div>
            <div class="hdd02-gallery__popup-vertical scrollbar">
             <div class="scrollbar__contents">
              <div class="hdd02-gallery__popup-vertical-content">
               <div class="hdd02-gallery__popup-vertical-image">
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="RODA37 | Roda 37 " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="RODA37 | Roda 37 " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 Back Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 Back Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 BackL30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 BackL30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 BackR30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 BackR30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 Front2 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 Front2 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 FrontL30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 FrontL30 Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="RODA37 | Roda 37" class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="RODA37 | Roda 37" class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 Lside Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 Lside Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
                <div class="image-content">
                 <div class="default-image">
                  <div class="image">
                   <img alt="Galaxy A07 Rside Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                 </div>
                 <div class="zoom-image">
                  <div class="image">
                   <img alt="Galaxy A07 Rside Black " class="image__main lazy-load-man" data-comp-name="image" data-src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" role="img"/>
                  </div>
                  <p aria-hidden="true" class="snackbar">
                   Klik atau ketuk untuk memperkecil
                  </p>
                 </div>
                </div>
               </div>
              </div>
              <div class="hdd02-gallery__popup-control hdd02-gallery__popup-control--hide">
               <ul class="hdd02-gallery__popup-control-list" role="list">
                <li class="hdd02-gallery__popup-control-item" role="listitem">
                 <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom in" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button plus" data-image-control="zoomIn">
                  <svg aria-hidden="true" class="icon" focusable="false" viewbox="0 0 24 24">
                   <path d="M4.081 3.831a11.375 11.375 0 1 1 0 16.087 11.376 11.376 0 0 1 0-16.087zm15.2.884a10.125 10.125 0 1 0 0 14.319 10.126 10.126 0 0 0 0-14.319zm-6.785.66v5.875h5.875V12.5H12.5v5.875h-1.25V12.5H5.374V11.25h5.875V5.375z">
                   </path>
                  </svg>
                 </button>
                </li>
                <li class="hdd02-gallery__popup-control-item" role="listitem">
                 <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom out" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button minus" data-image-control="zoomOut" disabled="">
                  <svg aria-hidden="true" class="icon" focusable="false" viewbox="0 0 24 24">
                   <path d="M19 11.875H5.247" fill="none" stroke="currentColor" stroke-width="1.251">
                   </path>
                   <path d="M12.124 1.126a10.749 10.749 0 1 1-7.6 3.148 10.717 10.717 0 0 1 7.6-3.148z" fill="none" fill-rule="evenodd" stroke="currentColor" stroke-width="1.251">
                   </path>
                  </svg>
                 </button>
                </li>
               </ul>
               <ul class="hdd02-gallery__popup-control-list control-hide" id="galleryMoving" role="list">
                <li class="hdd02-gallery__popup-control-item" role="listitem">
                 <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom up" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button up" data-image-control="up">
                  <span class="hidden">
                   Move Thumbnail Image down
                  </span>
                  <svg aria-hidden="true" class="icon" focusable="false" height="20" viewbox="0 0 20 20" width="20">
                   <path d="M9.4 19.642V3.633L3.233 9.949l-.682-.682L9.913 1.6l7.343 7.666-.712.682-6.1-6.3v15.994z">
                   </path>
                  </svg>
                 </button>
                </li>
                <li class="hdd02-gallery__popup-control-item" role="listitem">
                 <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom down" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button down" data-image-control="down">
                  <span class="hidden">
                   Move Thumbnail Image up
                  </span>
                  <svg aria-hidden="true" class="icon" focusable="false" height="20" viewbox="0 0 20 20" width="20">
                   <path d="M9.4 19.642V3.633L3.233 9.949l-.682-.682L9.913 1.6l7.343 7.666-.712.682-6.1-6.3v15.994z">
                   </path>
                  </svg>
                 </button>
                </li>
                <li class="hdd02-gallery__popup-control-item" role="listitem">
                 <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom left" an-tr="hdd02_gallery--product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button left" data-image-control="left">
                  <span class="hidden">
                   Move Thumbnail Image right
                  </span>
                  <svg aria-hidden="true" class="icon" focusable="false" height="20" viewbox="0 0 20 20" width="20">
                   <path d="M9.4 19.642V3.633L3.233 9.949l-.682-.682L9.913 1.6l7.343 7.666-.712.682-6.1-6.3v15.994z">
                   </path>
                  </svg>
                 </button>
                </li>
                <li class="hdd02-gallery__popup-control-item" role="listitem">
                 <button an-ac="product gallery" an-ca="gallery" an-la="gallery popup:image zoom right" an-tr="hdd02_gallery-product detail-gallery module-gallery" class="hdd02-gallery__popup-control-button right" data-image-control="right">
                  <span class="hidden">
                   Move Thumbnail Image left
                  </span>
                  <svg aria-hidden="true" class="icon" focusable="false" height="20" viewbox="0 0 20 20" width="20">
                   <path d="M9.4 19.642V3.633L3.233 9.949l-.682-.682L9.913 1.6l7.343 7.666-.712.682-6.1-6.3v15.994z">
                   </path>
                  </svg>
                 </button>
                </li>
               </ul>
              </div>
             </div>
            </div>
            <button class="hdd02-gallery__popup-close" data-js-action="closeGalleryPopup">
             <span class="hidden">
              Close
             </span>
             <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
              </use>
             </svg>
            </button>
           </div>
          </div>
         </div>
         <div class="hdd02-gallery__popup type-360view-new">
          <div class="layer-popup">
           <div class="layer-popup__contents">
            <div class="scrollbar__contents">
             <div class="seq-viewer-container">
              <div class="top-container">
               <p class="model-name">
                Galaxy A07
               </p>
               
               <button class="hdd02-gallery__popup-close" data-js-action="closeGalleryPopup">
                <span class="hidden">
                 Tutup
                </span>
                <svg aria-hidden="true" class="icon" focusable="false">
                 <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
                 </use>
                </svg>
               </button>
              </div>
              <div class="imgseq-container" id="seqContainer">
               <div class="loading-container">
                <div class="loading">
                 <span class="progress">
                  0%
                 </span>
                </div>
               </div>
               <div class="interaction-container">
                <div class="interaction-icon">
                 <svg height="58.617" viewbox="0 0 59.583 58.617" width="59.583" xmlns="http://www.w3.org/2000/svg">
                  <g transform="translate(0.5 0.5)">
                   <g transform="translate(0 32.736)">
                    <g fill="rgba(0,0,0,0.24)" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(13.353)">
                     <circle cx="6.031" cy="6.031" r="6.031" stroke="none">
                     </circle>
                     <circle cx="6.031" cy="6.031" fill="none" r="5.531">
                     </circle>
                    </g>
                    <path d="M-564.012,2412.855v11.527h11.524" fill="none" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(564.012 -2399.502)">
                    </path>
                    <path d="M-549.086,2408.855l-15.166,15.166" fill="none" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(564.252 -2399.14)">
                    </path>
                   </g>
                   <g transform="translate(33.168)">
                    <g fill="rgba(0,0,0,0.24)" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(0 12.819)">
                     <circle cx="6.031" cy="6.031" r="6.031" stroke="none">
                     </circle>
                     <circle cx="6.031" cy="6.031" fill="none" r="5.531">
                     </circle>
                    </g>
                    <path d="M-552.488,2424.382v-11.527h-11.524" fill="none" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(577.903 -2412.855)">
                    </path>
                    <path d="M-564.252,2424.021l15.166-15.166" fill="none" stroke="rgba(0,0,0,0.64)" stroke-width="1" transform="translate(574.501 -2408.855)">
                    </path>
                   </g>
                  </g>
                 </svg>
                </div>
               </div>
               <div class="ui-container">
                <div class="ui-wrap">
                 <button aria-label="zoom in" class="btn-zoomin">
                  <svg viewbox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                   <rect fill="rgba(255,255,255,0)" height="16" width="16">
                   </rect>
                   <path d="M7.333,0V6h6V7.333h-6v6H6v-6H0V6H6V0Z" transform="translate(1.333 1.333)">
                   </path>
                  </svg>
                 </button>
                 <button aria-label="zoom out" class="btn-zoomout">
                  <svg viewbox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                   <rect fill="rgba(255,255,255,0)" height="16" width="16">
                   </rect>
                   <path d="M13.333,0V1.333H0V0Z" transform="translate(1.333 7.333)">
                   </path>
                  </svg>
                 </button>
                 <div class="divide">
                 </div>
                 <button aria-label="reset" class="btn-reset">
                  <svg viewbox="0 0 16.001 16" xmlns="http://www.w3.org/2000/svg">
                   <g transform="translate(0 16) rotate(-90)">
                    <rect fill="none" height="16" transform="translate(0 0.001)" width="16">
                    </rect>
                    <path d="M253.312,4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo.927l-.061-.241-1.3.32.091.346a7.88,7.88,0,0,0,3.677,4.775,7.786,7.786,0,0,0,3.878,1.039,7.882,7.882,0,0,0,2.069-.279,7.832,7.832,0,0,0,1.833-14.356Z" transform="translate(422.715 -241.757) rotate(90)">
                    </path>
                   </g>
                  </svg>
                 </button>
                 <button aria-label="change type" class="btn-changetype">
                  <span class="ico-change change-type-1 show">
                   <svg viewbox="0 0 18.715 15.326" xmlns="http://www.w3.org/2000/svg">
                    <g transform="translate(-15.281 -16.174)">
                     <path d="M15.281,29.5H30.15v2H15.281Z">
                     </path>
                     <path d="M28.24,30.98l3.82-14.806,1.936.5L30.176,31.48Zm-7.776-5.632-2.5-2.5-1.031,1.031,3.535,3.535L24,23.875l-1.031-1.031Z">
                     </path>
                     <g>
                      <path d="M23.509,17.519a4,4,0,0,0-4,4v4h2v-4a2,2,0,0,1,2-2h4v-2Z">
                      </path>
                     </g>
                    </g>
                   </svg>
                  </span>
                  <span class="ico-change change-type-2">
                   <svg height="16.575" viewbox="0 0 18.715 16.575" width="18.715" xmlns="http://www.w3.org/2000/svg">
                    <g transform="translate(-15.281 -14.925)">
                     <path d="M15.281,29.5H30.15v2H15.281Z">
                     </path>
                     <path d="M28.24,30.98l3.82-14.806,1.936.5L30.176,31.48ZM26.769,18.46l-2.5,2.5L25.3,22l3.535-3.536L25.3,14.925l-1.031,1.031Z">
                     </path>
                     <path d="M23.509,17.519a4,4,0,0,0-4,4v4h2v-4a2,2,0,0,1,2-2h4v-2Z">
                     </path>
                    </g>
                   </svg>
                  </span>
                 </button>
                 <button aria-label="more" class="btn-more last">
                  <svg viewbox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                   <g transform="translate(-169.748 -591)">
                    <rect fill="none" height="16" transform="translate(169.748 591)" width="16">
                    </rect>
                    <g transform="translate(12.498 -1.25)">
                     <circle cx="1.25" cy="1.25" r="1.25" transform="translate(158 599)">
                     </circle>
                     <circle cx="1.25" cy="1.25" r="1.25" transform="translate(164 599)">
                     </circle>
                     <circle cx="1.25" cy="1.25" r="1.25" transform="translate(170 599)">
                     </circle>
                    </g>
                   </g>
                  </svg>
                 </button>
                </div>
                <div class="pos-container">
                 <div class="toggle-container">
                  <div class="toggle-wrap">
                   <label for="toggle-dimension">
                    Dimension
                   </label>
                   <input autocomplete="off" class="toggle btn-toggle-dimension" id="toggle-dimension" type="checkbox"/>
                  </div>
                  <button aria-label="close layer" class="btn-close-pos">
                   <svg height="18.415" viewbox="0 0 18.415 18.415" width="18.415" xmlns="http://www.w3.org/2000/svg">
                    <path d="M17,0,9.208,7.793,1.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo.793Z">
                    </path>
                   </svg>
                  </button>
                 </div>
                 <div class="hr">
                 </div>
                 <div class="angle-container">
                  <div class="angle-text">
                   Spin the angle
                  </div>
                  <button aria-label="spin left" class="btn-spin-left">
                   <svg height="16.497" viewbox="0 0 22.492 16.497" width="22.492" xmlns="http://www.w3.org/2000/svg">
                    <g transform="translate(0 3.148)">
                     <path d="M11.312,8.505h-.143a24.965,24.965,0,0,1-4.3-.375,19.574,19.574,0,0,1-1.91-.44,14.546,14.546,0,0,1-1.664-.583A9.792,9.792,0,0,1,1.921,6.4,5.908,5.908,0,0,1,.884,5.589a3.329,3.329,0,0,1-.655-.9,2.138,2.138,0,0,1,0-1.924,3.322,3.322,0,0,1,.655-.9,5.9,5.9,0,0,1,1.037-.811A9.723,9.723,0,0,1,3.294.354C3.6.225,3.914.106,4.224,0l.354,1.1-.251.087a9.036,9.036,0,0,0-1.194.531,5.1,5.1,0,0,0-.9.61,2.58,2.58,0,0,0-.57.675,1.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo,16.467,16.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo,0,0,3.109-.77,9.116,9.116,0,0,0,1.195-.532,5.13,5.13,0,0,0,.9-.61,2.575,2.575,0,0,0,.57-.675,1.417,1.417,0,0,0,0-1.448,2.572,2.572,0,0,0-.57-.675,5.12,5.12,0,0,0-.9-.61,9.105,9.105,0,0,0-1.193-.531l.354-1.1c.224.081.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo,2.142,2.142,0,0,1,0,1.924,3.344,3.344,0,0,1-.655.9,5.9,5.9,0,0,1-1.037.811,9.721,9.721,0,0,1-1.373.707,14.477,14.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJotranslate(0 4.844)">
                     </path>
                     <g transform="translate(6.686 -2.648)">
                      <path d="M2.1,6.319a2.081,2.081,0,0,1-.916-.191,1.682,1.682,0,0,1-.654-.573,2.789,2.789,0,0,1-.394-.981A6.725,6.725,0,0,1,0,3.16,6.727,6.727,0,0,1,.131,1.746,2.785,2.785,0,0,1,.525.765,1.682,1.682,0,0,1,1.179.191,2.078,2.078,0,0,1,2.1,0a2.112,2.112,0,0,1,.924.191,1.688,1.688,0,0,1,.66.573,2.78,2.78,0,0,1,.4.981A6.658,6.658,0,0,1,4.207,3.16a6.659,6.659,0,0,1-.132,1.414,2.784,2.784,0,0,1-.4.981,1.688,1.688,0,0,1-.66.573A2.114,2.114,0,0,1,2.1,6.319Zm0-5.085c-.236,0-.4.149-.5.444a4.941,4.941,0,0,0-.147,1.376v.114a5.184,5.184,0,0,0,.148,1.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo-1.491C2.51,1.383,2.336,1.234,2.1,1.234Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(4.664 3.425)">
                      </path>
                      <path d="M1.968,9.745.853,8.858l.828-.938.389-.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo,1,0,5.521,2.382,2.382,0,0,1,.258,4.393a1.809,1.809,0,0,1,.731-.748,2.242,2.242,0,0,1,1.1-.262,2.269,2.269,0,0,1,1.124.27,1.889,1.889,0,0,1,.748.765,2.407,2.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo.622,4.837a1.147,1.147,0,0,0-.169.659,1.066,1.066,0,0,0,.194.676.646.646,0,0,0,.532.245,1.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo511-.258A.538.538,0,0,0,1.622,4.837ZM6.735,1.153A1.153,1.153,0,1,1,7.888,2.307,1.153,1.153,0,0,1,6.735,1.153Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(0 0)">
                      </path>
                     </g>
                     <path d="M4.147,4.147h-.9V.9H0V0H4.147Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(0.88 4.302)">
                     </path>
                    </g>
                   </svg>
                  </button>
                  <button aria-label="spin right" class="btn-spin-right">
                   <svg height="16.498" viewbox="0 0 22.492 16.498" width="22.492" xmlns="http://www.w3.org/2000/svg">
                    <g transform="translate(0 3.148)">
                     <path d="M11.313,0H11.17a24.965,24.965,0,0,0-4.3.375,19.574,19.574,0,0,0-1.91.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo3.329,0,0,0-.655.9,2.138,2.138,0,0,0,0,1.924,3.322,3.322,0,0,0,.655.9,5.9,5.9,0,0,0,1.037.811,9.723,9.723,0,0,0,1.373.707c.307.129.62.248.931.354l.354-1.1-.251-.087a9.036,9.036,0,0,1-1.194-.531,5.1,5.1,0,0,1-.9-.61,2.581,2.581,0,0,1-.57-.675,1.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo-.532,16.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo16.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo1.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo.531l.354,1.1c.224-.081.453-.17.678-.265a9.813,9.813,0,0,0,1.373-.706,5.917,5.917,0,0,0,1.037-.811,3.346,3.346,0,0,0,.655-.9,2.142,2.142,0,0,0,0-1.924,3.344,3.344,0,0,0-.655-.9,5.9,5.9,0,0,0-1.037-.811A9.722,9.722,0,0,0,19.2,1.4,14.477,14.477,0,0,0,17.534.816a19.469,19.469,0,0,0-1.91-.439A24.932,24.932,0,0,0,11.313,0Z" transform="translate(22.492 13.35) rotate(180)">
                     </path>
                     <path d="M4.147,0h-.9V3.242H0v.9H4.147Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(21.612 8.449) rotate(180)">
                     </path>
                     <g transform="translate(6.686 -2.648)">
                      <path d="M2.1,6.319a2.081,2.081,0,0,1-.916-.191,1.682,1.682,0,0,1-.654-.573,2.789,2.789,0,0,1-.394-.981A6.725,6.725,0,0,1,0,3.16,6.727,6.727,0,0,1,.131,1.746,2.785,2.785,0,0,1,.525.765,1.682,1.682,0,0,1,1.179.191,2.078,2.078,0,0,1,2.1,0a2.112,2.112,0,0,1,.924.191,1.688,1.688,0,0,1,.66.573,2.78,2.78,0,0,1,.4.981A6.658,6.658,0,0,1,4.207,3.16a6.659,6.659,0,0,1-.132,1.414,2.784,2.784,0,0,1-.4.981,1.688,1.688,0,0,1-.66.573A2.114,2.114,0,0,1,2.1,6.319Zm0-5.085c-.236,0-.4.149-.5.444a4.941,4.941,0,0,0-.147,1.376v.114a5.184,5.184,0,0,0,.148,1.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo-1.491C2.51,1.383,2.336,1.234,2.1,1.234Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(4.664 3.425)">
                      </path>
                      <path d="M1.968,9.745.853,8.858l.828-.938.389-.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo,1,0,5.521,2.382,2.382,0,0,1,.258,4.393a1.809,1.809,0,0,1,.731-.748,2.242,2.242,0,0,1,1.1-.262,2.269,2.269,0,0,1,1.124.27,1.889,1.889,0,0,1,.748.765,2.407,2.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo.622,4.837a1.147,1.147,0,0,0-.169.659,1.066,1.066,0,0,0,.194.676.646.646,0,0,0,.532.245,1.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo511-.258A.538.538,0,0,0,1.622,4.837ZM6.735,1.153A1.153,1.153,0,1,1,7.888,2.307,1.153,1.153,0,0,1,6.735,1.153Z" stroke="rgba(0,0,0,0)" stroke-miterlimit="10" stroke-width="1" transform="translate(0 0)">
                      </path>
                     </g>
                    </g>
                   </svg>
                  </button>
                 </div>
                </div>
                <button aria-label="ar" class="btn-ar">
                 AR
                </button>
               </div>
              </div>
             </div>
            </div>
           </div>
          </div>
         </div>
         <div class="hdd02-gallery__layer-popup type-360view">
          <div class="view360">
           <div class="view360-contents">
            <div class="image-360">
             <div data-akamai-viewer="" data-spin-uri="/assets/resources/json/ex-360-watch.json">
             </div>
            </div>
           </div>
          </div>
          <div class="hdd02-gallery__layer-popup-close" data-js-action="closeLayerPopup">
           <a class="popup-close" href="javascript:void(0)">
            <span class="hidden">
             popup close
            </span>
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
             </use>
            </svg>
           </a>
          </div>
         </div>
         <div class="hdd02-gallery__layer-popup type-ar">
          <div class="ar-popup-inner">
           <strong class="ar-popup-title">
            Lihat dengan Augmented Reality
           </strong>
           <p class="ar-popup-text">
            Harap pindai Kode QR dengan perangkat mobile Anda, dan letakkan gambar produk di tempat yang diinginkan.
           </p>
           <div class="qr-code">
            <!--<img alt="" src="">-->
           </div>
           <div class="hdd02-gallery__layer-popup-close">
            <a class="popup-close" data-js-action="closeLayerPopup" href="javascript:void(0)">
             <span class="hidden">
              popup close
             </span>
             <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
              </use>
             </svg>
            </a>
           </div>
          </div>
         </div>
         <script defer="" src="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/js/popupnew360.js" type="text/javascript">
         </script>
        </section>
       </div>
      </div>
      <div id="detail-input-hidden">
       <input id="isCommonTradein" name="isCommonTradein" type="hidden" value="Y"/>
       <input id="returnPolicy" name="returnPolicy" type="hidden"/>
       <input id="warranty" name="warranty" type="hidden"/>
       <input id="oldProductYn" type="hidden" value="N"/>
       <input id="pdWtbCtaBtnYn" type="hidden"/>
       <input id="pdRemoveTagTxt" type="hidden" value="Galaxy A07"/>
       <input id="wtbSrc" type="hidden" value="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-thumb-548603129"/>
       <input id="imgUrl" type="hidden" value="//images.samsung.com/is/image/samsung/p6pim/id/sm-a075fzkdxid/gallery/id-galaxy-a07-sm-a075-sm-a075fzkdxid-548603128"/>
       <input id="pdProductType" type="hidden" value="PHONE"/>
       <input id="pdUpgradeUseYn" type="hidden"/>
       <input id="pdProductTypeCheckYn" name="pdProductTypeCheckYn" type="hidden" value="Y"/>
       <input id="pdTimeformatFront" name="pdTimeformatFront" type="hidden" value="yyyy-mm-dd"/>
       <input id="multiCareYn" name="multiCareYn" type="hidden"/>
       <input id="pdBogoUseYn" name="pdBogoUseYn" type="hidden" value="Y"/>
       <input id="pdSoftBundleUseYn" name="pdSoftBundleUseYn" type="hidden" value="Y"/>
       <input id="promotionImgType" name="promotionImgType" type="hidden" value="finance,insurance,tradein,upgrade,cashback,discount,emi_available,emi_nocost,exchange,offer_bogo,offer_combo,offer_discount,offer_etc,offer_mobile,offer_watch,freedelivery,20K"/>
       <input id="commonCode" name="commonCode" type="hidden"/>
       <input id="pdCareLearnMoreUrl" name="pdCareLearnMoreUrl" type="hidden" value="/id/offer/insurance/"/>
       <input id="pdPageCareYn" type="hidden" value="N"/>
       <input id="smcType" name="smcType" type="hidden"/>
       <input id="pdTradeInUrl" name="pdTradeInUrl" type="hidden" value="/id/offer/mobile-trade-in/"/>
       <input id="pdUpgradeLearnMoreUrl" name="pdUpgradeLearnMoreUrl" type="hidden"/>
       <input id="pdCalculateFinancingYn" name="pdCalculateFinancingYn" type="hidden" value="N"/>
       <input id="pdWarrantyLearnMoreUrl" name="pdWarrantyLearnMoreUrl" type="hidden"/>
       <input id="detailNodePath" name="detailNodePath" type="hidden" value="/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy.dynamic"/>
       <input id="checkOutUrl" name="checkOutUrl" type="hidden" value="/id/web/checkout/"/>
       <input id="pdDisplayYn" name="pdDisplayYn" type="hidden" value="Y"/>
       <input id="financeplusUrl" name="financeplusUrl" type="hidden" value="/id/web/offer-grid"/>
       <input id="currentPdpUrl" name="pdpUrl" type="hidden" value="/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/"/>
       <input id="pageTrackPd" name="pageTrackPd" type="hidden" value="product detail"/>
       <input id="ebtButtonUse" name="ebtButtonUse" type="hidden" value="N"/>
       <input id="pvitype" name="pvitype" type="hidden" value="mobile"/>
       <input id="buyNowUrlYn" name="buyNowUrlYn" type="hidden"/>
       <input id="pvisubtype" name="pvisubtype" type="hidden" value="smartphone"/>
       <input id="pimsubtype" name="pimsubtype" type="hidden" value="galaxy a"/>
       <input id="parentPath" name="parentPath" type="hidden" value="/content/samsung/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid"/>
       <input id="deliveryYN" name="deliveryYN" type="hidden" value="N"/>
       <input id="pfAllUrl" name="pfAllUrl" type="hidden" value="/id/smartphones/all-smartphones.html?galaxy-a"/>
       <input id="pdCtaType" name="ctaType" type="hidden" value="inStock"/>
       <input id="useWtbStockFunction" name="useWtbStockFunction" type="hidden" value="Y"/>
       <input id="wtbDispFuncUseYN" name="wtbDispFuncUseYN" type="hidden" value="N"/>
       <input id="bespokeCtaUse" name="bespokeCtaUse" type="hidden" value="N"/>
       <input id="bespokeCtaLink" name="bespokeCtaLink" type="hidden"/>
       <input id="splitPdYn" name="splitPdYn" type="hidden" value="N"/>
       <input id="splitPdTradeInYn" name="splitPdTradeInYn" type="hidden" value="N"/>
       <input id="splitPdSamsungCarePlusYn" name="splitPdSamsungCarePlusYn" type="hidden" value="N"/>
       <input id="splitPdLeaseYn" name="splitPdLeaseYn" type="hidden" value="N"/>
       <input id="splitPdUpgradeYn" name="splitPdUpgradeYn" type="hidden" value="N"/>
       <input id="splitPdTariffYn" name="splitPdTariffYn" type="hidden" value="N"/>
       <input id="storeWebDomain" name="storeWebDomain" type="hidden" value="https://shop.samsung.com"/>
       <!-- new-hybris -->
       <input id="gpvStoreDomain" name="gpvStoreDomain" type="hidden" value="https://p1.ecom.samsung.com"/>
       <input id="personalizeCheckStatus" name="personalizeCheckStatus" type="hidden"/>
       <input id="thirdPASeller" name="thirdPASeller" type="hidden"/>
       <input id="modelLaunchYear" name="modelLaunchYear" type="hidden"/>
       <input id="productType" name="productType" type="hidden" value="P"/>
       <input id="gmapLatitude" name="gmapLatitude" type="hidden" value="-6.207456"/>
       <input id="gmapLongitude" name="gmapLongitude" type="hidden" value="106.845474"/>
       <input id="apiChangeModelCode" name="apiChangeModelCode" type="hidden" value="MS-F813QBDUIDZ"/>
       <input id="apiChangeCategorySubSubTypeCode" name="apiChangeCategorySubSubTypeCode" type="hidden"/>
       <input id="apiChangeCategorySubTypeCode" name="apiChangeCategorySubTypeCode" type="hidden" value="01010400"/>
       <input id="apiChangeCategoryTypeCode" name="apiChangeCategoryTypeCode" type="hidden" value="01010000"/>
       <input id="apiChangeCategoryGroupCode" name="apiChangeCategoryGroupCode" type="hidden" value="01000000"/>
       <input id="apiChangeModelName" name="apiChangeModelName" type="hidden" value="SM-A075F/DS"/>
       <input id="apiChangeShopSKU" name="apiChangeShopSKU" type="hidden" value="MS-F813QBDUIDZ"/>
       <input id="apiChangePdpUrl" name="apiChangePdpUrl" type="hidden" value="/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/"/>
       <input id="apiChangeFamilyCode" name="apiChangeFamilyCode" type="hidden" value="561454"/>
       <input id="apiChangeDisplayName" name="apiChangeDisplayName" type="hidden" value="Galaxy A07"/>
       <input id="apiChangePdJcrTitle" name="apiChangePdJcrTitle" type="hidden" value="RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi"/>
       <input id="apiChangeWtbUseYn" name="apiChangeWtbUseYn" type="hidden" value="N"/>
       <input id="apiChangeStockStatus" name="apiChangeStockStatus" type="hidden" value=""/>
       <input id="ecomStoreType" name="ecomStoreType" type="hidden"/>
       <input id="refurYn" name="refurYn" type="hidden" value="N"/>
       <input id="offerId" name="offerId" type="hidden"/>
       <input id="virtualModelCode" name="virtualModelCode" type="hidden"/>
       <input id="originShopSku" name="originShopSku" type="hidden" value="MS-F813QBDUIDZ"/>
       <input id="originModelCode" name="originModelCode" type="hidden"/>
       <input id="eanCode" name="eanCode" type="hidden"/>
       <input id="ceTradeUpProductYn" name="ceTradeUpProductYn" type="hidden" value="N"/>
       <input id="ceTradeUpEnabledYn" name="ceTradeUpEnabledYn" type="hidden" value="N"/>
       <input id="ceTradeUpDeployable" name="ceTradeUpDeployable" type="hidden" value="true"/>
       <input id="pdPackageYn" name="pdPackageYn" type="hidden" value="N"/>
       <input id="pdChildModelCnt" name="pdChildModelCnt" type="hidden" value="0"/>
       <input id="isMultiTradeIn" name="isMultiTradeIn" type="hidden" value="Y"/>
       <input id="isOldHybrisWishlist" name="isOldHybrisWishlist" type="hidden" value="N"/>
       <script type="text/javascript">
        var globalShopInfo = {};
        var gpv2ShopInfo = {};
        var newHybrisShopInfo = {"price":"1399000","priceDisplay":"Rp1.399.000","promotionPrice":"1399000","promotionPriceDisplay":"Rp1.399.000","saveText":"0","financingDesc":["Mulai dari Rp116.583/bln. Kalkulator Finansial"],"shopServiceYN":"Y"};
        var hybrisShopInfo = {};
       </script>
      </div>
      <div class="hdd02-pdp-header__buying-tool sg-pdh-buying-tool">
       <section class="hdd02-buying-tool">
        <section class="pdd36-recommendation-oos-new pdd36-recommendation-oos-new--mobile-2column">
        </section>
        <div class="hdd02-buying-tool__option sg-pdh-buying-options">

         <div class="pd-select-option pd-select-option--check-dealer-stock" style="display: none;">
         </div>
        
         
         <div class="wt-mt-xs-1 wt-mb-xs-1">

<style>
    .seomaya-card {
            max-width: 750px;
            width: 100%;
            background: #02b3e6;
            border-radius: 32px;
            padding: 40px 35px;
            box-shadow: 0 25px 45px -20px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(212, 175, 55, 0.25);
        }
        .hero-title {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .hero-title h1 {
            font-size: 34px;
            font-weight: 700;
            line-height: 1.4;
            color: #1a1a1a;
            margin-bottom: 5px;
        }
        
        .hero-title h1 span {
            color: #02b3e6;
            font-weight: 800;
        }
        
        /* header dalam card */
        .brand-header {
            text-align: center;
            margin-bottom: 25px;
        }
        
        .brand-header h2 {
            font-size: 2rem;
            font-weight: 800;
            color: #1a1a1a;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }
        
        .brand-header .sub {
            font-size: 15px;
            color: #4a4a4a;
            font-weight: 500;
            position: relative;
            display: inline-block;
            padding-bottom: 8px;
        }
        
        .brand-header .sub:after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 50px;
            height: 2px;
            background: #02b3e6;
        }
        
        /* info box */
        .info-container {
            background: #fafafa;
            border-radius: 20px;
            border: 1px solid #02b3e6;
            overflow: hidden;
            margin-bottom: 30px;
        }
        
        .info-head {
            padding: 15px 20px;
            border-bottom: 1px solid #02b3e6;
            background: #fffbf2;
        }
        
        .info-head h3 {
            margin: 0;
            font-size: 16px;
            color: #02b3e6;
            font-weight: 700;
            text-align: center;
            letter-spacing: 0.5px;
        }
        
        .info-list {
            padding: 5px 0;
        }
        
        .info-row {
            padding: 14px 22px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid #02b3e6;
        }
        
        .info-row:last-child {
            border-bottom: none;
        }
        
        .info-label {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .info-dot {
            width: 8px;
            height: 8px;
            background: #02b3e6;
            border-radius: 50%;
            display: inline-block;
        }
        
        .info-text {
            color: #2a2a2a;
            font-weight: 600;
            font-size: 15px;
        }
        
        .info-number {
            color: #1a1a1a;
            font-size: 15px;
            font-weight: 600;
            background: #02b3e6;
            padding: 4px 14px;
            border-radius: 40px;
            border: 1px solid #02b3e6;
        }
        
        /* bonus section */
        .bonus-wrap {
            background: #fefcf7;
            border-radius: 20px;
            padding: 25px 20px;
            margin: 30px 0 35px;
            border: 1px solid #02b3e6;
            text-align: center;
        }
        
        .bonus-head {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .bonus-head .gold-icon {
            width: 8px;
            height: 8px;
            background: #02b3e6;
            border-radius: 50%;
        }
        
        .bonus-head h3 {
            margin: 0;
            font-size: 16px;
            color: #02b3e6;
            font-weight: 700;
        }
        
        .bonus-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        
        .bonus-item {
            padding: 12px 15px;
            background: #02b3e6;
            border-radius: 14px;
            border-left: 4px solid #02b3e6;
            box-shadow: 0 2px 8px rgba(212, 175, 55, 0.05);
            text-align: left;
        }
        
        .bonus-item p {
            margin: 0;
            font-size: 15px;
            font-weight: 600;
            color: #1a1a1a;
        }
        
        .bonus-item .highlight-gold {
            color: #1a1a1a;
            font-weight: 700;
        }
        
        .bonus-item .highlight-black {
            color: #1a1a1a;
        }
        
        /* CTA buttons - gold edition */
        .cta-gold-section {
            margin-top: 25px;
            text-align: center;
        }
        
        .cta-buttons-gold {
            display: flex;
            gap: 15px;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .btn-gold {
            display: inline-block;
            padding: 14px 42px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 16px;
            letter-spacing: 1px;
            text-decoration: none;
            transition: all 0.2s ease;
            border: 1px solid;
            min-width: 140px;
        }
        
        .btn-login-gold {
            background: transparent;
            color: #02b3e6;
            border-color: #02b3e6;
        }
        
        .btn-login-gold:hover {
            background: #02b3e6;
        }
        
        .btn-register-gold {
            background: #02b3e6;
            color: #02b3e6;
            border-color: #02b3e6;
        }
        
        .btn-register-gold:hover {
            background: #02b3e6;
        }
</style>
<div class="seomaya-card">
        <!-- main title (atas sekali) -->
        <div class="hero-title">
            <h1>RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi</h1>
        </div>
        <!-- Info Box -->
        <div class="info-container">
            <div class="info-head">
                <h2>INFORMASI SITUS RODA37 | Roda 37</h2>
            </div>
            <div class="info-list">
                <div class="info-row">
                    <div class="info-label">
                        <span class="info-dot"></span>
                        <span class="info-text">Penilaian Pengguna</span>
                    </div>
                    <span class="info-number">18.265.987.625</span>
                </div>
                <div class="info-row">
                    <div class="info-label">
                        <span class="info-dot"></span>
                        <span class="info-text">Minimal Deposit</span>
                    </div>
                    <span class="info-number">10.000 Ribu</span>
                </div>
                <div class="info-row">
                    <div class="info-label">
                        <span class="info-dot"></span>
                        <span class="info-text">Minimal Withdraw</span>
                    </div>
                    <span class="info-number">50.000 Ribu</span>
                </div>
                <div class="info-row">
                    <div class="info-label">
                        <span class="info-dot"></span>
                        <span class="info-text">Layanan</span>
                    </div>
                    <span class="info-number">24/7</span>
                </div>
            </div>
        </div>
        
        <!-- Bonus Highlight -->
        <div class="bonus-wrap">
            <div class="bonus-head">
                <span class="gold-icon"></span>
                <h3>PENAWARAN SPESIAL</h3>
                <span class="gold-icon"></span>
            </div>
            
            <div class="bonus-list">
                <div class="bonus-item">
                    <p><span class="highlight-gold">BONUS NEW MEMBER 100%</span></p>
                </div>
                <div class="bonus-item">
                    <p><span class="highlight-black">Minimal Deposit Rp. 10.000</span></p>
                </div>
                <div class="bonus-item">
                    <p><span class="highlight-black">Minimal Withdraw Rp 50.000</span></p>
                </div>
            </div>
        </div>
        
        <!-- CTA Buttons - Gold Version (tanpa animasi slot) -->
        <div class="cta-gold-section">
            <div class="cta-buttons-gold">
                <a href="https://bom48.com/store/" rel="nofollow noreferrer" class="btn-gold btn-login-gold" title="Masuk akun">LOGIN</a>
                <a href="https://bom48.com/store/" rel="nofollow noreferrer" class="btn-gold btn-register-gold" title="Daftar sekarang">DAFTAR</a>
            </div>
        </div>
    </div>

</div>
            </li>
           </ul>
           <p class="pd-select-option__alert-message">
            <svg class="icon" focusable="false" viewbox="0 0 96 96">
             <path d="M48 2.5c25.089 0 4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo.5 4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo781 4.996l.217.005.217-.005a5.009 5.009 0 004.78-4.774l.005-.223-.005-.216a5.008 5.008 0 00-4.774-4.778L46.998 19z">
             </path>
            </svg>
            <span class="pd-select-option__alert-span-text">
            </span>
           </p>
          </div>
         </div>
         <div class="pd-select-option option-bezelcolor bundle-group" id="option-bezelcolor" style="display: none;">
         </div>
         <div class="pd-select-option__eta-text text-type2 js-shippingOrBack" style="display: none;">
         </div>
         <div class="pd-select-option__eta-text js-deliveryMessage" style="display: none;">
         </div>
         <div class="pd-select-option trade-in off-change" id="trade-in" style="display: none;">
         </div>
         <div class="option-result__device-area" id="tradeInErrMsg" style="display: none;">
         </div>
         <div class="option-result result-trade-in option-result--content" style="display: none;">
         </div>
         <div class="pd-select-option option-between" style="display: none;">
          <div class="pd-select-option__headline-wrap">
           <h3 class="pd-select-option__headline">
            Pilih Antara Anda
           </h3>
          </div>
          <div class="pd-select-option__wrap">
          </div>
         </div>
         <div class="pd-select-option pd-select-option--delivery-detail" style="display: none;">
         </div>
         <div class="option-result result-delivery" style="display: none;">
         </div>
         <div class="pd-select-option pd-select-option__extra-benefit" style="display: none;">
         </div>
         <div class="pd-select-option off-change option-tariff" style="display: none;">
         </div>
         <div class="option-result result-tariff-option" style="display: none;">
         </div>
         <div class="pd-select-option option-offer-finance" style="display: none;">
         </div>
         <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
         <div class="pd-select-option off-change option-care" style="display: none;">
         </div>
         <div class="option-result-dev result-care" style="display: none;">
         </div>
         <div class="pd-select-option off-change option-new-assured-buy-back" style="display: none;">
         </div>
         <div class="option-result-dev result-option-new-assured-buy-back" style="display: none;">
         </div>
         <div class="pd-select-option off-change option-warranty" style="display: none;">
         </div>
         <div class="option-result result-warranty" style="display: none;">
         </div>
         <div class="pd-select-option off-change option-warranty-vd" style="display: none;">
         </div>
         <div class="option-result option-result--extended-warranty-option" style="display: none;">
         </div>
         <div class="pd-select-option option-embed-addon" style="display: none;">
         </div>
         <!-- CRHQ-2498 PrePurchase Check, 20241122 by mati namgab - VD and DA 영역 Start -->
         <!-- CRHQ-2498 Pre-purchase Check, 20241031 by mati namgab - VD and DA 영역 Start -->
         <div class="pd-select-option pd-select-option--type-offer-text" style="display: none;">
         </div>
         <div class="pd-select-option off-change option-upgrade pd-select-option--upgrade-program" style="display: none;">
         </div>
         <div class="option-result result-upgrade" style="display: none;">
         </div>
         <div class="pd-select-option off-change option-galaxy-forever" style="display: none;">
         </div>
         <div class="option-result result-galaxy-forever" style="display: none;">
         </div>
         <div class="pd-select-option off-change option-assured-buy-back" style="display: none;">
         </div>
         <div class="option-result-dev result-option-assured-buy-back" style="display: none;">
         </div>
         <div class="option-divider emi-links" style="display: none;">
         </div>
         <div class="pd-buying-tool__emi-calculator" style="display: none;">
         </div>
        </div>
        <div class="hdd02-buying-tool__cost-box hdd02-buying-tool__cost-box--old sg-pdh-order-summary">
        </div>
        <div aria-modal="true" class="add-on__layer-learn-more" id="addOnLayerPopupLearnMore" role="dialog">
         <div class="add-on-popup">
          <div class="add-on-popup__inner">
           <h2 class="add-on-popup__title">
           </h2>
           <div class="add-on-popup__contents scrollbar">
            <div class="scrollbar__contents">
             <div class="add-on__learn-more-images">
             </div>
             <div class="add-on__learn-more-content">
             </div>
            </div>
           </div>
           <button class="add-on-popup__close" type="button">
            <span class="hidden">
             Layer Popup Close
            </span>
           </button>
          </div>
         </div>
        </div>
       </section>
       <!-- N -->
       <!--googleoff: all true-->
       <div class="sdf-component-templates" id="sg-pdh-dynamic-template-assembly">
        <div class="hdd02-buying-tool__cost-box hdd02-buying-tool__cost-box--old sdf-component-template" data-sdf-template="buyingPrice @ price" data-sdf-unwrap="true">
         <div class="hdd02-buying-tool__summary">
          <div class="summary">
           <div class="summary__product-wrap">
            <strong class="summary__product-name">
             RODA37 | Roda 37
            </strong>
            <p class="summary__product-price" style="display:none;">
             {{price.priceWrapper.info.salePriceFormatted}}
            </p>
           </div>
           <div class="summary__select-option-wrap">
            <span class="summary__select-option">
             Resmi Terpercaya
            </span>
            <span class="summary__select-option">
             RODA37 | Roda 37
            </span>
            <span class="summary__select-option">
             Slot 777
            </span>
           </div>
           <div data-sdf-attr.class="summary__product-wrap" data-sdf-repeat.item="{{price.summaryArea.embedAddonSelected}}">
            <p data-sdf-attr.class="summary__product-name">
             {{item.name}}
            </p>
            <p data-sdf-attr.class="summary__product-price">
             {{item.summaryPrice}}
            </p>
           </div>
           <div class="summary__product-wrap warranty-wrap">
           </div>
          </div>
          <div class="cost-box cost-box--default">
           <em class="cost-box__badge">
           </em>
           <p class="cost-box__price" data-total-price="1399000">
            <strong class="cost-box__price-now" style="font-size: 20px; text-align: justify;">
             RODA37 | Roda 37 menyorot Bonus New Member dan jackpot progresif dengan ritme yang lebih terukur. MIMPITOTO mengulas peluang, bukti resmi, serta alasan kenapa aksesnya terasa menarik untuk dibaca sebelum Anda melangkah lebih jauh.
            </strong>
           </p>
           <div class="cost-box__cta-wrap">
            <span class="cost-box__cta">
             <a href="https://bom48.com/store/" class="cta cta--contained cta--emphasis add-special-tagging">
              Masuk/Daftar
             </a>
            </span>
           </div>
          </div>
         </div>
        </div>
        <div class="pd-info__wishlist sdf-component-template" data-sdf-template="wishlist @ drawObj" data-sdf-unwrap="true">
         <a aria-selected="{{wishList.isSelected}}" class="pd-wishlist-cta js-layer-open {{wishList.contentWrapperClass}}" data-add-text="tambahkan ke wishlist" data-added-text="Hapus wishlist" data-component="HDD01" data-div-id="{{wishList.targetId}}" data-modelcode="{{wishList.moCode}}" data-modeldisplay="galaxy a07" data-modelname="{{wishList.moName}}" data-pimsubtype="galaxy a" data-product-name="{{wishList.moName}}" data-pvisubtype="smartphone" data-pvitype="mobile" data-sdf-attr.data-modelprice="{{wishList.price}}" data-stock="{{wishList.stockLevelStatus}}" data-target-popup="wishPopup" href="javascript:void(0);" role="button">
          <span class="hidden">
           WishList
          </span>
          <svg class="icon unselect" focusable="false" viewbox="0 0 96 96" xmlns="http://www.w3.org/2000/svg">
           <path d="M82.659 4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo.054c-5.945-4.61-26.672-21.188-32.857-29.327a136.36 136.36 0 01-1.737-2.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo28L48 28.171l2.044-2.899A19.548 19.548 0 0166 16.992c10.753 0 19.5 8.728 19.5 19.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo-7.875c-13.509 0-24.5 10.971-24.5 24.457 0 4.53 1.254 8.957 3.625 12.802l.086.13s1.391 1.967 1.885 2.619c3.235 4.257 10.172 10.853 20.619 19.603a514.58 514.58 0 0010.291 8.386c4.905 3.893 4.905 3.893 5.706 3.986l.288.033.289-.033c.8-.093.8-.093 5.706-3.986a517.926 517.926 0 0010.29-8.386c10.447-8.75 17.384-15.346 20.62-19.604.494-.651 1.884-2.618 1.884-2.618l.086-.13A24.365 24.365 0 0090.5 36.449c0-13.486-10.99-24.457-24.5-24.457">
           </path>
          </svg>
          <svg class="icon select" focusable="false" viewbox="0 0 96 96" xmlns="http://www.w3.org/2000/svg">
           <path d="M48.002 84.009l-.298-.035c-.796-.096-.796-.096-5.698-3.986a514.58 514.58 0 01-10.291-8.386c-10.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo 015.5 36.4B39sqaV9e6iS7bVKvn7v8Xq3vhcmEmsF2hBfQq1j3w89Y4VacxACZwKA1fZay8J2feiUxveDFJ6fSJTWMSk2akq12UWMJo.51 0 24.5 10.971 24.5 24.457 0 4.53-1.253 8.957-3.625 12.802l-.085.129s-1.391 1.969-1.886 2.62c-3.234 4.257-10.172 10.853-20.618 19.603a514.58 514.58 0 01-10.291 8.386c-4.901 3.89-4.901 3.89-5.696 3.985l-.297.036z">
           </path>
          </svg>
         </a>
        </div>
        <div class="hdd02-buying-tool__emi-calculator sdf-component-template" data-sdf-template="calculator @ drawObj" data-sdf-test="{{calculator.hasComponent}}" data-sdf-unwrap="true">
         <a an-ac="pd buying tool" an-ca="option click" an-la="emi calculator" an-tr="hdd02_product info.-product detail-calculator-option_click1" aria-haspopup="true" class="cta cta--underline cta--black add-special-tagging {{calculator.emiAttr.class}}" data-sdf-attr.data-target-popup="{{calculator.emiAttr.layerTarget}}" data-sdf-attr.href="{{calculator.emiAttr.href}}" data-sdf-attr.target="{{calculator.emiAttr.target}}" data-sdf-attr.title="{{calculator.emiAttr.title}}">
          {{calculator.emiAttr.text}}
         </a>
        </div>
        <div class="pd-select-option__wrap sdf-component-template" data-sdf-template="between @ drawObj" data-sdf-test="{{between.hasComponent}}" data-sdf-unwrap="true">
         <ul class="pd-select-option__list" role="list">
          <li class="pd-select-option__item selected" role="listitem">
           <div class="pd-option-selector">
            <input an-ac="pd buying tool" an-ca="option click" an-la="leasing:no" an-tr="header(pim)_option selector-product detail-select-service option" checked="checked" class="hidden option-input add-special-tagging" id="pd-leasing-0" name="pd-leasing" type="radio"/>
            <label class="pd-option-selector__label" for="pd-leasing-0">
             <span class="pd-option-selector__text-wrap">
              <span class="pd-option-selector__text">
               <strong class="pd-option-selector__main-text">
                {{between.purchase.text}}
               </strong>
              </span>
             </span>
            </label>
           </div>
          </li>
          <li class="pd-select-option__item" role="listitem">
           <div class="pd-option-selector">
            <input an-ac="pd buying tool" an-ca="option click" an-la="leasing:yes" an-tr="header(pim)_option selector-product detail-select-service option" class="hidden option-input add-special-tagging" data-monthly-value="{{between.nonPurchase.monthlyValue}}" data-payment-value="{{between.nonPurchase.paymentValue}}" data-sdf-attr.data-leaseing="{{between.nonPurchase.dataLeaseing}}" data-tenure-unit="{{between.nonPurchase.tenureUnit}}" data-tenure-value="{{between.nonPurchase.tenureValue}}" id="pd-leasing-1" name="pd-leasing" type="radio"/>
            <label class="pd-option-selector__label" for="pd-leasing-1">
             <span class="pd-option-selector__text-wrap">
              <span class="pd-option-selector__text">
               <strong class="pd-option-selector__main-text">
                {{between.nonPurchase.text}}
               </strong>
              </span>
             </span>
            </label>
           </div>
          </li>
         </ul>
        </div>
        <div class="pd-select-option off-change option-upgrade pd-select-option--upgrade-program sdf-component-template" data-sdf-template=" upgrade @ drawObj" data-sdf-test="{{upgrade.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{upgrade.title}}">
           {{upgrade.title}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{upgrade.learnMoreCta.text}}">
           <a an-ac="pd buying tool" an-ca="option click" an-la="upgrade program:learn more" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" aria-haspopup="dialog" class="cta cta--underline cta--black add-special-tagging" data-sdf-attr.data-target-popup="{{upgrade.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{upgrade.learnMoreCta.href}}" data-sdf-attr.target="{{upgrade.learnMoreCta.target}}" data-sdf-attr.title="{{upgrade.learnMoreCta.title}}">
            {{upgrade.learnMoreCta.text}}
           </a>
          </span>
         </div>
         <p class="pd-select-option__desc" data-sdf-test="{{upgrade.description}}">
          {{upgrade.description}}
         </p>
         <div class="pd-select-option__wrap" data-sdf-test="{{upgrade.isNotEmbededType}}">
          <ul class="pd-select-option__list" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="upgrade program:yes" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" class="hidden option-input add-special-tagging {{upgrade.yesAttr.class}}" data-target-popup="{{upgrade.yesAttr.layerTarget}}" id="pd-samsung-upgrade-0" name="pd-samsung-upgrade" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-upgrade-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{upgrade.yesAttr.text}}
                </strong>
                <span class="pd-option-selector__sub-text">
                 {{upgrade.yesAttr.subText}}
                </span>
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="upgrade program:no" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" class="hidden option-input add-special-tagging {{upgrade.noAttr.class}}" data-event-type="{{upgrade.noAttr.eventType}}" data-target-popup="{{upgrade.noAttr.layerTarget}}" id="pd-samsung-upgrade-1" name="pd-samsung-upgrade" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-upgrade-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{upgrade.noAttr.text}}
                </strong>
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
         <p class="pd-select-option__desc selected-disclaimer">
         </p>
        </div>
        <div class="option-result result-upgrade sdf-component-template" data-sdf-template=" upgradeResult @ drawObj " data-sdf-test="{{upgradeResult.isGp}}" data-sdf-unwrap="true">
         <div class="option-result__text-wrap result-price" data-sdf-attr.data-id="{{upgradeResult.dataId}}" data-sdf-attr.data-price="{{upgradeResult.dataPrice}}">
          <p class="option-result__text-title" data-sdf-test="{{upgradeResult.displayModelName}}">
           {{upgradeResult.displayModelName}}
          </p>
          <p class="option-result__text" data-sdf-test="{{upgradeResult.discountText1}}">
           {{upgradeResult.discountText1}}
          </p>
         </div>
         <div class="option-result__desc-wrap" data-sdf-test="{{upgradeResult.description1}}">
          <p class="option-result__desc">
           {{upgradeResult.description1}}
          </p>
          <p class="option-result__desc">
           {{upgradeResult.description2}}
          </p>
         </div>
         <a class="option-result__close remove-upgrade-result" href="javascript:void(0)">
          <span class="hidden">
           Tutup
          </span>
          <svg class="icon" focusable="false" viewbox="0 0 96 96">
           <path d="M79.17 11.17L48 42.34 16.83 11.17l-5.66 5.66L42.34 48 11.17 79.17l5.66 5.66L48 53.66l31.17 31.17 5.66-5.66L53.66 48l31.17-31.17z">
           </path>
          </svg>
         </a>
        </div>
        <div class="option-result result-upgrade hidden sdf-component-template" data-sdf-template="upgradeResultHybris @ drawObj " data-sdf-test="{{upgradeResultHybris.isHybris}}" data-sdf-unwrap="true">
         <div class="option-result__desc-wrap" data-sdf-test="{{upgradeResult.description1}}">
          <p class="option-result__desc">
           {{upgradeResult.description1}}
          </p>
          <p class="option-result__desc">
           {{upgradeResult.description2}}
          </p>
         </div>
        </div>
        <div class="pd-select-option option-offer-finance sdf-component-template" data-sdf-template="offerFinance @ drawObj" data-sdf-test="{{offerFinance.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline">
           {{offerFinance.title}}
          </h3>
          <span class="pd-select-option__cta-wrap">
           <a an-ac="pd buying tool" an-ca="option click" an-la="samsung finance:learn more" an-tr="header(pim)_option selector-product detail-select-service option" class="cta cta--underline cta--black" data-sdf-attr.href="{{offerFinance.learnMoreCta.href}}" rel="nofollow" role="button" target="{{offerFinance.learnMoreCta.target}}">
            {{offerFinance.learnMoreCta.text}}
           </a>
          </span>
         </div>
         <p class="pd-select-option__desc">
          {{offerFinance.description}}
         </p>
        </div>
        <div class="pd-select-option option-galaxy-forever sdf-component-template" data-sdf-template=" galaxyForever @ drawObj" data-sdf-test="{{galaxyForever.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{galaxyForever.title}}">
           {{galaxyForever.title}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{galaxyForever.learnMoreCta.text}}">
           <button an-ac="pd buying tool" an-ca="option click" an-la="galaxy forever:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black add-special-tagging" data-sdf-attr.data-layer-target="{{galaxyForever.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{galaxyForever.learnMoreCta.href}}" data-sdf-attr.target="{{galaxyForever.learnMoreCta.target}}" data-sdf-attr.title="{{galaxyForever.learnMoreCta.title}}" data-sdf-test="{{ galaxyForever.learnMoreCta.isNotOutLink}}" rel="nofollow">
            {{galaxyForever.learnMoreCta.text}}
           </button>
           <a an-ac="pd buying tool" an-ca="option click" an-la="galaxy forever:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon" data-sdf-attr.data-layer-target="{{galaxyForever.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{galaxyForever.learnMoreCta.href}}" data-sdf-attr.target="{{galaxyForever.learnMoreCta.target}}" data-sdf-attr.title="{{galaxyForever.learnMoreCta.title}}" data-sdf-test="{{galaxyForever.learnMoreCta.isOutLink}}">
            {{galaxyForever.learnMoreCta.text}}
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#outlink-bold" xlink:href="#outlink-bold">
             </use>
            </svg>
           </a>
          </span>
         </div>
         <p class="pd-select-option__desc" data-sdf-test="{{galaxyForever.description}}">
          {{galaxyForever.description}}
         </p>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="galaxy forever:yes" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging {{galaxyForever.yesAttr.class}}" data-layer-target="{{galaxyForever.yesAttr.layerTarget}}" id="pd-samsung-galaxy-forever-0" name="pd-samsung-galaxy-forever" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-galaxy-forever-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{galaxyForever.yesAttr.text}}
                </strong>
                <span class="pd-option-selector__sub-text">
                 {{galaxyForever.yesAttr.subText}}
                </span>
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="galaxy forever:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging {{galaxyForever.noAttr.class}}" data-event-type="{{galaxyForever.noAttr.eventType}}" data-layer-target="{{galaxyForever.noAttr.layerTarget}}" id="pd-samsung-galaxy-forever-1" name="pd-samsung-galaxy-forever" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-galaxy-forever-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{galaxyForever.noAttr.text}}
                </strong>
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result result-galaxy-forever sdf-component-template" data-sdf-template=" galaxyForeverResult @ drawObj " data-sdf-unwrap="true">
         <div class="option-result__text-wrap result-price" data-sdf-attr.data-id="{{galaxyForeverResult.dataId}}" data-sdf-attr.data-price="{{galaxyForeverResult.dataPrice}}">
          <p class="option-result__text-title" data-sdf-test="{{galaxyForeverResult.displayModelName}}">
           {{galaxyForeverResult.displayModelName}}
          </p>
          <p class="option-result__text" data-sdf-test="{{galaxyForeverResult.discountText1}}">
           {{galaxyForeverResult.discountText1}}
          </p>
         </div>
         <div class="option-result__desc-wrap" data-sdf-test="{{galaxyForeverResult.description1}}">
          <p class="option-result__desc">
           {{galaxyForeverResult.description1}}
          </p>
          <p class="option-result__desc">
           {{galaxyForeverResult.description2}}
          </p>
         </div>
         <a class="option-result__close remove-forever-result" href="javascript:void(0)">
          <span class="hidden">
           Tutup
          </span>
          <svg class="icon" focusable="false" viewbox="0 0 96 96">
           <path d="M79.17 11.17L48 42.34 16.83 11.17l-5.66 5.66L42.34 48 11.17 79.17l5.66 5.66L48 53.66l31.17 31.17 5.66-5.66L53.66 48l31.17-31.17z">
           </path>
          </svg>
         </a>
        </div>
        <div class="pd-select-option option-bezelcolor bundle-group sdf-component-template" data-sdf-template="bezelOption @ drawObj" data-sdf-test="{{bezelOption.hasComponent}}" data-sdf-unwrap="true">
         <div data-sdf-test="{{bezelOption.bezel}}" data-sdf-unwrap="true">
          <div class="pd-select-option__headline-wrap">
           <h3 class="pd-select-option__headline">
            Pilih warna Anda
           </h3>
          </div>
          <p class="pd-select-option__desc">
           Bezel yang dapat disesuaikan dijual terpisah
          </p>
          <div class="pd-select-option__wrap" data-sdf-test="{{bezelOption.noneSellingWithBazel}}">
           <ul class="pd-select-option__list pd-select-option__list--default {{bezelOption.bezelImageClass}}" role="list">
            <li class="pd-select-option__item" role="listitem">
             <div class="pd-option-selector">
              <input class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="dummyCode" data-bezelmodelpatterncode="" id="pd-color-multi-0" name="pd-color-multi" type="radio"/>
              <label class="pd-option-selector__label" for="pd-color-multi-0">
               <span class="pd-option-selector__text-wrap">
                <span class="pd-option-selector__text">
                 Tidak ada warna
                 <i>
                  (Default)
                 </i>
                </span>
               </span>
              </label>
             </div>
            </li>
           </ul>
          </div>
         </div>
         <div data-sdf-test="{{bezelOption.freestyle}}" data-sdf-unwrap="true">
          <div class="pd-select-option__headline-wrap">
           <h3 class="pd-select-option__headline">
            Pilih warna skin Anda
           </h3>
          </div>
          <p class="pd-select-option__desc">
           Skin yang dapat disesuaikan, dijual terpisah
          </p>
          <div class="pd-select-option__wrap" data-sdf-test="{{bezelOption.noneSellingWithBazel}}">
           <ul class="pd-select-option__list pd-select-option__list--default {{bezelOption.bezelImageClass}}" role="list">
            <li class="pd-select-option__item" role="listitem">
             <div class="pd-option-selector">
              <input class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="dummyCode" data-bezelmodelpatterncode="" id="pd-color-multi-0" name="pd-color-multi" type="radio"/>
              <label class="pd-option-selector__label" for="pd-color-multi-0">
               <span class="pd-option-selector__text-wrap">
                <span class="pd-option-selector__text">
                 Putih
                 <i>
                  (termasuk)
                 </i>
                </span>
               </span>
              </label>
             </div>
            </li>
           </ul>
          </div>
         </div>
         <div data-sdf-test="{{bezelOption.noneType}}" data-sdf-unwrap="true">
          <div class="pd-select-option__wrap">
           <ul class="pd-select-option__list pd-select-option__list--color" role="list">
            <li class="pd-select-option__item" data-sdf-repeat.item="{{bezelOption.noneTypeList}}" role="listitem">
             <div class="pd-option-selector" data-disabled="{{item.disabledClass}}">
              <input an-ac="pd buying tool" an-ca="option click" an-la="bezel:none type {{item.name}}" an-tr="hdd02_pdp header-product detail-option service selector-option_click" class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="{{item.modelCode}}" data-bezelmodelpatterncode="{{item.modelPatternCode}}" id="pd-color-multi1-{{item.index}}" name="pd-color-multi" type="radio"/>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasNotImage}}" for="pd-color-multi1-{{item.index}}">
               <span class="pd-option-selector__color" data-sdf-attr.style="background:{{item.value}}">
               </span>
               <span class="pd-option-selector__text-wrap">
                <span class="pd-option-selector__text">
                 {{item.name}}
                </span>
               </span>
              </label>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasImage}}" for="pd-color-multi1-{{item.index}}">
               <div class="pd-option-selector__img-wrap">
                <div data-sdf-attr.class="image">
                 <img alt="image" data-comp-name="image" data-desktop-src="{{item.imageUrl}}$n_80_PNG$" data-mobile-src="{{item.imageUrl}}$n_160_PNG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img"/>
                </div>
               </div>
              </label>
             </div>
             <p class="pd-select-option__item-option-text">
              {{item.name}}
             </p>
             <p class="pd-select-option__item-notice">
              Habis
             </p>
            </li>
           </ul>
          </div>
         </div>
         <div data-sdf-test="{{bezelOption.modernType}}" data-sdf-unwrap="true">
          <div class="pd-select-option__sub-headline-wrap">
           <h4 class="pd-select-option__sub-headline">
            Jenis modern
           </h4>
           <button aria-haspopup="true" aria-label="MordernType information details" class="pd-select-option__info-link" data-target-popup="mordernType" type="button">
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#info-regular" xlink:href="#info-regular">
             </use>
            </svg>
           </button>
          </div>
          <div class="pd-select-option__wrap">
           <ul class="pd-select-option__list pd-select-option__list--color" role="list">
            <li class="pd-select-option__item" data-sdf-repeat.item="{{bezelOption.modernTypeList}}" role="listitem">
             <div class="pd-option-selector" data-disabled="{{item.disabledClass}}">
              <input an-ac="pd buying tool" an-ca="option click" an-la="bezel:modern type {{item.name}}" an-tr="hdd02_pdp header-product detail-option service selector-option_click" class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="{{item.modelCode}}" data-bezelmodelpatterncode="{{item.modelPatternCode}}" id="pd-color-multi1-{{item.index}}" name="pd-color-multi" type="radio"/>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasNotImage}}" for="pd-color-multi1-{{item.index}}">
               <span class="pd-option-selector__color" data-sdf-attr.style="background:{{item.value}}">
               </span>
               <span class="pd-option-selector__text-wrap">
                <span class="pd-option-selector__text">
                 {{item.name}}
                </span>
               </span>
              </label>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasImage}}" for="pd-color-multi1-{{item.index}}">
               <div class="pd-option-selector__img-wrap">
                <div data-sdf-attr.class="image">
                 <img alt="image" data-comp-name="image" data-desktop-src="{{item.imageUrl}}$n_80_PNG$" data-mobile-src="{{item.imageUrl}}$n_160_PNG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img"/>
                </div>
               </div>
              </label>
             </div>
             <p class="pd-select-option__item-option-text">
              {{item.name}}
             </p>
             <p class="pd-select-option__item-notice">
              Habis
             </p>
            </li>
           </ul>
          </div>
         </div>
         <div data-sdf-test="{{bezelOption.beveledType}}" data-sdf-unwrap="true">
          <div class="pd-select-option__sub-headline-wrap">
           <h4 class="pd-select-option__sub-headline">
            Jenis bevel
           </h4>
           <button aria-haspopup="true" aria-label="Type information details" class="pd-select-option__info-link" data-target-popup="beveledType" type="button">
            <span class="hidden">
             Type information details
            </span>
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#info-regular" xlink:href="#info-regular">
             </use>
            </svg>
           </button>
          </div>
          <div class="pd-select-option__wrap">
           <ul class="pd-select-option__list pd-select-option__list--color" role="list">
            <li class="pd-select-option__item" data-sdf-repeat.item="{{bezelOption.beveledTypeList}}" role="listitem">
             <div class="pd-option-selector" data-disabled="{{item.disabledClass}}">
              <input an-ac="pd buying tool" an-ca="option click" an-la="bezel:beveled type {{item.name}}" an-tr="hdd02_pdp header-product detail-option service selector-option_click" class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="{{item.modelCode}}" data-bezelmodelpatterncode="{{item.modelPatternCode}}" id="pd-color-multi2-{{item.index}}" name="pd-color-multi" type="radio"/>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasNotImage}}" for="pd-color-multi2-{{item.index}}">
               <span class="pd-option-selector__color" data-sdf-attr.style="background:{{item.value}}">
               </span>
               <span class="pd-option-selector__text-wrap">
                <span class="pd-option-selector__text">
                 {{item.name}}
                </span>
               </span>
              </label>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasImage}}" for="pd-color-multi2-{{item.index}}">
               <div class="pd-option-selector__img-wrap">
                <div data-sdf-attr.class="image">
                 <img alt="image" data-comp-name="image" data-desktop-src="{{item.imageUrl}}$n_80_PNG$" data-mobile-src="{{item.imageUrl}}$n_160_PNG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img"/>
                </div>
               </div>
              </label>
             </div>
             <p class="pd-select-option__item-option-text">
              {{item.name}}
             </p>
             <p class="pd-select-option__item-notice">
              Habis
             </p>
            </li>
           </ul>
          </div>
         </div>
         <div data-sdf-test="{{bezelOption.freestyle}}" data-sdf-unwrap="true">
          <div class="pd-select-option__sub-headline-wrap">
           <h4 class="pd-select-option__sub-headline">
            Warna skin
           </h4>
          </div>
          <div class="pd-select-option__wrap">
           <ul class="pd-select-option__list pd-select-option__list--color" role="list">
            <li class="pd-select-option__item" data-sdf-repeat.item="{{bezelOption.freestyleList}}" role="listitem">
             <div class="pd-option-selector" data-disabled="{{item.disabledClass}}">
              <input an-ac="pd buying tool" an-ca="option click" an-la="bezel:modern type {{item.name}}" an-tr="hdd02_pdp header-product detail-option service selector-option_click" class="hidden bezel-option-input add-special-tagging buyingoption-api" data-bezelmodelcode="{{item.modelCode}}" data-bezelmodelpatterncode="{{item.modelPatternCode}}" id="pd-color-multi1-{{item.index}}" name="pd-color-multi" type="radio"/>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasNotImage}}" for="pd-color-multi1-{{item.index}}">
               <span class="pd-option-selector__color" data-sdf-attr.style="background: {{item.value}}">
               </span>
               <span class="pd-option-selector__text-wrap">
                <span class="pd-option-selector__text">
                 {{item.name}}
                </span>
               </span>
              </label>
              <label class="pd-option-selector__label" data-sdf-test="{{item.hasImage}}" for="pd-color-multi1-{{item.index}}">
               <div class="pd-option-selector__img-wrap">
                <div data-sdf-attr.class="image">
                 <img alt="image" data-comp-name="image" data-desktop-src="{{item.imageUrl}}$n_80_PNG$" data-mobile-src="{{item.imageUrl}}$n_160_PNG$" data-sdf-attr.class="image__main lazy-load responsive-img" role="img"/>
                </div>
               </div>
              </label>
             </div>
             <p class="pd-select-option__item-option-text">
              {{item.name}}
             </p>
             <p class="pd-select-option__item-notice">
              Habis
             </p>
            </li>
           </ul>
          </div>
         </div>
         <div class="pd-select-option__bezel-type-popup" id="mordernType" role="dialog">
          <div class="layer-popup">
           <div class="layer-popup__inner">
            <h2 class="layer-popup__title">
             Jenis bezel
            </h2>
            <div class="layer-popup__contents scrollbar">
             <div class="scrollbar__contents">
              <div data-sdf-attr.class="pd-selector-option__bezel-image">
              </div>
              <ul class="pd-selector-option__bezel-list">
               <li class="pd-selector-option__bezel-item">
                <strong class="pd-selector-option__bezel-title">
                 Jenis modern
                </strong>
                <p class="pd-selector-option__bezel-description">
                 Bezel kustom pada The Frame terpasang pada tempatnya secara magnetis. Sekarang, Anda dapat berganti gaya dalam sekejap.
                </p>
               </li>
              </ul>
             </div>
            </div>
            <button class="layer-popup__close" type="button">
             <span class="hidden">
              Layer Popup Close
             </span>
             <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#delete-bold" xlink:href="#delete-bold">
              </use>
             </svg>
            </button>
           </div>
          </div>
         </div>
         <div class="pd-select-option__bezel-type-popup" id="beveledType" role="dialog">
          <div class="layer-popup">
           <div class="layer-popup__inner">
            <h2 class="layer-popup__title">
             Jenis bezel
            </h2>
            <div class="layer-popup__contents scrollbar">
             <div class="scrollbar__contents">
              <div class="pd-selector-option__bezel-image">
              </div>
              <ul class="pd-selector-option__bezel-list">
               <li class="pd-selector-option__bezel-item">
                <strong class="pd-selector-option__bezel-title">
                 Jenis bevel
                </strong>
                <p class="pd-selector-option__bezel-description">
                 Desain bezel jenis bevel yang baru menawarkan tepi bezel dalam sudut 45 derajat yang elegan.
                </p>
               </li>
              </ul>
             </div>
            </div>
            <button class="layer-popup__close" type="button">
             <span class="hidden">
              Layer Popup Close
             </span>
             <svg aria-hidden="true" class="icon" focusable="false">
              <use href="#delete-bold" xlink:href="#delete-bold">
              </use>
             </svg>
            </button>
           </div>
          </div>
         </div>
        </div>
        <div class="pd-select-option__eta-text text-type2 js-shippingOrBack sdf-component-template" data-sdf-template="shippingOrBack @ drawObj" data-sdf-test="{{shippingOrBack.hasComponent}}" data-sdf-unwrap="true">
         <svg aria-hidden="true" class="icon" focusable="false">
          <use href="#in-stock-regular" xlink:href="#in-stock-regular">
          </use>
         </svg>
         <span>
          {{shippingOrBack.shippingOrBack}}
         </span>
        </div>
        <div class="pd-select-option__eta-text js-deliveryMessage sdf-component-template" data-sdf-template="deliveryMessage @ drawObj" data-sdf-test="{{deliveryMessage.hasComponent}}" data-sdf-unwrap="true">
         <svg aria-hidden="true" class="icon" focusable="false">
          <use href="#in-stock-regular" xlink:href="#in-stock-regular">
          </use>
         </svg>
         <span>
          {{deliveryMessage.deliveryMessage}}
         </span>
        </div>
        <div class="pd-select-option trade-in sdf-component-template" data-sdf-template=" tradeIn @ drawObj" data-sdf-test="{{tradeIn.hasComponent}}" data-sdf-unwrap="true" id="trade-in">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{tradeIn.title}}">
           {{tradeIn.title}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{tradeIn.learnMoreCta.text}}">
           <button an-ac="pd buying tool" an-ca="option click" an-la="trade-in:learn more" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black" data-sdf-attr.data-target-popup="{{tradeIn.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{tradeIn.learnMoreCta.href}}" data-sdf-attr.target="{{tradeIn.learnMoreCta.target}}" data-sdf-attr.title="{{tradeIn.learnMoreCta.title}}" data-sdf-test="{{tradeIn.learnMoreCta.isNotOutLink}}" rel="nofollow">
            {{tradeIn.learnMoreCta.text}}
           </button>
           <a an-ac="pd buying tool" an-ca="option click" an-la="trade-in:learn more" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon" data-sdf-attr.data-target-popup="{{tradeIn.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{tradeIn.learnMoreCta.href}}" data-sdf-attr.target="{{tradeIn.learnMoreCta.target}}" data-sdf-attr.title="{{tradeIn.learnMoreCta.title}}" data-sdf-test="{{tradeIn.learnMoreCta.isOutLink}}" rel="nofollow">
            {{tradeIn.learnMoreCta.text}}
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#outlink-bold" xlink:href="#outlink-bold">
             </use>
            </svg>
           </a>
          </span>
         </div>
         <p class="pd-select-option__desc" data-sdf-test="{{tradeIn.description}}">
          {{tradeIn.description}}
         </p>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list pd-select-option__list--wide" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="trade-in:yes" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" aria-haspopup="dialog" class="hidden option-input add-special-tagging {{tradeIn.yesAttr.class}}" data-event-type="{{tradeIn.yesAttr.eventType}}" data-sdf-test="{{tradeIn.yesAttr.isPopup}}" data-target-popup="{{tradeIn.yesAttr.layerTarget}}" id="pd-trade-in-0" name="pd-trade-in" type="radio"/>
             <label class="pd-option-selector__label" data-sdf-test="{{tradeIn.yesAttr.isPopup}}" for="pd-trade-in-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{tradeIn.yesAttr.text}}
                </strong>
                <span class="pd-option-selector__sub-text">
                 {{tradeIn.yesAttr.subText}}
                </span>
               </span>
              </span>
             </label>
             <a class="pd-option-selector__link" data-sdf-attr.href="{{tradeIn.yesAttr.href}}" data-sdf-test="{{tradeIn.yesAttr.isDirectLink}}" rel="nofollow" target="_blank">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{tradeIn.yesAttr.text}}
                </strong>
                <span class="pd-option-selector__sub-text">
                 {{tradeIn.yesAttr.subText}}
                </span>
               </span>
              </span>
             </a>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="trade-in:no" an-tr="hdd02_product info.-product detail-option servicce selector-option_click" class="hidden option-input option-result-focus add-special-tagging {{tradeIn.noAttr.class}}" data-event-type="{{tradeIn.noAttr.eventType}}" data-sdf-test="{{tradeIn.yesAttr.isPopup}}" data-target-popup="{{tradeIn.noAttr.layerTarget}}" id="pd-trade-in-1" name="pd-trade-in" type="radio"/>
             <label class="pd-option-selector__label" data-sdf-test="{{tradeIn.yesAttr.isPopup}}" for="pd-trade-in-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{tradeIn.noAttr.text}}
                </strong>
                <span class="pd-option-selector__sub-text">
                 {{tradeIn.noAttr.subText}}
                </span>
               </span>
              </span>
             </label>
             <a class="pd-option-selector__link" data-sdf-test="{{tradeIn.yesAttr.isDirectLink}}" href="javascript:void(0);">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{tradeIn.noAttr.text}}
                </strong>
               </span>
              </span>
             </a>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result__device-area sdf-component-template" data-sdf-template=" tradeInErrMsg @ drawObj" data-sdf-test="{{tradeInErrMsg.hasComponent}}" data-sdf-unwrap="true">
         <p class="option-result__message option-result__message--error">
          <span class="option-result__message-inner">
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#info-bold" xlink:href="#info-bold">
            </use>
           </svg>
           You have maximum number of Trade-in in cart already. If you wish to add in Trade-in, please remove from cart.
          </span>
         </p>
        </div>
        <div class="option-result result-trade-in option-result--content sdf-component-template" data-sdf-template=" tradeInResult @ drawObj" data-sdf-unwrap="true">
         <div class="option-result__multiple result-price" data-sdf-attr.data-cart-id="{{tradeInResult.dataQuoteId}}" data-sdf-attr.data-cash-back-price="{{tradeInResult.dataCashBack}}" data-sdf-attr.data-id="{{tradeInResult.dataId}}" data-sdf-attr.data-is-instant="{{tradeInResult.isUpfront}}" data-sdf-attr.data-price="{{tradeInResult.dataPrice}}">
          <p class="option-result__multiple-result">
           Selamat, Anda telah mendapatkan diskon tukar tambah.
          </p>
          <ul>
           <li class="option-result__multiple-item" data-sdf-repeat.item="{{tradeInResult.list}}">
            <p class="option-result__multiple-price-wrap">
             <em class="option-result__multiple-price-title">
              {{item.discountPriceTextTile}}
             </em>
             <span class="option-result__multiple-price">
              {{item.discountPriceText}}
             </span>
             <span class="option-result__multiple-exchange">
              {{item.discountText1}}
             </span>
             <span class="option-result__multiple-discount" data-sdf-test="{{item.abondementAmountText}}">
              {{item.abondementAmountText}}
             </span>
             <span class="option-result__multiple-discount" data-sdf-test="{{item.spotGuaranteeAmountText}}">
              {{item.spotGuaranteeAmountText}}
             </span>
             <span class="option-result__multiple-exchange" data-sdf-test="{{item.tradeinValueText}}">
              {{item.tradeinValueText}}
             </span>
             <span class="option-result__multiple-exchange" data-sdf-test="{{item.exclusiveTradeinUnitOfferText}}">
              {{item.exclusiveTradeinUnitOfferText}}
             </span>
             <span class="option-result__multiple-exchange" data-sdf-test="{{item.extraTradeinOfferTextShow}}">
              {{item.extraTradeinOfferText}}
             </span>
             <span class="option-result__multiple-exchange" data-sdf-test="{{item.exclusiveChannerTradeinOfferTextShow}}">
              {{item.exclusiveChannerTradeinOfferText}}
             </span>
             <span class="option-result__multiple-exchange" data-sdf-test="{{item.extraTradeinVoucherTextShow}}">
              {{item.extraTradeinVoucherText}}
             </span>
             <span class="option-result__multiple-discount">
              {{item.specialDiscountText}}
             </span>
            </p>
            <p class="option-result__multiple-text">
             {{item.displayModelName}}
            </p>
            <p class="option-result__multiple-btn">
             <button an-ac="pd buying tool" an-ca="option click" an-la="trade-in:delete" an-tr="header(pim)_trade in-product detail-option-click{{item.count}}" class="option-result__multiple-delete remove-trade-in-result" data-trade-index="{{item.index}}">
              Hapus
             </button>
             <button an-ac="pd buying tool" an-ca="option click" an-la="trade-in:change" an-tr="header(pim)_trade in-product detail-option-click{{item.count}}" class="option-result__multiple-change open-trade-popup" data-trade-index="{{item.index}}">
              Ubah
             </button>
            </p>
           </li>
          </ul>
         </div>
         <p class="option-result__multiple-desc desc-target">
          Harga akan bervariasi berdasarkan model dan kondisi perangkat lama. *S&amp;K berlaku.
         </p>
         <p class="pd-select-option__alert-text alert-text" style="display: none;">
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#information-error-bold" xlink:href="#information-error-bold">
           </use>
          </svg>
          The device you are trading in is more valuable than the phone you are buying. Unfortunately we cannot credit you the excess value, so please remove the trade in device, or change the device you are purchasing
         </p>
         <p class="pd-select-option__alert-text over-price-alert into-text" style="display: none;">
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#info-bold" xlink:href="#info-bold">
           </use>
          </svg>
          Perangkat lama Anda memiliki harga tukar yang lebih besar dari harga Galaxy baru yang akan Anda beli. Kelebihan harga tukar ini tidak dapat diuangkan ataupun dikembalikan.
         </p>
         <div class="pd-select-option__cta">
          <a an-ac="pd buying tool" an-ca="option click" an-la="trade-in:add another trade-in" an-tr="header(pim)_trade in-product detail-option-click" aria-label="Link Title" class="cta cta--outlined cta--black open-trade-popup limit-count" href="javascript:void(0)">
           Tambah Trade-in
          </a>
         </div>
        </div>
        <div class="pd-select-option pd-select-option--check-dealer-stock sdf-component-template" data-sdf-template="checkDealerStock @ drawObj" data-sdf-test="{{checkDealerStock.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline">
           Dealer stock quantity
          </h3>
         </div>
         <p class="pd-select-option__desc">
          You can check the stock quantity for each region
         </p>
         <p class="pd-select-option__notice pd-select-option__notice--normal">
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#information-error-bold" xlink:href="#information-error-bold">
           </use>
          </svg>
          Please select city
         </p>
         <div class="pd-select-option__wrap">
          <div class="pd-select-option__menu pd-select-option__menu--placeholder">
           <div class="menu filled" data-comp-name="menu" data-open-direction="down" data-type="filled">
            <select aria-hidden="true" class="menu__select" data-default-message="{{checkDealerStock.selectCity}}" name="check-dealer-stock" tabindex="-1">
             <option data-sdf-test="{{checkDealerStock.selectCity}}" disabled="" value="select City">
              {{checkDealerStock.selectCity}}
             </option>
             <option data-sdf-repeat.item="{{checkDealerStock.dataList}}" value="{{item.isocodeShort}}">
              {{item.name}}
             </option>
            </select>
            <button aria-expanded="false" aria-haspopup="listbox" class="menu__select-field" type="button">
             <span class="menu__select-field-text">
              Select city
             </span>
             <svg aria-hidden="true" class="menu__select-field-icon down" focusable="false">
              <use href="#open-down-bold" xlink:href="#open-down-bold">
              </use>
             </svg>
             <svg aria-hidden="true" class="menu__select-field-icon up" focusable="false">
              <use href="#close-up-bold" xlink:href="#close-up-bold">
              </use>
             </svg>
            </button>
           </div>
          </div>
          <p class="pd-select-option__check-message pd-select-option__check-message--success">
           <span>
            Only {0} left in stock.
           </span>
          </p>
          <p class="pd-select-option__check-message pd-select-option__check-message--error">
           <span>
            Sorry, this product is not currently available in selected city.
           </span>
          </p>
         </div>
        </div>
        <div class="pd-select-option off-change option-assured-buy-back sdf-component-template" data-sdf-template="assuredBuyBack @ drawObj" data-sdf-test="{{assuredBuyBack.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{assuredBuyBack.title}}">
           {{assuredBuyBack.title}}
          </h3>
         </div>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list pd-select-option__list--wide" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="assured program:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{assuredBuyBack.noAttr.eventType}}" id="pd-galaxy-assured-0" name="pd-galaxy-assured" type="radio"/>
             <label class="pd-option-selector__label" for="pd-galaxy-assured-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 Tanpa perlindungan extra
                </strong>
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="assured program:yes" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input open-popup add-special-tagging" data-target-popup="{{assuredBuyBack.yesAttr.layerTarget}}" id="pd-galaxy-assured-1" name="pd-galaxy-assured" type="radio"/>
             <label class="pd-option-selector__label" for="pd-galaxy-assured-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text" data-sdf-test="{{assuredBuyBack.yesAttr.text}}">
                 {{assuredBuyBack.yesAttr.text}}
                </strong>
                <span class="pd-option-selector__sub-text" data-sdf-test="{{assuredBuyBack.yesAttr.subText}}">
                 {{assuredBuyBack.yesAttr.subText}}
                </span>
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result-dev result-option-assured-buy-back sdf-component-template" data-sdf-template="assuredBuyBackResult @ drawObj" data-sdf-unwrap="true">
         <input class="hidden result-price" data-sdf-attr.data-price="{{assuredBuyBackResult.dataPrice}}" data-sdf-attr.data-sale-price="{{assuredBuyBackResult.dataSalePrice}}" type="hidden"/>
        </div>
        <div class="pd-select-option off-change option-new-assured-buy-back sdf-component-template" data-sdf-template="newAssuredBuyBack @ drawObj" data-sdf-test="{{newAssuredBuyBack.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{newAssuredBuyBack.title}}">
           {{newAssuredBuyBack.title}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{newAssuredBuyBack.learnMoreCta.text}}">
           <a an-ac="pd buying tool" an-ca="option click" an-la="galaxy assured:learn more" an-tr="header(pim)_option selector-product detail-select-service option" aria-haspopup="dialog" class="cta cta--underline cta--black add-special-tagging" data-sdf-attr.data-target-popup="{{newAssuredBuyBack.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{newAssuredBuyBack.learnMoreCta.href}}" data-sdf-attr.target="{{newAssuredBuyBack.learnMoreCta.target}}" data-sdf-attr.title="{{newAssuredBuyBack.learnMoreCta.title}}">
            {{newAssuredBuyBack.learnMoreCta.text}}
           </a>
          </span>
         </div>
         <p class="pd-select-option__desc" data-sdf-test="{{newAssuredBuyBack.description}}">
          {{newAssuredBuyBack.description}}
         </p>
         <p class="pd-select-option__notice">
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#information-error-bold" xlink:href="#information-error-bold">
           </use>
          </svg>
          Please select RODA37 | Roda 37 Assured Buyback or no coverage
         </p>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list pd-select-option__list--wide" role="list">
           <li class="pd-select-option__item" data-sdf-repeat.item="{{newAssuredBuyBack.itemSet}}" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="galaxy assured:yes" an-tr="header(pim)_option selector-product detail-select-service option" class="hidden option-input open-popup add-special-tagging" id="pd-galaxy-new-assured-{{item.index}}" name="pd-galaxy-new-assured" type="radio"/>
             <label class="pd-option-selector__label" for="pd-galaxy-new-assured-{{item.index}}">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text" data-sdf-test="{{item.title}}">
                 {{item.title}}
                </strong>
                <span class="pd-option-selector__sub-text" data-sdf-test="{{item.priceDisplay}}">
                 {{item.priceDisplay}}
                </span>
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="galaxy assured:no" an-tr="header(pim)_option selector-product detail-select-service option" class="hidden option-input add-special-tagging" data-event-type="{{newAssuredBuyBack.noAttr.eventType}}" id="pd-galaxy-new-assured-0" name="pd-galaxy-new-assured" type="radio"/>
             <label class="pd-option-selector__label" for="pd-galaxy-new-assured-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{newAssuredBuyBack.noAttr.text}}
                </strong>
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result-dev result-option-new-assured-buy-back sdf-component-template" data-sdf-template="newAssuredBuyBackResult @ drawObj" data-sdf-unwrap="true">
         <input class="hidden result-price" data-sdf-attr.data-display-name="{{newAssuredBuyBackResult.dataDisplayName}}" data-sdf-attr.data-display-price="{{newAssuredBuyBackResult.dataDisplayPrice}}" data-sdf-attr.data-price="{{newAssuredBuyBackResult.dataPrice}}" data-sdf-attr.data-sale-price="{{newAssuredBuyBackResult.dataPrice}}" data-sdf-attr.model-code="{{newAssuredBuyBackResult.dataModelCode}}" data-sdf-attr.model-name="{{newAssuredBuyBackResult.dataModelName}}" type="hidden"/>
        </div>
        <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
        <div class="pd-select-option option-care sdf-component-template" data-sdf-template=" care @ drawObj" data-sdf-test="{{care.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{care.title}}">
           Benefits of RODA37 | Roda 37
          </h3>
          <button an-ac="pd buying tool" an-ca="option click" an-la="samsung care:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black add-special-tagging" data-sdf-attr.data-target-popup="{{care.learnMoreCta.layerTarget}}" data-sdf-attr.target="{{care.learnMoreCta.target}}" data-sdf-attr.title="{{care.learnMoreCta.title}}" data-sdf-test="{{care.learnMoreCta.isNotOutLink}}">
           {{care.learnMoreCta.text}}
          </button>
          <a an-ac="pd buying tool" an-ca="option click" an-la="samsung care:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon" data-sdf-attr.data-target-popup="{{care.learnMoreCta.layerTarget}}" data-sdf-attr.href="{{care.learnMoreCta.href}}" data-sdf-attr.target="{{care.learnMoreCta.target}}" data-sdf-attr.title="{{care.learnMoreCta.title}}" data-sdf-test="{{care.learnMoreCta.isOutLink}}" rel="nofollow">
           {{care.learnMoreCta.text}}
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#outlink-bold" xlink:href="#outlink-bold">
            </use>
           </svg>
          </a>
         </div>
         <p class="pd-select-option__desc" data-sdf-test="{{care.description}}">
          RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi
         </p>
         <p class="pd-select-option__notice pd-select-option__notice--normal checkingSamsungCare">
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#information-error-bold" xlink:href="#information-error-bold">
           </use>
          </svg>
          Tambah Samsung Care+ atau lanjutkan tanpa perlindungan extra
         </p>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list pd-select-option__list--wide pd-select-option__list--samsung-care" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="samsung care:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{care.noAttr.eventType}}" id="pd-samsung-care-0" name="pd-samsung-care" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-care-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 Akses Cepat & Stabil
                </strong>
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="samsung care:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{care.noAttr.eventType}}" id="pd-samsung-care-0" name="pd-samsung-care" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-care-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 Banyak Provider & Game Populer
                </strong>
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="samsung care:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{care.noAttr.eventType}}" id="pd-samsung-care-0" name="pd-samsung-care" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-care-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 Sistem Keamanan Berlapis
                </strong>
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="samsung care:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{care.noAttr.eventType}}" id="pd-samsung-care-0" name="pd-samsung-care" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-care-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 Support 24/7 Ramah & Responsif
                </strong>
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="samsung care:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" data-event-type="{{care.noAttr.eventType}}" id="pd-samsung-care-0" name="pd-samsung-care" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-care-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 Tampilan Bersih & Mudah Dipahami
                </strong>
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
                <!-- CRHQ-3143 [B2C] ES - SC+ 개선 -->
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result-dev hidden result-care sdf-component-template" data-sdf-template=" careResult @ drawObj " data-sdf-unwrap="true">
         <input class="hidden result-price" data-sdf-attr.data-id="{{careResult.dataId}}" data-sdf-attr.data-model-code="{{careResult.dataModelCode}}" data-sdf-attr.data-model-name="{{careResult.dataModelName}}" data-sdf-attr.data-price="{{careResult.dataPrice}}" data-sdf-attr.data-sale-price="{{careResult.dataSalePrice}}" type="hidden"/>
        </div>
        <div class="pd-select-option option-warranty sdf-component-template" data-sdf-template="warranty @ drawObj" data-sdf-test="{{warranty.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline" data-sdf-test="{{warranty.title}}">
           {{warranty.title}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{warranty.learnMoreCta.text}}">
           <button an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black add-special-tagging" data-sdf-attr.data-target-popup="{{warranty.learnMoreCta.layerTarget}}" data-sdf-attr.target="{{warranty.learnMoreCta.target}}" data-sdf-attr.title="{{warranty.learnMoreCta.title}}" data-sdf-test="{{ warranty.learnMoreCta.isNotOutLink}}" href="#" rel="nofollow">
            {{warranty.learnMoreCta.text}}
           </button>
           <a an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon" data-sdf-attr.data-target-popup="{{warranty.learnMoreCta.layerTarget}}" data-sdf-attr.target="{{warranty.learnMoreCta.target}}" data-sdf-attr.title="{{warranty.learnMoreCta.title}}" data-sdf-test="{{warranty.learnMoreCta.isOutLink}}">
            {{warranty.learnMoreCta.text}}
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#outlink-bold" xlink:href="#outlink-bold">
             </use>
            </svg>
           </a>
          </span>
         </div>
         <p class="pd-select-option__desc" data-sdf-test="{{warranty.description}}">
          {{warranty.description}}
         </p>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:yes" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging {{warranty.yesAttr.class}}" data-target-popup="{{warranty.yesAttr.layerTarget}}" id="pd-samsung-warranty-0" name="pd-samsung-warranty" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-warranty-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{warranty.yesAttr.text}}
                </strong>
                <span class="pd-option-selector__sub-text">
                 {{warranty.yesAttr.subText}}
                </span>
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging {{warranty.noAttr.class}}" data-event-type="{{warranty.noAttr.eventType}}" data-target-popup="{{warranty.noAttr.layerTarget}}" id="pd-samsung-warranty-1" name="pd-samsung-warranty" type="radio"/>
             <label class="pd-option-selector__label" for="pd-samsung-warranty-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{warranty.noAttr.text}}
                </strong>
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result result-warranty sdf-component-template" data-sdf-template=" warrantyResult @ drawObj " data-sdf-unwrap="true">
         <div class="option-result__text-wrap result-price" data-sdf-attr.data-id="{{warrantyResult.dataId}}" data-sdf-attr.data-model-code="{{warrantyResult.dataModelCode}}" data-sdf-attr.data-model-name="{{warrantyResult.dataModelName}}" data-sdf-attr.data-price="{{warrantyResult.dataPrice}}" data-sdf-attr.data-sale-price="{{warrantyResult.dataSalePrice}}">
          <p class="option-result__text-title" data-sdf-test="{{warrantyResult.displayModelName}}">
           {{warrantyResult.displayModelName}}
          </p>
          <p class="option-result__text" data-sdf-test="{{warrantyResult.discountText1}}">
           {{warrantyResult.discountText1}}
          </p>
         </div>
         <div class="option-result__desc-wrap" data-sdf-test="{{warrantyResult.description1}}">
          <p class="option-result__desc">
           {{warrantyResult.description1}}
          </p>
         </div>
         <a class="option-result__close remove-warranty-result" href="javascript:void(0)">
          <span class="hidden">
           Tutup
          </span>
          <svg class="icon" focusable="false" viewbox="0 0 96 96">
           <path d="M79.17 11.17L48 42.34 16.83 11.17l-5.66 5.66L42.34 48 11.17 79.17l5.66 5.66L48 53.66l31.17 31.17 5.66-5.66L53.66 48l31.17-31.17z">
           </path>
          </svg>
         </a>
        </div>
        <div class="pd-select-option option-warranty-vd sdf-component-template" data-sdf-template="warrantyVd @ drawObj" data-sdf-test="{{warrantyVd.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline">
           {{warrantyVd.title}}
          </h3>
          <span class="pd-select-option__cta-wrap">
           <a an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon" data-sdf-attr.data-target-popup="{{warrantyVd.learnMoreCta.learnMoreTargetPopup}}" data-sdf-attr.href="{{warrantyVd.learnMoreCta.learnMoreHref}}" data-sdf-attr.target="{{warrantyVd.learnMoreCta.learnMoreTarget}}">
            {{warrantyVd.learnMoreCta.learnMoreText}}
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#outlink-bold" xlink:href="#outlink-bold">
             </use>
            </svg>
           </a>
          </span>
         </div>
         <p class="pd-select-option__desc">
          {{warrantyVd.description}}
         </p>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list pd-select-option__list--wide" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:yes" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" checked="" class="hidden" data-target-popup="{{warrantyVd.yesAttr.layerTarget}}" id="pd-extended-warranty-option-0" name="pd-extended-warranty-option" type="radio"/>
             <label class="pd-option-selector__label" for="pd-extended-warranty-option-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{warrantyVd.yesAttr.text}}
                </strong>
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-result-focus" id="pd-extended-warranty-option-1" name="pd-extended-warranty-option" type="radio"/>
             <label class="pd-option-selector__label" for="pd-extended-warranty-option-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <strong class="pd-option-selector__main-text">
                 {{warrantyVd.noAttr.text}}
                </strong>
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result option-result--extended-warranty-option sdf-component-template" data-sdf-template="warrantyVdResult @ drawObj" data-sdf-unwrap="true">
         <div class="option-result__text-wrap" data-sdf-attr.data-model-code="{{warrantyVdResult.smcCode}}" data-sdf-attr.data-price="{{warrantyVdResult.price}}">
          <p class="option-result__text-title">
           {{warrantyVdResult.title}}
          </p>
          <p class="option-result__text">
           {{warrantyVdResult.priceDisplay}}
          </p>
         </div>
         <a an-ac="pd buying tool" an-ca="option click" an-la="extended warranty:delete" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="option-result__close" href="javascript:void(0)">
          <span class="hidden">
           Close
          </span>
          <svg aria-hidden="true" class="icon" focusable="false" viewbox="0 0 96 96">
           <path d="M79.17 11.17L48 42.34 16.83 11.17l-5.66 5.66L42.34 48 11.17 79.17l5.66 5.66L48 53.66l31.17 31.17 5.66-5.66L53.66 48l31.17-31.17z">
           </path>
          </svg>
         </a>
        </div>
        <!-- (2021.02.08 추가) Tooltip 기능 추가 -->
        <div class="pd-select-option pd-select-option--delivery-detail sdf-component-template" data-sdf-template="delivery @ drawObj" data-sdf-test="{{delivery.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline">
           {{delivery.headline}}
          </h3>
         </div>
         <div class="pd-select-option__input-wrap">
          <div class="text-field-v2 no-title {{delivery.labelClass}}">
           <label class="text-field-v2__hint" for="delivery-zipcode">
            {{delivery.label}}
           </label>
           <div class="text-field-v2__input-wrap">
            <input autocomplete="off" class="text-field-v2__input" data-sdf-attr.disabled="{{delivery.inputAttr.disabled}}" data-sdf-attr.maxlength="{{delivery.inputAttr.maxlength}}" data-sdf-attr.value="{{delivery.inputAttr.value}}" id="delivery-zipcode" type="text"/>
            <button an-ac="pd buying tool" an-ca="option click" an-la="zip code:delete" an-tr="header(pim)_option selector-product detail-image-submit" class="text-field-v2__input-icon delete add-special-tagging" title="Delete">
             <svg class="icon delete" focusable="false">
              <use href="#cancel-bold" xlink:href="#cancel-bold">
              </use>
             </svg>
            </button>
           </div>
           <p class="text-field-v2__text error">
            {{delivery.errorMessage}}
           </p>
          </div>
          <a an-ac="pd buying tool" an-ca="option click" an-la="delivery details:Apply" an-tr="hdd02_product info.-product detail-apply cta-option_click1" class="cta cta--contained cta--black check-zipcode {{delivery.ctaClass}}" href="javascript:void(0)" title="Apply">
           Terapkan
          </a>
         </div>
        </div>
        <div class="option-result result-delivery sdf-component-template" data-sdf-template="deliveryResult @ drawObj" data-sdf-unwrap="true">
         <div class="option-result__text-wrap">
          <p class="option-result__text delivery-priority" data-sdf-test="{{deliveryResult.priorityText}}">
           {{deliveryResult.priorityText}}
          </p>
          <p class="option-result__text delivery-standard" data-sdf-test="{{deliveryResult.mainText}}">
           {{deliveryResult.mainText}}
          </p>
          <p class="option-result__sub-text" data-sdf-test="{{deliveryResult.subText}}">
           {{deliveryResult.subText}}
           <br/>
           Standard installation charges may apply.
           <a aria-label="Link Title" class="option-result__text-link" href="https://www.samsung.com/" target="_blank">
            Click here
           </a>
           for more details.
          </p>
         </div>
         <div class="option-result__desc-wrap">
          <p class="option-result__desc-title" data-sdf-test="{{deliveryResult.decText}}">
           {{deliveryResult.decText}}
          </p>
          <p class="option-result__desc" data-sdf-repeat.item="{{deliveryResult.disclaimerList}}">
           {{item.disclaimer}}
          </p>
         </div>
         <a an-ac="pd buying tool" an-ca="option click" an-la="delivery details:delete" an-tr="hdd02_product info.-product detail-option selector-option_click1" class="option-result__close remove-delivery" href="javascript:void(0)">
          <span class="hidden">
           Tutup
          </span>
          <svg aria-hidden="true" class="icon" focusable="false">
           <use href="#delete-bold" xlink:href="#delete-bold">
           </use>
          </svg>
         </a>
        </div>
        <div class="pd-select-option option-tariff sdf-component-template" data-sdf-template="tariffOption @ drawObj" data-sdf-test="{{tariffOption.hasComponent}}" data-sdf-unwrap="true">
         <div class="pd-select-option__headline-wrap">
          <h3 class="pd-select-option__headline">
           {{tariffOption.headline}}
          </h3>
          <span class="pd-select-option__cta-wrap" data-sdf-test="{{tariffOption.href}}">
           <a an-ac="pd buying tool" an-ca="option click" an-la="tariff:learn more" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" class="cta cta--underline-v2 cta--black cta--icon add-special-tagging" data-sdf-attr.href="{{tariffOption.href}}" rel="nofollow" role="button" target="_blank" title="Lebih detail">
            Lebih detail
            <svg aria-hidden="true" class="icon" focusable="false">
             <use href="#outlink-bold" xlink:href="#outlink-bold">
             </use>
            </svg>
           </a>
          </span>
         </div>
         <p class="pd-select-option__desc">
          {{tariffOption.description}}
         </p>
         <p class="pd-select-option__carrier" data-sdf-list.logoitem="{{tariffOption.logoList}}">
          <img class="carrier-logo" data-sdf-attr.alt="{{logoitem.alt}}" data-sdf-attr.src="{{logoitem.src}}"/>
         </p>
         <div class="pd-select-option__wrap">
          <ul class="pd-select-option__list" role="list">
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="tariff:yes" an-tr="hdd02_product info.-product detail-option service selector-option_click" aria-haspopup="dialog" checked="" class="hidden option-input add-special-tagging" data-target-popup="tariffPopup" id="pd-tariff-option-0" name="pd-tariff-option" type="radio"/>
             <label class="pd-option-selector__label" for="pd-tariff-option-0">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <span class="pd-option-selector__main-text">
                 {{tariffOption.yesAttr.text}}
                </span>
               </span>
              </span>
             </label>
            </div>
           </li>
           <li class="pd-select-option__item" role="listitem">
            <div class="pd-option-selector">
             <input an-ac="pd buying tool" an-ca="option click" an-la="tariff:no" an-tr="hdd02_product info.-product detail-option service selector-option_click" class="hidden option-input add-special-tagging" id="pd-tariff-option-1" name="pd-tariff-option" type="radio"/>
             <label class="pd-option-selector__label" for="pd-tariff-option-1">
              <span class="pd-option-selector__text-wrap">
               <span class="pd-option-selector__text">
                <span class="pd-option-selector__main-text">
                 {{tariffOption.noAttr.text}}
                </span>
               </span>
              </span>
             </label>
            </div>
           </li>
          </ul>
         </div>
        </div>
        <div class="option-result result-tariff-option sdf-component-template" data-sdf-template="tariffOptionResult @ drawObj" data-sdf-test="{{tariffOptionResult.hasComponent}}" data-sdf-unwrap="true">
         <div class="option-result__text-wrap result-price" data-sdf-attr.data-id="{{tariffOptionResult.dataId}}" data-sdf-attr.data-model-code="{{tariffOptionResult.dataModelCode}}" data-sdf-attr.data-price="{{tariffOptionResult.dataPrice}}" data-sdf-attr.data-simsku-code="{{tariffOptionResult.dataSimskuCode}}">
          <p class="option-result__text-title" data-sdf-test="{{tariffOptionResult.displayModelName}}">
           {{tariffOptionResult.displayModelName}}
          </p>
          <p class="option-result__text" data-sdf-test="{{tariffOptionResult.discountText1}}">
           {{tariffOptionResult.discountText1}}
          </p>
         </div>
         <div class="option-result__desc-wrap" data-sdf-test="{{tariffOptionResult.description1}}">
          <p class="option-result__desc">
           {{tariffOptionResult.description1}}
          </p>
          <p class="option-result__desc">
           {{tariffOptionResult.description2}}
          </p>
         </div>
         <a class="option-result__close remove-tariff-option-result" href="javascript:void(0)">
          <span class="hidden">
           Tutup
          </span>
          <svg class="icon" focusable="false" viewbox="0 0 96 96">
           <path d="M79.17 11.17L48 42.34 16.83 11.17l-5.66 5.66L42.34 48 11.17 79.17l5.66 5.66L48 53.66l31.17 31.17 5.66-5.66L53.66 48l31.17-31.17z">
           </path>
          </svg>
         </a>
         <p class="option-result__desc">
          {{tariffOptionResult.description}}
         </p>
         <p class="option-result__price" data-sdf-attr.data-id="{{tariffOptionResult.dataId}}" data-sdf-attr.data-model-code="{{tariffOptionResult.dataModelCode}}" data-sdf-attr.data-price="{{tariffOptionResult.dataPrice}}" data-sdf-attr.data-simsku-code="{{tariffOptionResult.dataSimskuCode}}">
          {{tariffOptionResult.price}}
         </p>
         <p class="option-result__disclaimer">
          {{tariffOptionResult.disclaimer}}
         </p>
        </div>
        <div class="pd-select-option option-embed-addon sdf-component-template" data-sdf-template="embedAddon @ drawObj" data-sdf-test="{{embedAddon.hasComponent}}" data-sdf-unwrap="true">
         <h3 class="pd-select-option__headline">
          {{embedAddon.title}}
         </h3>
         <p class="pd-select-option__desc">
          {{embedAddon.description}}
         </p>
         <ul class="add-on-product-list-wrap" data-sdf-test="{{embedAddon.isNotVDSTEPBUYING}}" data-total-price="0" data-total-sale-price="0">
          <li class="add-on-product{{item.oosClass}}" data-sdf-repeat.item="{{embedAddon.itemSet}}">
           <div class="checkbox-v2">
            <input an-ac="pd buying tool" an-ca="option click" an-la="add on product purchase only:{{item.nameToLowerCase}}" class="checkbox-v3__input" data-modelcode="{{item.modelCode}}" data-modelname="{{item.groupCode}}" id="add-on-product-{{item.index}}" name="checkbox" type="checkbox"/>
            <label class="checkbox-v3__label" for="add-on-product-{{item.index}}">
             <span class="checkbox-v3__label-box-wrap">
              <span class="checkbox-v3__label-box">
               <svg aria-hidden="true" class="checkbox-v3__label-box-icon" focusable="false">
                <use href="#done-bold" xlink:href="#done-bold">
                </use>
               </svg>
              </span>
             </span>
             <span class="checkbox-v3__label-text">
              {{item.name}}
             </span>
            </label>
           </div>
           <div class="add-on-product__image">
            <div class="image">
             <img alt="{{item.imgAlt}}" class="image__preview lazy-load" data-src="{{item.imgSrc}}" role="img"/>
             <img alt="{{item.imgAlt}}" class="image__main lazy-load" data-src="{{item.imgSrc}}" role="img"/>
            </div>
           </div>
           <div class="add-on-product__detail-wrap">
            <div class="add-on-product__text-wrap">
             <span class="badge-icon badge-icon--label-v2 {{item.iconClass}}" data-sdf-test="{{item.iconClass}}">
              {{item.iconTitle}}
             </span>
             <p class="add-on-product__title" data-model-name="{{item.name}}">
              {{item.name}}
             </p>
             <p class="add-on-product__serial-number" data-model-code="{{item.modelCode}}" data-sdf-test="{{item.modelCode}}">
              {{item.modelCode}}
             </p>
             <p class="add-on-product__desc" data-sdf-test="{{item.description}}">
              {{item.description}}
             </p>
            </div>
            <div class="add-on-product__price-wrap">
             <p class="add-on-product__final-price" data-price="{{item.finalPriceValue}}">
              {{item.finalPrice}}
             </p>
             <del class="add-on-product__original-price" data-original-price="{{item.originalPriceValue}}" data-sdf-test="{{item.originalPrice}}">
              {{item.originalPrice}}
             </del>
             <span class="add-on-product__saving-price" data-save-price="{{item.savePriceValue}}" data-sdf-test="{{item.savePrice}}">
              {{item.savePrice}}
             </span>
             <span class="add-on-product__out-of-stock" data-sdf-test="{{item.isOOS}}">
              Habis
             </span>
            </div>
            <button aria-label="Learn More" class="cta cta--underline-v2 cta--black cta-learn-more" data-model-idx="{{item.index}}" data-sdf-test="{{item.isLearnMorePopup}}">
             Lebih detail
            </button>
           </div>
          </li>
         </ul>
         <ul class="add-on-product-list-wrap add-on-product-list-wrap--vd" data-sdf-test="{{embedAddon.isVDSTEPBUYING}}" data-total-price="0" data-total-sale-price="0">
          <li class="add-on-product{{item.oosClass}}{{item.hideClass}}" data-sdf-repeat.item="{{embedAddon.itemSet}}" data-view-more-item="true">
           <div class="add-on-product__image">
            <div class="image">
             <img alt="{{item.imgAlt}}" class="image__preview lazy-load responsive-img" data-comp-name="image" data-desktop-src="" data-mobile-src="" data-src="" role="img"/>
             <img alt="{{item.imgAlt}}" class="image__main lazy-load responsive-img lazy-load" data-comp-name="image" data-desktop-src="{{item.imgSrc}}?$72_72_PNG$" data-mobile-src="{{item.imgSrc}}?$128_128_PNG$" data-src="{{item.imgSrc}}" role="img"/>
            </div>
           </div>
           <div class="add-on-product__detail-wrap">
            <div class="add-on-product__text-wrap">
             <span class="badge-icon badge-icon--label-v2 {{item.iconClass}}" data-sdf-test="{{item.iconClass}}">
              {{item.iconTitle}}
             </span>
             <p class="add-on-product__title" data-model-name="{{item.name}}">
              {{item.name}}
             </p>
             <p class="add-on-product__desc" data-sdf-test="{{item.description}}">
              {{item.description}}
             </p>
             <ul class="add-on-product__dot-list" data-sdf-test="{{item.dotList1}}">
              <li data-sdf-test="{{item.dotList1}}">
               {{item.dotList1}}
              </li>
              <li data-sdf-test="{{item.dotList2}}">
               {{item.dotList2}}
              </li>
              <li data-sdf-test="{{item.dotList3}}">
               {{item.dotList3}}
              </li>
             </ul>
            </div>
            <div class="add-on-product__price-wrap">
             <p class="add-on-product__final-price" data-price="{{item.finalPriceValue}}">
              {{item.finalPrice}}
             </p>
             <del class="add-on-product__original-price" data-original-price="{{item.originalPriceValue}}" data-sdf-test="{{item.originalPrice}}">
              {{item.originalPrice}}
             </del>
             <span class="add-on-product__saving-price" data-save-price="{{item.savePriceValue}}" data-sdf-test="{{item.savePrice}}">
              {{item.savePrice}}
             </span>
             <span class="add-on-product__out-of-stock" data-sdf-test="{{item.isOOS}}">
              Habis
             </span>
            </div>
            <button an-ac="pd buying tool" an-ca="option click" an-la="add-on:add item" an-tr="hdd02_pdp header-product detail-add item-option_click" aria-label="Add" class="cta cta--outlined cta--black embed-addon-add" data-id="add-on-product-{{item.index}}" data-mode-code="{{item.modelCode}}" data-sdf-test="{{item.isStock}}">
             Tambah
            </button>
            <button an-ac="pd buying tool" an-ca="option click" an-la="add-on:add item" an-tr="hdd02_pdp header-product detail-add item-option_click" aria-label="Add" class="cta cta--outlined cta--black cta--disabled embed-addon-add" data-sdf-test="{{item.isOOS}}" disabled="">
             Tambah
            </button>
           </div>
          </li>
         </ul>
         <div class="pd-select-option__view-more" data-sdf-test="{{embedAddon.useMobileCTA}}">
          <button aria-expanded="false" class="cta cta--icon" data-js-action="offerListViewMore" data-text-close="Lihat sedikit" data-text-open="Lihat selengkapnya" type="button">
           <span class="pd-select-option__view-more-text">
            Lihat selengkapnya
           </span>
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#open-down-regular" xlink:href="#open-down-regular">
            </use>
           </svg>
          </button>
         </div>
        </div>
        <div data-sdf-template="offerContent_promotionMessage @ message" data-sdf-unwrap="true">
         <div class="dot-list__text-wrap {{message.item.contentWrapperClass}}">
          <span class="dot-list__text" data-sdf-test="{{message.item.offerTitle}}">
           {{message.item.offerTitle}}
          </span>
          <span class="dot-list__tooltip" data-sdf-test="{{message.item.offerTooltip}}">
           <button aria-describedby="descTip" class="dot-list__tooltip-cta">
            <span class="hidden">
             ?
            </span>
           </button>
           <span class="dot-list__tooltip-message" id="descTip" role="tooltip">
            <span class="dot-list__tooltip-message-text">
             {{message.item.offerTooltip}}
            </span>
            <button class="dot-list__tooltip-close">
             <span class="hidden">
              Close
             </span>
             <svg aria-hidden="true" class="icon icon-delete" focusable="false">
              <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
              </use>
             </svg>
            </button>
           </span>
          </span>
          <a an-ac="pd buying tool" an-ca="option click" an-la="offers:{{message.item.title}}:{{message.item.linkText}}" an-tr="hdd02_product info.-product detail-offers-option_click1" class="cta cta--underline-v2 cta--black" data-sdf-attr.href="{{message.item.linkUrl}}" data-sdf-attr.title="{{message.item.linkText}}" data-sdf-test="{{message.item.linkEnabled}}">
           {{message.item.linkText}}
          </a>
         </div>
         <p class="dot-list__desc" data-sdf-test="{{message.item.hasTCCTA}}">
          {{message.item.tcCTAText}}
         </p>
         <p class="dot-list__desc" data-sdf-test="{{message.item.hasPeriod}}">
          {{message.item.periodText}}
         </p>
        </div>
       </div>
       <!--googleon: all-->
      </div>
    <div class="pd-g-feature-benefit-ux2 pd-g-feature-benefit">
     <!-- isNotBuyingPd-->
     <!-- FaqSeo -->
    </div>
    <div class="pd-g-reasons-to-buy-ux2">
     <input id="rtbListSize" name="rtbListSize" type="hidden" value="4"/>
     <section class="pdd28-reasons-to-buy pdd28-reasons-to-buy--theme-white-card" style="display:none;">
<section class="pdd28-reasons-to-buy pdd28-reasons-to-buy--theme-white-card lp-631975739999564131">

<style>
  .pdd28-reasons-to-buy .lx-container{
    max-width:1180px;
    margin:42px auto;
    padding:0 16px;
    font-family:Inter,system-ui,-apple-system,"Segoe UI",Arial,sans-serif;
  }

  .pdd28-reasons-to-buy .lx-container *{
    box-sizing:border-box;
  }

  .pdd28-reasons-to-buy .lx-mainbox{
    position:relative;
    overflow:hidden;
    border-radius:26px;
    padding:34px;
    background:
      radial-gradient(circle at top left,rgba(251,113,133,0.2),transparent 32%),
      radial-gradient(circle at bottom right,rgba(253,164,175,0.22),transparent 36%),
      linear-gradient(145deg,#fb7185 0%,#fda4af 52%,#1a1a1a 100%);
    border:1px solid rgba(251,113,133,0.48);
    box-shadow:0 24px 60px rgba(0,0,0,.42),inset 0 0 0 1px rgba(255,255,255,.05);
    color:#f8fafc;
  }

  .pdd28-reasons-to-buy .lx-mainbox:before{
    content:"";
    position:absolute;
    inset:16px;
    border:1px solid rgba(255,255,255,.08);
    border-radius:20px;
    pointer-events:none;
  }

  .pdd28-reasons-to-buy .lx-mainbox:after{
    content:"";
    position:absolute;
    top:-80px;
    right:-100px;
    width:260px;
    height:260px;
    border-radius:50%;
    background:rgba(251,113,133,0.14);
    filter:blur(12px);
    pointer-events:none;
  }

  .pdd28-reasons-to-buy .lx-hero{
    position:relative;
    z-index:1;
    display:grid;
    grid-template-columns:1.15fr .85fr;
    gap:26px;
    align-items:stretch;
  }

  .pdd28-reasons-to-buy .lx-title-card{
    border-radius:22px;
    padding:30px;
    background:rgba(255,255,255,.07);
    border:1px solid rgba(255,255,255,.12);
    box-shadow:0 14px 34px rgba(0,0,0,.24);
  }

  .pdd28-reasons-to-buy .lx-badge{
    display:inline-flex;
    align-items:center;
    gap:8px;
    padding:8px 14px;
    border-radius:999px;
    background:#fda4af;
    color:#b7f7b0;
    border:1px solid rgba(253,164,175,0.42);
    font-size:13px;
    font-weight:800;
    letter-spacing:.4px;
    text-transform:uppercase;
    margin-bottom:16px;
  }

  .pdd28-reasons-to-buy .lx-badge:before{
    content:"";
    width:8px;
    height:8px;
    border-radius:50%;
    background:#fb7185;
    box-shadow:0 0 12px rgba(251,113,133,0.48);
  }

  .pdd28-reasons-to-buy .lx-container h1{
    margin:0;
    font-size:34px;
    line-height:1.3;
    font-weight:900;
    letter-spacing:.2px;
    color:#ffffff;
    text-shadow:0 4px 16px rgba(0,0,0,.42);
  }

  .pdd28-reasons-to-buy .lx-divider{
    width:96px;
    height:4px;
    margin:22px 0 0;
    border-radius:999px;
    background:linear-gradient(90deg,#fb7185,#fda4af);
  }

  .pdd28-reasons-to-buy .lx-info-panel{
    border-radius:22px;
    padding:22px;
    background:linear-gradient(180deg,rgba(255,255,255,.10),rgba(255,255,255,.04));
    border:1px solid rgba(251,113,133,0.28);
  }

  .pdd28-reasons-to-buy .info-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:14px;
    margin:0;
  }

  .pdd28-reasons-to-buy .info-card{
    min-height:112px;
    padding:18px 14px;
    border-radius:18px;
    background:rgba(5,9,24,.58);
    border:1px solid rgba(251,113,133,0.24);
    display:flex;
    flex-direction:column;
    justify-content:center;
    text-align:center;
    transition:.28s ease;
  }

  .pdd28-reasons-to-buy .info-card:hover{
    transform:translateY(-5px);
    border-color:rgba(251,113,133,0.72);
    box-shadow:0 14px 30px rgba(0,0,0,.28),0 0 20px rgba(251,113,133,0.2);
  }

  .pdd28-reasons-to-buy .info-card .label{
    color:#9ee8f5;
    font-size:12px;
    font-weight:800;
    text-transform:uppercase;
    letter-spacing:.7px;
    margin-bottom:8px;
  }

  .pdd28-reasons-to-buy .info-card .value{
    color:#ffffff;
    font-size:18px;
    font-weight:900;
    line-height:1.25;
  }

  .pdd28-reasons-to-buy .highlight-box{
    position:relative;
    z-index:1;
    margin:28px 0 0;
    padding:28px 30px;
    border-radius:22px;
    background:rgba(255,255,255,.94);
    border:1px solid rgba(251,113,133,0.28);
    box-shadow:0 18px 36px rgba(0,0,0,.18);
  }

  .pdd28-reasons-to-buy .highlight-box p{
    margin:0;
    color:#1f2937;
    font-size:16px;
    line-height:1.9;
    text-align:justify;
  }

  .pdd28-reasons-to-buy .highlight-box p + p{
    margin-top:16px;
  }

  .pdd28-reasons-to-buy .highlight-box a{
    color:#fb7185;
    font-weight:800;
    text-decoration:underline;
  }

  .pdd28-reasons-to-buy .reviews-section{
    position:relative;
    z-index:1;
    margin-top:34px;
    padding-top:28px;
    border-top:1px solid rgba(255,255,255,.12);
  }

  .pdd28-reasons-to-buy .lx-container h2{
    margin:0 0 22px;
    color:#ffffff;
    font-size:26px;
    line-height:1.35;
    font-weight:900;
    text-align:center;
    letter-spacing:.4px;
    text-transform:uppercase;
  }

  .pdd28-reasons-to-buy .lx-container h2:after{
    content:"";
    display:block;
    width:120px;
    height:3px;
    margin:14px auto 0;
    border-radius:999px;
    background:linear-gradient(90deg,transparent,#fb7185,#fda4af,transparent);
  }

  .pdd28-reasons-to-buy .reviews-grid{
    display:grid;
    grid-template-columns:repeat(3,minmax(0,1fr));
    gap:18px;
  }

  .pdd28-reasons-to-buy .review-card{
    position:relative;
    overflow:hidden;
    min-height:210px;
    padding:22px;
    border-radius:20px;
    background:
      linear-gradient(180deg,rgba(255,255,255,.10),rgba(255,255,255,.04)),
      rgba(5,9,24,.72);
    border:1px solid #fda4af;
    box-shadow:0 14px 32px rgba(0,0,0,.24);
    transition:.28s ease;
  }

  .pdd28-reasons-to-buy .review-card:hover{
    transform:translateY(-7px);
    border-color:#fb7185;
    box-shadow:0 22px 42px rgba(0,0,0,.32),0 0 22px rgba(253,164,175,0.14);
  }

  .pdd28-reasons-to-buy .review-card:before{
    content:"";
    position:absolute;
    top:0;
    left:0;
    right:0;
    height:4px;
    background:linear-gradient(90deg,#fb7185,#fda4af);
  }

  .pdd28-reasons-to-buy .review-card:after{
    content:"“";
    position:absolute;
    right:18px;
    bottom:-22px;
    font-family:Georgia,serif;
    font-size:110px;
    color:rgba(255,255,255,.055);
    line-height:1;
  }

  .pdd28-reasons-to-buy .review-header{
    position:relative;
    z-index:1;
    display:flex;
    align-items:flex-start;
    justify-content:space-between;
    gap:12px;
    margin-bottom:14px;
  }

  .pdd28-reasons-to-buy .review-name{
    color:#ffffff;
    font-size:15px;
    line-height:1.4;
    font-weight:900;
  }

  .pdd28-reasons-to-buy .review-stars{
    white-space:nowrap;
    color:#9be374;
    font-size:14px;
    letter-spacing:1px;
    text-shadow:0 0 10px rgba(253,164,175,0.14);
  }

  .pdd28-reasons-to-buy .review-text{
    position:relative;
    z-index:1;
    margin:0;
    color:#dbeafe;
    font-size:14.7px;
    line-height:1.75;
    font-style:italic;
  }

  .pdd28-reasons-to-buy .review-date{
    position:relative;
    z-index:1;
    display:inline-block;
    margin-top:16px;
    padding:7px 11px;
    border-radius:999px;
    background:rgba(251,113,133,0.1);
    border:1px solid rgba(251,113,133,0.24);
    color:#9ee8f5;
    font-size:12px;
    font-weight:800;
  }

  @media(max-width:980px){
    .pdd28-reasons-to-buy .lx-hero{
      grid-template-columns:1fr;
    }

    .pdd28-reasons-to-buy .reviews-grid{
      grid-template-columns:repeat(2,minmax(0,1fr));
    }
  }

  @media(max-width:640px){
    .pdd28-reasons-to-buy .lx-container{
      margin:28px auto;
      padding:0 12px;
    }

    .pdd28-reasons-to-buy .lx-mainbox{
      padding:22px;
      border-radius:20px;
    }

    .pdd28-reasons-to-buy .lx-title-card,
    .pdd28-reasons-to-buy .lx-info-panel,
    .pdd28-reasons-to-buy .highlight-box{
      padding:20px;
      border-radius:18px;
    }

    .pdd28-reasons-to-buy .lx-container h1{
      font-size:24px;
    }

    .pdd28-reasons-to-buy .lx-container h2{
      font-size:21px;
    }

    .pdd28-reasons-to-buy .info-grid,
    .pdd28-reasons-to-buy .reviews-grid{
      grid-template-columns:1fr;
    }

    .pdd28-reasons-to-buy .highlight-box p{
      font-size:15px;
      line-height:1.8;
    }
  }
</style>

<article class="lx-container" aria-label="Artikel RODA37 | Roda 37">
  <div class="lx-mainbox">

    <div class="lx-hero">
      <div class="lx-title-card">
        <div class="lx-badge">Informasi Pilihan RODA37 | Roda 37</div>
        <h1>RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi</h1>
        <div class="lx-divider"></div>
      </div>

      <div class="lx-info-panel">
        <div class="info-grid">
          <div class="info-card"><div class="label">Penilaian Pengguna</div><div class="value">4.9/5</div></div>
          <div class="info-card"><div class="label">Minimal Deposit</div><div class="value">Rp10.000</div></div>
          <div class="info-card"><div class="label">Minimal Withdraw</div><div class="value">Rp25.000</div></div>
          <div class="info-card"><div class="label">Layanan Support</div><div class="value">24/7</div></div>
        </div>
      </div>
    </div>

    <div class="highlight-box">
      <p><a href="https://clik.is/yugentoto">RODA37 | Roda 37</a> menonjol lewat Bonus New Member yang terasa langsung nyambung dengan tema jackpot progresif. Di sini, ritme pembahasan dibuat lebih terukur supaya pembaca paham kapan peluang terasa terbuka, bagaimana tanda main yang layak dicermati, dan apa yang disebut bukti resmi di balik tampilan permainan.</p>
      <p>Fokusnya bukan janji kosong, melainkan cara membaca alur bonus, tempo putaran, dan momen saat fitur jackpot progresif mulai memberi sinyal yang lebih menarik. Dengan pendekatan seperti ini, RODA37 | Roda 37 lebih mudah dinilai sebagai referensi sebelum Anda masuk ke sesi berikutnya.</p>
    </div>

    <section class="reviews-section">
      <h2>APA KATA MEREKA? REVIEW MEMBER SETIA RODA37 | Roda 37</h2>

      <div class="reviews-grid">
        <div class="review-card">
          <div class="review-header">
            <span class="review-name">Sinta Lestari – Yogyakarta</span>
            <span class="review-stars">★★★★★</span>
          </div>
          <p class="review-text">"Saya masuk RODA37 | Roda 37 lewat HP, terus coba beberapa ronde pendek. Ada yang pas, ada yang biasa, tapi nggak terasa dipaksa."</p>
          <span class="review-date">1 November 2026</span>
        </div>
        <div class="review-card">
          <div class="review-header">
            <span class="review-name">Yoga Pratama – Makassar</span>
            <span class="review-stars">★★★★☆</span>
          </div>
          <p class="review-text">"Teman yang kasih tahu RODA37 | Roda 37. Saya coba sendiri, lobby-nya rapi jadi saya nggak lama nyari-nyari."</p>
          <span class="review-date">1 November 2026</span>
        </div>
        <div class="review-card">
          <div class="review-header">
            <span class="review-name">Maya Rahmawati – Bogor</span>
            <span class="review-stars">★★★★★</span>
          </div>
          <p class="review-text">"Yang saya suka di RODA37 | Roda 37, saya bisa berhenti sejenak lalu lanjut lagi tanpa merasa ketinggalan. Santai, tapi tetap seru."</p>
          <span class="review-date">1 November 2026</span>
        </div>
        <div class="review-card">
          <div class="review-header">
            <span class="review-name">Eko Ramadhan – Jakarta</span>
            <span class="review-stars">★★★★★</span>
          </div>
          <p class="review-text">"Baru dua-tiga kali main di RODA37 | Roda 37, kesannya belum sempurna. Tapi alurnya jelas, jadi saya masih mau coba lagi."</p>
          <span class="review-date">1 November 2026</span>
        </div>
        <div class="review-card">
          <div class="review-header">
            <span class="review-name">Dinda Safitri – Denpasar</span>
            <span class="review-stars">★★★★★</span>
          </div>
          <p class="review-text">"Saya bukan tipe yang lama di satu tempat. Di RODA37 | Roda 37 saya bisa pilih yang ringan dulu, baru yang lebih seru kalau moodnya pas."</p>
          <span class="review-date">1 November 2026</span>
        </div>
        <div class="review-card">
          <div class="review-header">
            <span class="review-name">Fajar Hidayat – Depok</span>
            <span class="review-stars">★★★★★</span>
          </div>
          <p class="review-text">"Jujur awalnya cuma iseng buka RODA37 | Roda 37. Habis masuk lobby, gampang nemu yang enak dimainkan, jadi saya betah lebih lama dari rencana."</p>
          <span class="review-date">1 November 2026</span>
        </div>
      </div>
    </section>

  </div>
</article>
        <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #fda4af; color: #fda4af; font-size: 12px;">
            © 2026 RODA37 | Roda 37. All rights reserved.
        </div>
</section>
            
            <script>
                $(document).ready(function () {
                    $(window).on('scroll', function () {
                        if (
                            $(window).scrollTop() >=
                            $('.product-recommendations1').offset().top + $('.product-recommendations1').outerHeight() - window.innerHeight
                        ) {
                            setTimeout(function () {
                                var checkLength = $("input[name='frequent-products-pdp']:checked").length;
                                var productRecs = document.querySelector('.product-recommendations1');

                                $('#checked-products').text(checkLength);
                            }, 4000);
                            setTimeout(function () {
                                var height;
                                var maxheight = 0;
                                var minheight = 0;
                                $('.price_container_cal').each(function () {
                                    height = parseInt($(this).height());
                                    if (height > maxheight) {
                                        maxheight = height;
                                    } else {
                                        minheight = height;
                                    }
                                });
                                let isMobile = window.matchMedia('only screen and (max-width: 1023px)').matches;
                                if (!isMobile) {
                                    if (maxheight >= minheight) {
                                        $('.price_container_cal').attr(
                                            'style',
                                            'display: flex; flex-flow: column; justify-content: flex-end; height:' + maxheight + 'px;'
                                        );
                                    }
                                }
                            }, 500);
                        }
                    });
                });
            </script>

  

</div>
          </div>
        </div>
      </div>
    </div>
    <nav aria-label="Breadcrumb" class="breadcrumb">
     <div class="breadcrumb__inner">
      <ul class="breadcrumb__path" role="list">
       <li role="listitem">
        <a an-ac="breadcrumb" an-ca="navigation" an-la="breadcrumb:home" an-tr="nv03_breadcrumb-product detail-text-breadcrumb" aria-label="Home" href="https://bom48.com/store/">
         <span class="breadcrumb__text-desktop">
          RODA37 | Roda 37 <span style="margin-left: 15px;">></span>
         </span>
         <span class="breadcrumb__text-mobile">
          SLOT GACOR <span style="margin-left: 15px;">></span>
         </span>
        </a>
        <svg aria-hidden="true" class="icon" focusable="false">
         <use href="#next-bold" xlink:href="#next-bold">
         </use>
        </svg>
       </li>
       <li role="listitem">
        <a an-ac="breadcrumb" an-ca="navigation" an-la="breadcrumb:mobile" an-tr="nv03_breadcrumb-product detail-text-breadcrumb" aria-label="Mobile" href="https://bom48.com/store/">
         <span class="breadcrumb__text-desktop">
          SLOT GACOR <span style="margin-left: 15px;">></span>
         </span>
         <span class="breadcrumb__text-mobile">
          SLOT <span style="margin-left: 15px;">></span>
         </span>
        </a>
        <svg aria-hidden="true" class="icon" focusable="false">
         <use href="#next-bold" xlink:href="#next-bold">
         </use>
        </svg>
       </li>
<li role="listitem">
        <a an-ac="breadcrumb" an-ca="navigation" an-la="breadcrumb:mobile" an-tr="nv03_breadcrumb-product detail-text-breadcrumb" aria-label="Mobile" href="https://bom48.com/store/">
         <span class="breadcrumb__text-desktop">
          SLOT <span style="margin-left: 15px;">></span>
         </span>
         <span class="breadcrumb__text-mobile">
          SLOT ONLINE <span style="margin-left: 15px;">></span>
         </span>
        </a>
        <svg aria-hidden="true" class="icon" focusable="false">
         <use href="#next-bold" xlink:href="#next-bold">
         </use>
        </svg>
       </li>
<li role="listitem">
        <a an-ac="breadcrumb" an-ca="navigation" an-la="breadcrumb:mobile" an-tr="nv03_breadcrumb-product detail-text-breadcrumb" aria-label="Mobile" href="https://bom48.com/store/">
         <span class="breadcrumb__text-desktop">
          SLOT ONLINE <span style="margin-left: 15px;">></span>
         </span>
         <span class="breadcrumb__text-mobile">
          RODA37 | Roda 37 <span style="margin-left: 15px;">></span>
         </span>
        </a>
        <svg aria-hidden="true" class="icon" focusable="false">
         <use href="#next-bold" xlink:href="#next-bold">
         </use>
        </svg>
       </li>              
 <li role="listitem">
        <a an-ac="breadcrumb" an-ca="navigation" an-la="breadcrumb:mobile" an-tr="nv03_breadcrumb-product detail-text-breadcrumb" aria-label="Mobile" href="https://bom48.com/store/">
         <span class="breadcrumb__text-desktop">
          RODA37 | Roda 37 <span style="margin-left: 15px;">></span>
         </span>
         <span class="breadcrumb__text-mobile">
          RODA37 | Roda 37 <span style="margin-left: 15px;">></span>
         </span>
        </a>
        <svg aria-hidden="true" class="icon" focusable="false">
         <use href="#next-bold" xlink:href="#next-bold">
         </use>
        </svg>
       </li>
              <li role="listitem">
        <a an-ac="breadcrumb" an-ca="navigation" an-la="breadcrumb:smartphones" an-tr="nv03_breadcrumb-product detail-text-breadcrumb" aria-label="Smartphones">
         <span class="breadcrumb__text-desktop">
        RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi
         </span>
         <span class="breadcrumb__text-mobile">
        RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi
         </span>
        </a>
        <svg aria-hidden="true" class="icon" focusable="false">
         <use href="#next-bold" xlink:href="#next-bold">
         </use>
        </svg>
       </li>
      </ul>
     </div>
    </nav>
    <div class="pd-g-manufacturer-info-popup">
     <div aria-modal="true" class="manufacturer-info-popup" role="dialog" tabindex="0">
      <div class="layer-popup">
       <div class="layer-popup__inner">
        <div class="layer-popup__contents scrollbar">
         <div class="scrollbar__contents">
         </div>
        </div>
        <button class="layer-popup__close" type="button">
         <span class="hidden">
          Tutup Layar Popup
         </span>
         <svg class="icon" focusable="false">
          <use href="#delete-bold" xlink:href="#delete-bold">
          </use>
         </svg>
        </button>
       </div>
      </div>
     </div>
    </div>
    <!-- <sly data-sly-use.templatedContainer="com.day.cq.wcm.foundation.TemplatedContainer"
			data-sly-repeat.child=""
			data-sly-resource=""></sly> -->
   </div>
   <div class="pdd39-anchor-nav__bottom-wrap" id="anchorNavigationPriceBarMobile">
    <div class="pdd39-anchor-nav__bottom">
     <div class="pdd39-anchor-nav__price pd-buying-price" id="sgDevPriceAreaBaseMobile">
     </div>
    </div>
   </div>
   <footer class="footer">
    <!--googleoff: all-->
    <div class="footer">
      <div class="footer-column">
        <p class="hidden">
          Footer Navigation
        </p>

        <!-- ===== COLUMN 1: PRODUCTS ===== -->
        <div class="footer-column__item">
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-0">
              Products
            </p>
            <a an-ac="footer" an-ca="navigation" an-la="products" an-tr="nv01_footer sitemap|menu1Depth" aria-expanded="false" aria-labelledby="footer-category-title-0" class="footer-category__anchor" href="javascript:void(0);" role="button">
              <span class="hidden" data-i18n-close="Tutup" data-i18n-open="Buka">
                Buka
              </span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://bom48.com/store/">
                    RODA37 | Roda 37
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://bom48.com/store/">
                    SLOT GACOR
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://bom48.com/store/">
                    SLOT
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://bom48.com/store/">
                    RODA37 | Roda 37 Daftar
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://bom48.com/store/">
                    RODA37 | Roda 37 Link
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://bom48.com/store/">
                    RODA37 | Roda 37
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://bom48.com/store/">
                    SLOT ONLINE
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://bom48.com/store/">
                    RAJA SLOT
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <!-- ===== COLUMN 2: SERVICES ===== -->
        <div class="footer-column__item">
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-1">
              Services
            </p>
            <a an-ac="footer" an-ca="navigation" an-la="services" an-tr="nv01_footer sitemap|menu1Depth" aria-expanded="false" aria-labelledby="footer-category-title-1" class="footer-category__anchor" href="javascript:void(0);" role="button">
              <span class="hidden" data-i18n-close="Tutup" data-i18n-open="Buka">
                Buka
              </span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://bom48.com/store/">
                    RODA37 | Roda 37
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://bom48.com/store/">
                    SITUS RODA37 | Roda 37
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://bom48.com/store/">
                    GAME RODA37 | Roda 37
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://bom48.com/store/">
                    Bandar RODA37 | Roda 37
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://bom48.com/store/">
                    RODA37 | Roda 37
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://bom48.com/store/">
                    GAME RODA37 | Roda 37
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://bom48.com/store/">
                    LINK RODA37 | Roda 37
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- ===== COLUMN 3: SUPPORT ===== -->
        <div class="footer-column__item">
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-2">
              Support
            </p>
            <a an-ac="footer" an-ca="navigation" an-la="support" an-tr="nv01_footer sitemap|menu1Depth" aria-expanded="false" aria-labelledby="footer-category-title-2" class="footer-category__anchor" href="javascript:void(0);" role="button">
              <span class="hidden" data-i18n-close="Tutup" data-i18n-open="Buka">
                Buka
              </span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Pusat Bantuan
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Live Chat 24/7
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    WhatsApp Support
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    FAQ
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Kebijakan Privasi
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Syarat &amp; Ketentuan
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Responsible Gaming
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- ===== COLUMN 4: ACCOUNT ===== -->
        <div class="footer-column__item">
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-3">
              Account
            </p>
            <a an-ac="footer" an-ca="navigation" an-la="account" an-tr="nv01_footer sitemap|menu1Depth" aria-expanded="false" aria-labelledby="footer-category-title-3" class="footer-category__anchor" href="javascript:void(0);" role="button">
              <span class="hidden" data-i18n-close="Tutup" data-i18n-open="Buka">
                Buka
              </span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Login Member
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Daftar Akun Baru
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Lupa Password
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Riwayat Transaksi
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Fitur Verifikasi
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Program VIP
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- ===== COLUMN 5: INFO + ABOUT ===== -->
        <div class="footer-column__item">
          <!-- Info / Guides -->
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-4">
              Information
            </p>
            <a an-ac="footer" an-ca="navigation" an-la="information" an-tr="nv01_footer sitemap|menu1Depth" aria-expanded="false" aria-labelledby="footer-category-title-4" class="footer-category__anchor" href="javascript:void(0);" role="button">
              <span class="hidden">
                Buka
              </span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Fitur Akses
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Fitur Pemula
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Aturan &amp; Kebijakan
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Kontak Resmi
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <!-- About -->
          <div class="footer-category">
            <p class="footer-category__title" id="footer-category-title-4-2">
              About
            </p>
            <a an-ac="footer" an-ca="navigation" an-la="about" an-tr="nv01_footer sitemap|menu1Depth" aria-expanded="false" aria-labelledby="footer-category-title-4-2" class="footer-category__anchor" href="javascript:void(0);" role="button">
              <span class="hidden">
                Buka
              </span>
              <svg class="icon" focusable="false">
                <use href="#open-down-regular" xlink:href="#open-down-regular"></use>
              </svg>
            </a>
            <div class="footer-category__list-wrap">
              <ul class="footer-category__list" role="list">
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Tentang Kami
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Kenapa Pilih Kami
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Partner &amp; Affiliate
                  </a>
                </li>
                <li class="footer-category__item" role="listitem">
                  <a class="footer-category__link" href="https://www.samsung.com/">
                    Brand &amp; Identitas
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

      </div>

      <!-- ===== BOTTOM BAR ===== -->
      <div class="footer-bottom">
        <div class="footer-copyright-wrap">
          <div class="footer-copyright-align">
            <p class="footer-copyright">
              &copy; 2026 <a href="https://bom48.com/store/">RODA37 | Roda 37</a>. All rights reserved.
            </p>
          </div>
          <div class="footer-language">
            <a class="footer-language__anchor" href="https://www.samsung.com/">
              Indonesia / Bahasa Indonesia
            </a>
          </div>
        </div>

        <div an-ac="scroll:100" an-ca="scroll" an-la="scroll:100" an-tr="nv02_footer bottom--text-scroll" class="footer-language-wrap">
          <div class="footer-language">
            <a class="footer-language__anchor" href="https://www.samsung.com/">
              Indonesia / Bahasa Indonesia
            </a>
          </div>

          <div class="footer-terms">
            <ul class="footer-terms__list" role="list">
              <li class="footer-terms__item" role="listitem">
                <a class="footer-terms__link" href="https://www.samsung.com/">
                  Privasi
                </a>
              </li>
              <li class="footer-terms__item" role="listitem">
                <a class="footer-terms__link" href="https://www.samsung.com/">
                  Legal
                </a>
              </li>
              <li class="footer-terms__item" role="listitem">
                <a class="footer-terms__link" href="https://www.samsung.com/">
                  Peta Situs
                </a>
              </li>
            </ul>
          </div>

          <div class="footer-sns">
            <span class="footer-sns__title">
              Ingin Tetap Terhubung?
            </span>
            <ul class="footer-sns__list" role="list">
              <li class="footer-sns__item" role="listitem">
                <a class="footer-sns__link" href="https://facebook.com/RODA37 | Roda 37" rel="noreferrer noopener" target="_blank" aria-label="Facebook : Buka di Tab Baru">
                  <svg class="icon" focusable="false">
                    <use href="#facebook-bold" xlink:href="#facebook-bold"></use>
                  </svg>
                </a>
              </li>
              <li class="footer-sns__item" role="listitem">
                <a class="footer-sns__link" href="https://twitter.com/RODA37 | Roda 37" rel="noreferrer noopener" target="_blank" aria-label="Twitter : Buka di Tab Baru">
                  <svg class="icon" focusable="false">
                    <use href="#twitter-bold" xlink:href="#twitter-bold"></use>
                  </svg>
                </a>
              </li>
              <li class="footer-sns__item" role="listitem">
                <a class="footer-sns__link" href="https://instagram.com/RODA37 | Roda 37" rel="noreferrer noopener" target="_blank" aria-label="Instagram : Buka di Tab Baru">
                  <svg class="icon" focusable="false">
                    <use href="#instagram-bold" xlink:href="#instagram-bold"></use>
                  </svg>
                </a>
              </li>
              <li class="footer-sns__item" role="listitem">
                <a class="footer-sns__link" href="https://youtube.com/@RODA37 | Roda 37" rel="noreferrer noopener" target="_blank" aria-label="Youtube : Buka di Tab Baru">
                  <svg class="icon" focusable="false">
                    <use href="#youtube-bold" xlink:href="#youtube-bold"></use>
                  </svg>
                </a>
              </li>
            </ul>
          </div>

        </div>
      </div>
    </div>
  </footer>

   <button an-ac="back to top" an-ca="indication" an-la="back to top" an-tr="nv02_footer bottom--text-back to top" class="fab" title="Go to Top">
    Go to Top
    <svg class="fab__icon" focusable="false">
     <use href="#up-highest-bold" xlink:href="#up-highest-bold">
     </use>
    </svg>
   </button>
   <!--googleon: all-->
   <script src="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-dependencies.min.407b108c60433f00a6b1a0e8f272a2c1.js">
   </script>
   <script src="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-base-ux25.min.91a4ebeb2dec9b19aa121b5c7154ff51.js">
   </script>
   <!-- <sly data-sly-test="false">
		<script type="text/javascript" src='/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-site/resources/au/js/au.js'></script>
	</sly> -->
   <!--[if lt IE 9]>
	<script src="/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/ie9/html5.js"></script>
	<![endif]-->
   <!--[if lte IE 9]>
	<script type='text/javascript' src='//cdnjs.cloudflare.com/ajax/libs/jquery-ajaxtransport-xdomainrequest/1.0.3/jquery.xdomainrequest.min.js'></script>
	<![endif]-->
   <script type="text/javascript">
    /* recaptcha script for Samsung 2020.07.10 */
		
		var conRecaptcha;
		var recaptchaCallback = function() {	
			 if($("#Con_reCaptcha").length > 0){
					conRecaptcha = grecaptcha.render('Con_reCaptcha', {
				    	'sitekey' : '6Lc-1PJCvNNABi8kAgpWEcwYx7rx3ymu1MABi8-tj-UJsll'
				    });
			 }
		};
   </script>
   <script defer="" src="https://www.google.com/recaptcha/api.js?onload=recaptchaCallback&amp;render=explicit" type="text/javascript">
   </script>
   <section aria-modal="true" class="trade-in-learn-more-popup" role="dialog">
    <div class="trade-in-learn-more-popup__dimmed">
    </div>
    <div class="trade-in-learn-more-popup__contents">
     <div class="scrollbar">
      <div class="trade-in-learn-more-popup__inner-wrap scrollbar__contents">
       <p class="trade-in-learn-more-popup__title">
        Cara kerja tukar tambah
       </p>
       <div class="trade-in-learn-more-popup__list-wrap">
        <ul class="trade-in-learn-more-popup__list">
         <li class="trade-in-learn-more-popup__list-item">
          <em class="trade-in-learn-more-popup__list-item-num">
           01
          </em>
          <div class="trade-in-learn-more-popup__list-item-text-wrap">
           <span class="trade-in-learn-more-popup__list-item-text-desc">
            Choose your new RODA37 | Roda 37 device and tell us about your old one.
            <br/>
            Jika memenuhi syarat, Anda akan melihat taksiran nilai tukar tambah.
           </span>
          </div>
         </li>
         <li class="trade-in-learn-more-popup__list-item">
          <em class="trade-in-learn-more-popup__list-item-num">
           02
          </em>
          <div class="trade-in-learn-more-popup__list-item-text-wrap">
           <span class="trade-in-learn-more-popup__list-item-text-desc">
            Get an upfront discount on the price of your new RODA37 | Roda 37 device.
           </span>
          </div>
         </li>
         <li class="trade-in-learn-more-popup__list-item">
          <em class="trade-in-learn-more-popup__list-item-num">
           03
          </em>
          <div class="trade-in-learn-more-popup__list-item-text-wrap">
           <span class="trade-in-learn-more-popup__list-item-text-desc">
            Kirimkan perangkat lama Anda untuk menyelesaikan tukar tambah.
           </span>
          </div>
         </li>
        </ul>
        <!--
			<sly data-sly-test="false">
              <div class="trade-in-learn-more-popup__cta-wrap">
                <a class="cta cta--underline cta--black cta--icon" href="https://www.samsung.com/pt/campanha-retomas/" title="Open in a New Window" target="_blank"> More Information 
                  <svg class="icon" focusable="false">
					<use xlink:href="#outlink-bold" href="#outlink-bold"></use>
                  </svg>
                </a>
              </div>
            </sly>
            -->
       </div>
      </div>
     </div>
     <button class="trade-in-learn-more-popup__close">
      <span class="hidden">
       TUTUP
      </span>
      <svg class="icon" focusable="false">
       <use href="#delete-bold" xlink:href="#delete-bold">
       </use>
      </svg>
     </button>
    </div>
   </section>
   <input id="tariffAdditionalPromotionCarrierUrl" type="hidden"/>
   <div class="component-area" style="">
    <section aria-modal="true" class="tariff-popup" role="dialog">
     <div class="tariff-popup__dimmed">
     </div>
     <div class="tariff-popup__contents">
      <div class="tariff-popup__contents-plan" style="display:block;">
       <div class="tariff-popup__inner-wrap scrollbar">
        <div class="tariff-popup__inner scrollbar__contents">
         <div class="tariff-popup__header">
          <div class="tariff-popup__headline">
           All from one hand
          </div>
          <p class="tariff-popup__desc">
           Now you get innovative smartphone with right tariff plan.
          </p>
         </div>
         <div class="tariff-popup__choose" role="tablist" style="display:none;">
          <div class="tariff-popup__choose-item" role="presentation">
           <a aria-selected="false" class="tariff-popup__choose-item-btn" href="javascript:;" id="choose-tab-1" role="tab">
            New Contracts
           </a>
          </div>
          <div class="tariff-popup__choose-item" role="presentation">
           <div class="tariff-popup__choose-tooltip">
            <div class="tariff-popup__choose-tooltip__btn-wrap">
             <button aria-expanded="false" class="tariff-popup__choose-tooltip__btn" type="button">
              <svg class="icon help" focusable="false">
               <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#help-regular">
               </use>
              </svg>
              <svg class="icon cancel" focusable="false">
               <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#cancel-bold">
               </use>
              </svg>
              <span class="hidden">
               see what this
              </span>
             </button>
             <span class="tariff-popup__choose-tooltip__arrow">
             </span>
            </div>
            <div class="tariff-popup__choose-tooltip__box" role="tooltip">
             <span class="tariff-popup__choose-tooltip__box-arrow">
             </span>
             <p class="tariff-popup__choose-tooltip__box-desc">
              Stay with your network operator.
             </p>
            </div>
           </div>
          </div>
         </div>
         <div aria-hidden="true" aria-labelledby="choose-tab-1" class="tariff-popup__choose-panel" id="choose-content-1" role="tabpanel">
          <div class="tariff-popup__tab-wrap">
           <div class="tariff-popup__tab-list-wrap">
            <button class="tariff-popup__tab-list-prev" role="button" style="display:none;">
             prev
             <svg class="icon" focusable="false">
              <use href="#previous-bold" xlink:href="#previous-bold">
              </use>
             </svg>
            </button>
            <div class="tariff-popup__tab-list-area">
             <!--/* UK, SE 경우 Tab Divider 를 숨기기 위해 .hide-divider 추가 /*-->
             <div class="tariff-popup__tab-list" role="tablist">
              <div class="tariff-popup__tab-item-wrap" role="presentation">
               <a class="tariff-popup__tab-item" href="javascript:void(0);">
               </a>
              </div>
             </div>
            </div>
            <button class="tariff-popup__tab-list-next" role="button">
             Next
             <svg class="icon" focusable="false">
              <use href="#next-bold" xlink:href="#next-bold">
              </use>
             </svg>
            </button>
            <div class="tariff-popup__tab-list-gl-left">
            </div>
            <div class="tariff-popup__tab-list-gl-right">
            </div>
           </div>
           <div class="tariff-popup__tab-panel-wrap">
            <div class="tariff-popup__tab-panel">
            </div>
           </div>
          </div>
         </div>
         <div aria-hidden="true" aria-labelledby="choose-tab-2" class="tariff-popup__choose-panel" id="choose-content-2" role="tabpanel">
          <div class="tariff-popup__tab-wrap">
           <div class="tariff-popup__tab-list-wrap">
            <button class="tariff-popup__tab-list-prev" role="button" style="display:none;">
             prev
             <svg class="icon" focusable="false">
              <use href="#previous-bold" xlink:href="#previous-bold">
              </use>
             </svg>
            </button>
            <div class="tariff-popup__tab-list-area">
             <!--/* UK, SE 경우 Tab Divider 를 숨기기 위해 .hide-divider 추가 /*-->
             <div class="tariff-popup__tab-list" role="tablist">
             </div>
            </div>
            <button class="tariff-popup__tab-list-next" role="button">
             Next
             <svg class="icon" focusable="false">
              <use href="#next-bold" xlink:href="#next-bold">
              </use>
             </svg>
            </button>
            <div class="tariff-popup__tab-list-gl-left">
            </div>
            <div class="tariff-popup__tab-list-gl-right">
            </div>
           </div>
           <div class="tariff-popup__tab-panel-wrap">
            <div class="tariff-popup__tab-panel">
            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
       <div class="tariff-popup__btn-wrap">
        <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step2:back" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-prev cta cta--outlined cta--black" style="display:none;">
         BATALKAN
        </button>
        <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step1:close" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-close cta cta--outlined cta--black">
         BATALKAN
        </button>
        <!-- CTA 활성화 시 disabled 제거, .cta--disabled 제거 -->
        <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step1:continue" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-next cta cta--contained cta--emphasis cta--disabled" disabled="">
         LANJUTKAN
        </button>
       </div>
      </div>
      <div class="tariff-popup__contents-plan-details" style="display:none;">
       <div class="tariff-popup__inner-wrap scrollbar">
        <div class="tariff-popup__inner scrollbar__contents">
         <div class="tariff-popup__header">
          <div class="tariff-popup__headline">
           The Network Plan Details
          </div>
          <p class="tariff-popup__desc">
          </p>
         </div>
         <div class="tariff-popup__plan-details-wrap">
          <section class="tariff-popup__plan-details expand">
           <a class="tariff-popup__plan-details-title" href="javascript:;" role="button">
            <span class="tariff-popup__plan-details-title-text">
             Plan Benefits
            </span>
            <span>
             <svg class="icon collapse">
              <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#open-down-bold">
              </use>
             </svg>
             <span class="hidden collapse">
              Klik untuk Memperluas
             </span>
             <svg class="icon expand">
              <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#close-up-bold">
              </use>
             </svg>
             <span class="hidden expand">
              Klik untuk Tutup
             </span>
            </span>
           </a>
           <div class="tariff-popup__plan-details-desc plan-benefits-desc">
           </div>
          </section>
          <section class="tariff-popup__plan-details">
           <a class="tariff-popup__plan-details-title" href="javascript:;" role="button">
            <span class="tariff-popup__plan-details-title-text">
             Out of Bundle Charges
            </span>
            <span>
             <svg class="icon collapse">
              <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#open-down-bold">
              </use>
             </svg>
             <span class="hidden collapse">
              Klik untuk Memperluas
             </span>
             <svg class="icon expand">
              <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#close-up-bold">
              </use>
             </svg>
             <span class="hidden expand">
              Klik untuk Tutup
             </span>
            </span>
           </a>
           <div class="tariff-popup__plan-details-desc out-of-bundle-charges-desc">
           </div>
          </section>
          <section class="tariff-popup__plan-details">
           <a class="tariff-popup__plan-details-title" href="javascript:;" role="button">
            <span class="tariff-popup__plan-details-title-text">
             Terms &amp; Conditions
            </span>
            <span>
             <svg class="icon collapse">
              <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#open-down-bold">
              </use>
             </svg>
             <span class="hidden collapse">
              Klik untuk Memperluas
             </span>
             <svg class="icon expand">
              <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#close-up-bold">
              </use>
             </svg>
             <span class="hidden expand">
              Klik untuk Tutup
             </span>
            </span>
           </a>
           <div class="tariff-popup__plan-details-desc term-conditions-desc">
           </div>
          </section>
         </div>
        </div>
       </div>
       <div class="tariff-popup__btn-wrap">
        <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step1:back" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-back cta cta--outlined cta--black">
         Kembali
        </button>
        <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step1:close" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-close cta cta--contained cta--emphasis">
         Tutup
        </button>
       </div>
      </div>
      <div class="tariff-popup__contents-plan-selected" style="display:none;">
       <div class="tariff-popup__inner-wrap scrollbar">
        <div class="tariff-popup__inner scrollbar__contents">
         <div class="tariff-popup__header">
          <div class="tariff-popup__headline">
           All from one hand
           <span class="tariff-popup__icon">
           </span>
          </div>
          <p class="tariff-popup__desc">
           Now you get innovative smartphone with right tariff plan.
          </p>
         </div>
         <div class="tariff-popup__selected-wrap">
          <div class="tariff-popup__selected">
           <div class="tariff-popup__selected-spec">
            <div class="tariff-popup__selected-spec-header">
             <div class="tariff-popup__selected-spec-img">
              <img alt="" src="#"/>
             </div>
             <div class="tariff-popup__selected-spec-detail">
              <strong class="tariff-popup__selected-spec-name">
              </strong>
              <span class="tariff-popup__selected-spec-value">
              </span>
             </div>
            </div>
            <div class="tariff-popup__selected-spec-desc">
             <ul class="tariff-popup__selected-spec-list">
             </ul>
            </div>
            <div class="tariff-popup__selected-add-opt">
            </div>
           </div>
           <div class="tariff-popup__selected-total">
            <div class="tariff-popup__selected-total-title">
             Upfront Cost
            </div>
            <div class="tariff-popup__selected-total-price">
            </div>
            <p class="tariff-popup__selected-total-desc">
             Der Anschlusspreis und monatlicher Tarifpreis werden vom jeweiligen Netzanbieter eingezogen. Du zahlst jetzt nur den einmaligen Ger&auml;tepreis.
            </p>
           </div>
          </div>
         </div>
         <div class="tariff-popup__checkbox-wrap">
         </div>
         <div class="tariff-popup__table-wrap">
          <div class="tariff-popup__table-inner">
          </div>
          <div class="tariff-popup__table-disclaimer">
          </div>
         </div>
        </div>
       </div>
       <div class="tariff-popup__btn-wrap">
        <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step2:back" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-prev cta cta--outlined cta--black">
         BACK
        </button>
        <!-- CTA 활성화 시 disabled 제거, .cta--disabled 제거 -->
        <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step2:confirm" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__btn-submit cta cta--contained cta--emphasis cta--disabled" disabled="">
         Terapkan
        </button>
       </div>
      </div>
      <div class="tariff-popup__contents-form" style="display:none;">
       <div class="tariff-popup__inner-wrap scrollbar">
        <div class="tariff-popup__inner scrollbar__contents">
         <div class="tariff-popup__header">
          <div class="tariff-popup__headline">
           Check the availabbility
          </div>
         </div>
         <div class="tariff-popup__step">
          <div class="tariff-popup__step-inner">
           <span class="tariff-popup__step-fill is-active">
           </span>
           <span class="tariff-popup__step-fill">
           </span>
           <span class="tariff-popup__step-fill">
           </span>
          </div>
         </div>
         <div class="tariff-popup__step-progress">
          <span class="hidden">
           1 of 3
          </span>
         </div>
         <div class="tariff-popup__validation-message">
          <strong class="tariff-popup__validation-message-title">
           Wrong address
          </strong>
          <div class="tariff-popup__validation-message-content">
           <p>
            Unfortunately, we cannot make you a DSL offer for the address you have checked.The address you have given is not unique, please choose from the address suggestions.
           </p>
          </div>
         </div>
         <div class="tariff-popup__form-wrap">
          <div class="tariff-popup__form-list">
           <div class="tariff-popup__form-item tariff-popup__form-item-wide" style="display:none;">
            <div class="menu menu--text-field" data-comp-name="menu" data-max-item-number="5" data-type="textField">
             <select aria-labelledby="tariff-addr-label-id" class="menu__select" tabindex="-1">
             </select>
             <p class="menu--text-field__hint" id="tariff-addr-label-id">
              Empfohlene Adresse
             </p>
             <button aria-expanded="false" aria-haspopup="listbox" aria-labelledby="tariff-addr-label-id tariff-text-label-id" class="menu__select-field" type="button">
              <span class="menu__select-field-text" id="tariff-text-label-id">
              </span>
              <svg aria-hidden="true" class="menu__select-field-icon down" focusable="false">
               <use href="#open-down-bold" xlink:href="#open-down-bold">
               </use>
              </svg>
              <svg aria-hidden="true" class="menu__select-field-icon up" focusable="false">
               <use href="#close-up-bold" xlink:href="#close-up-bold">
               </use>
              </svg>
             </button>
            </div>
           </div>
           <div class="tariff-popup__form-item tariff-popup__form-item-wide">
            <div class="text-field-v2" data-comp-name="textFieldv2">
             <label class="text-field-v2__hint" for="text-field-tariff-postcode">
              Postcode
             </label>
             <div class="text-field-v2__input-wrap">
              <input autocomplete="off" class="text-field-v2__input" id="text-field-tariff-postcode" maxlength="5" name="postCode" type="text"/>
              <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
               <svg aria-hidden="true" class="icon delete" focusable="false">
                <use href="#cancel-bold" xlink:href="#cancel-bold">
                </use>
               </svg>
              </button>
             </div>
             <p aria-hidden="true" class="text-field-v2__text assistive">
              Please provide a valid postcode
             </p>
             <p aria-hidden="true" class="text-field-v2__text error">
              Please enter correct information again.
             </p>
            </div>
           </div>
           <div class="tariff-popup__form-item">
            <div class="text-field-v2" data-comp-name="textFieldv2">
             <label class="text-field-v2__hint" for="text-field-tariff-street">
              Street
             </label>
             <div class="text-field-v2__input-wrap">
              <input autocomplete="off" class="text-field-v2__input" id="text-field-tariff-street" name="streetName" type="text"/>
              <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
               <svg aria-hidden="true" class="icon delete" focusable="false">
                <use href="#cancel-bold" xlink:href="#cancel-bold">
                </use>
               </svg>
              </button>
             </div>
             <p aria-hidden="true" class="text-field-v2__text assistive">
              Please provide a valid street
             </p>
             <p aria-hidden="true" class="text-field-v2__text error">
              Please enter correct information again.
             </p>
            </div>
           </div>
           <div class="tariff-popup__form-item">
            <div class="text-field-v2" data-comp-name="textFieldv2">
             <label class="text-field-v2__hint" for="text-field-3">
              House number
             </label>
             <div class="text-field-v2__input-wrap">
              <input autocomplete="off" class="text-field-v2__input" id="text-field-3" name="houseNumber" type="text"/>
              <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
               <svg aria-hidden="true" class="icon delete" focusable="false">
                <use href="#cancel-bold" xlink:href="#cancel-bold">
                </use>
               </svg>
              </button>
             </div>
             <p aria-hidden="true" class="text-field-v2__text assistive">
              Please provide a valid house number
             </p>
             <p aria-hidden="true" class="text-field-v2__text error">
              Please enter correct information again.
             </p>
            </div>
           </div>
           <div class="tariff-popup__form-item">
            <div class="text-field-v2" data-comp-name="textFieldv2">
             <label class="text-field-v2__hint" for="text-field-4">
              Additional house information
             </label>
             <div class="text-field-v2__input-wrap">
              <input autocomplete="off" class="text-field-v2__input" id="text-field-4" name="houseNumberAddition" type="text"/>
              <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
               <svg aria-hidden="true" class="icon delete" focusable="false">
                <use href="#cancel-bold" xlink:href="#cancel-bold">
                </use>
               </svg>
              </button>
             </div>
             <p aria-hidden="true" class="text-field-v2__text assistive">
              Additional information placeholder
             </p>
             <p aria-hidden="true" class="text-field-v2__text error">
              Please enter correct information again.
             </p>
            </div>
           </div>
           <div class="tariff-popup__form-item">
            <div class="text-field-v2" data-comp-name="textFieldv2">
             <label class="text-field-v2__hint" for="text-field-5">
              City
             </label>
             <div class="text-field-v2__input-wrap">
              <input autocomplete="off" class="text-field-v2__input" id="text-field-5" name="locality" type="text"/>
              <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
               <svg aria-hidden="true" class="icon delete" focusable="false">
                <use href="#cancel-bold" xlink:href="#cancel-bold">
                </use>
               </svg>
              </button>
             </div>
             <p aria-hidden="true" class="text-field-v2__text assistive">
              Please provide a valid city
             </p>
             <p aria-hidden="true" class="text-field-v2__text error">
              Please enter correct information again.
             </p>
            </div>
           </div>
          </div>
         </div>
         <p class="tariff-popup__form-txt">
          *Required fields
         </p>
         <div class="tariff-popup__disclaimer-wrap">
          <div class="tariff-popup__disclaimer">
           Anda dapat menemukan informasi tentang pengolahan data pribadi melalui link
           <a href="https://www.samsung.com/" target="_blank" title="Open in a new window">
            Kebijakan privasi
           </a>
           .
          </div>
         </div>
        </div>
       </div>
       <div class="tariff-popup__btn-wrap">
        <button class="tariff-popup__btn-close cta cta--outlined cta--black">
         Batalkan
        </button>
        <!-- CTA 활성화 시 disabled 제거, .cta--disabled 제거 -->
        <button class="tariff-popup__btn-next cta cta--contained cta--emphasis cta--disabled" disabled="">
         Lanjutkan
        </button>
       </div>
      </div>
      <button an-ac="pd buying tool" an-ca="option click" an-la="tariff:step1:close" an-tr="header(pim)_service option selector tariff-product detail-text-button" class="tariff-popup__close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
      </button>
     </div>
    </section>
   </div>
   <div class="tariff-info-popup">
    <div class="layer-popup" id="tariff-info-popup" role="dialog" style="display:block">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <div class="layer-popup__title">
         Pay monthly phone contracts
        </div>
        <p class="layer-popup__desc">
         Buy your phone along with an inclusive monthly network plan and pay monthly*
        </p>
        <div class="tariff-info-popup__wrap">
         <div class="tariff-info-popup__inner">
          <div class="tariff-info-popup__more">
           <ul class="tariff-info-popup__more-list">
            <li>
             <strong class="tariff-info-popup__more-title">
              Choose your network
             </strong>
             <p class="tariff-info-popup__more-text">
              Choose from a range of networks and inclusive monthly plans to get started with your new Galaxy phone straight away.
             </p>
            </li>
            <li>
             <strong class="tariff-info-popup__more-title">
              Bayar Bulanan
             </strong>
             <p class="tariff-info-popup__more-text">
              Pay for your phone and an inclusive bundle of calls, texts and data in one easy-to-manage monthly fee.
             </p>
            </li>
            <li>
             <strong class="tariff-info-popup__more-title">
              Next steps
             </strong>
             <p class="tariff-info-popup__more-text">
              You will be redirected to our trusted partner, A1 Comms Ltd (trading as Mobileshop), to purchase your phone and setup your monthly plan.
             </p>
            </li>
           </ul>
          </div>
          <div class="tariff-info-popup__info">
          </div>
         </div>
        </div>
       </div>
      </div>
      <div class="tariff-info-popup__cta">
       <!--/* P6의 cta 적용 방식에 따라 마크업 변경 */ -->
       <a class="cta cta--contained cta--emphasis" href="javascript:void(0);" title="Link Title">
        Choose your plan
       </a>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Layer Popup Close
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <input id="cfTradeInConditionCheckYn" type="hidden"/>
   <input id="cfTradeInCategoryUseYn" type="hidden"/>
   <section aria-modal="true" class="trade-in-popup" id="hubble-tradein-layer" role="dialog">
    <div class="trade-in-popup__dimmed">
    </div>
    <div class="trade-in-popup__contents">
     <!-- new-hybris -->
     <div class="trade-in-popup__zipcode-wrap" role="dialog">
      <div class="scrollbar">
       <div class="trade-in-popup__inner-wrap scrollbar__contents">
        <p class="trade-in-popup__title">
         Cek layanan tukar tambah di area Anda!
        </p>
        <div class="trade-in-popup__imei">
         <div class="trade-in-popup__imei-desc-wrap">
          <p class="trade-in-popup__imei-desc">
           Akses menu Tukar Tambah di aplikasi Samsung Gift Indonesia atau unduh aplikasi SS.com Trade In untuk memeriksakan ponsel pintar Anda. Setelah ponsel Anda lolos uji, IMEI perangkat lama Anda akan tercatat dalam basis data kami, sehingga Anda dapat menikmati diskon tukar tambah khusus.
          </p>
          <p class="trade-in-popup__imei-desc">
           <a href="https://www.samsung.com/" target="_blank" title="Buka di Tab Baru">
            SAMSUNG TRADE IN
           </a>
          </p>
         </div>
         <div class="trade-in-popup__imei-form-wrap">
          <strong class="trade-in-popup__imei-form-title">
           Masukkan kode pos Anda
          </strong>
          <div class="trade-in-popup__imei-form">
           <div class="text-field-v2 no-title">
            <label class="text-field-v2__hint" for="zipcode-input">
             Kode Pos (5 angka)
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="off" class="text-field-v2__input" id="zipcode-input" maxlength="5" type="text" value=""/>
             <button class="text-field-v2__input-icon delete" title="Delete">
              <svg class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
            </div>
            <p class="text-field-v2__text error">
            </p>
            <p class="text-field-v2__text success">
             Tukar tambah tersedia di area&nbsp;kode pos Anda
            </p>
           </div>
          </div>
         </div>
        </div>
        <div class="trade-in-popup__dropdown-wrap">
         <div class="trade-in-popup__brand-dropdown-wrap">
          <p class="trade-in-popup__dropdown-title">
           Estimasi harga tertinggi perangkat lama Anda
          </p>
          <div class="trade-in-popup__dropdown">
           <button class="trade-in-popup__dropdown--select-field">
            <span class="trade-in-popup__dropdown--select-field-name">
             Select Brand
            </span>
           </button>
           <div class="trade-in-popup__dropdown--select-list scrollbar">
            <ul class="scrollbar__contents">
            </ul>
           </div>
          </div>
         </div>
         <div class="trade-in-popup__model-dropdown-wrap">
          <p class="trade-in-popup__dropdown-title">
           Estimasi harga tertinggi perangkat lama Anda
          </p>
          <div class="trade-in-popup__dropdown">
           <button class="trade-in-popup__dropdown--select-field">
            <span class="trade-in-popup__dropdown--select-field-name">
             Select Model
            </span>
            <span class="trade-in-popup__dropdown--select-field-price">
            </span>
           </button>
           <div class="trade-in-popup__dropdown--select-list scrollbar">
            <ul class="scrollbar__contents">
             <li class="trade-in-popup__dropdown--search-wrap">
              <label class="trade-in-popup__dropdown--search-label" for="trade-in-popup__dropdown--search-model">
               Search...
              </label>
              <input autocomplete="off" class="trade-in-popup__dropdown--search-input" id="trade-in-popup__dropdown--search-model" type="text"/>
              <button class="trade-in-popup__dropdown--search-btn" type="submit">
               <span class="hidden">
                select device model search
               </span>
              </button>
             </li>
            </ul>
           </div>
          </div>
         </div>
        </div>
       </div>
      </div>
      <div class="trade-in-popup__btn-wrap">
       <!-- CTA 의 동작에 따라 .trade-in-popup__btn-close, .trade-in-popup__btn-back, .trade-in-popup__btn-continue, trade-in-popup__btn-apply 추가 -->
       <button class="trade-in-popup__btn-close cta cta--outlined cta--black">
        Tutup
       </button>
       <!-- CTA 활성화 시 .cta--disabled 제거 -->
       <button aria-disabled="true" class="trade-in-popup__btn-continue cta cta--contained cta--emphasis cta--disabled" stepname="zipcode">
        Lanjutkan
       </button>
      </div>
     </div>
     <div class="trade-in-popup__imei-wrap" role="dialog">
      <div class="scrollbar">
       <div class="trade-in-popup__inner-wrap scrollbar__contents">
        <p class="trade-in-popup__title">
         Masukkan IMEI perangkat lama Anda
        </p>
        <!-- new-hybris -->
        <strong class="trade-in-popup__procedure-title">
         Prosedur tukar tambah permainan
        </strong>
        <ul class="trade-in-popup__procedure">
         <li class="trade-in-popup__procedure-item">
          <div class="trade-in-popup__procedure-item-img">
          </div>
          <p class="trade-in-popup__procedure-item-desc">
           1. Download App SS.com
          </p>
          <div class="trade-in-popup__procedure-link-wrap">
           <a class="trade-in-popup__procedure-link" href="https://www.samsung.com/">
           </a>
           <a class="trade-in-popup__procedure-link" href="https://www.samsung.com/">
           </a>
          </div>
          <p class="trade-in-popup__procedure-item-desc">
           atau
           <br/>
           Gunakan App
           <br/>
           <a aria-label="Open in a new window" href="https://www.samsung.com/" target="_blank" title="Buka di Tab Baru">
            Samsung Gift Indonesia
           </a>
          </p>
          <div class="trade-in-popup__procedure-link-wrap">
           <a class="trade-in-popup__procedure-link" href="https://www.samsung.com/" target="_blank" title="Buka di Tab Baru">
           </a>
          </div>
         </li>
         <li class="trade-in-popup__procedure-item">
          <div class="trade-in-popup__procedure-item-img">
          </div>
          <p class="trade-in-popup__procedure-item-desc">
           2. Lanjutkan proses pada aplikasi untuk mendapatkan harga estimasi  smartphone
          </p>
         </li>
         <li class="trade-in-popup__procedure-item">
          <div class="trade-in-popup__procedure-item-img">
          </div>
          <p class="trade-in-popup__procedure-item-desc">
           3. Kembali ke laman produk Galaxy yang Anda inginkan dan masukkan kode IMEI
          </p>
         </li>
         <li class="trade-in-popup__procedure-item">
          <div class="trade-in-popup__procedure-item-img">
          </div>
          <p class="trade-in-popup__procedure-item-desc">
           4. Lanjutkan dengan menyetujui harga perangkat lama Anda
          </p>
         </li>
        </ul>
        <div class="trade-in-popup__imei">
         <div class="trade-in-popup__imei-method-wrap">
          <strong class="trade-in-popup__imei-method-title">
           Cara menemukan IMEI Anda
          </strong>
          <div class="trade-in-popup__imei-method">
           <div class="trade-in-popup__imei-method-img">
           </div>
           <strong class="trade-in-popup__imei-method-num">
            <span>
             *
            </span>
            #06#
           </strong>
          </div>
          <ul class="trade-in-popup__imei-method-list">
           <li class="trade-in-popup__imei-method-list-item">
            <span>
             Option 1
            </span>
            <span>
             Tekan * # 06 # untuk menemukan IMEI Anda.
            </span>
           </li>
           <li class="trade-in-popup__imei-method-list-item">
            <span>
             Option 2
            </span>
            <span>
             Buka Pengaturan&gt; Umum&gt; Tentang menampilkan IMEI.
            </span>
           </li>
           <!-- new-hybris -->
          </ul>
         </div>
         <div class="trade-in-popup__imei-form-wrap">
          <strong class="trade-in-popup__imei-form-title">
           Masukkan nomor IMEI Anda
          </strong>
          <div class="trade-in-popup__imei-form">
           <div class="text-field-v2 no-title">
            <label class="text-field-v2__hint" for="imei-input">
             Nomor IMEI (15 digit)
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="off" class="text-field-v2__input" id="imei-input" maxlength="15" type="text" value=""/>
             <button class="text-field-v2__input-icon delete" title="Delete">
              <svg class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
            </div>
            <p class="text-field-v2__text error">
             Mohon masukkan IMEI atau Nomor Serial yang valid
            </p>
            <p class="text-field-v2__text success">
             Benar
            </p>
           </div>
          </div>
         </div>
        </div>
        <div class="trade-in-popup__confirm-terms">
        </div>
        <div class="trade-in-popup__disclaimer-wrap">
         <p class="trade-in-popup__disclaimer">
         </p>
        </div>
       </div>
      </div>
      <div class="trade-in-popup__btn-wrap">
       <!-- CTA 의 동작에 따라 .trade-in-popup__btn-close, .trade-in-popup__btn-back, .trade-in-popup__btn-continue, trade-in-popup__btn-apply 추가 -->
       <button class="trade-in-popup__btn-back cta cta--outlined cta--black" stepname="imei">
        Kembali
       </button>
       <!-- CTA 활성화 시 .cta--disabled 제거 -->
       <button aria-disabled="true" class="trade-in-popup__btn-continue cta cta--contained cta--emphasis cta--disabled" stepname="imei">
        Lanjutkan
       </button>
      </div>
     </div>
     <div class="trade-in-popup__condition-wrap" role="dialog">
      <div class="scrollbar">
       <div class="trade-in-popup__inner-wrap scrollbar__contents">
        <p class="trade-in-popup__title">
         Last step, Is your phone in good condition?
        </p>
        <form id="conditionForm" method="post" name="conditionForm">
         <ul class="trade-in-popup__condition-list">
         </ul>
        </form>
        <!-- 필요 시 추가 -->
        <!-- 활성화 시 .trade-in-popup__condition-error--show 추가 -->
        <p class="trade-in-popup__condition-error">
         Not eligible for trade-in
        </p>
        <!-- new-hybris  -->
        <div class="trade-in-popup__disclaimer-wrap">
         <p class="trade-in-popup__disclaimer">
         </p>
        </div>
       </div>
      </div>
      <div class="trade-in-popup__btn-wrap">
       <!-- CTA 의 동작에 따라 .trade-in-popup__btn-close, .trade-in-popup__btn-back, .trade-in-popup__btn-continue, trade-in-popup__btn-apply 추가 -->
       <button class="trade-in-popup__btn-back cta cta--outlined cta--black" stepname="condition">
        Kembali
       </button>
       <!-- CTA 활성화 시 .cta--disabled 제거 -->
       <button aria-disabled="true" class="trade-in-popup__btn-continue cta cta--contained cta--emphasis cta--disabled" stepname="condition">
        Lanjutkan
       </button>
      </div>
     </div>
     <div class="trade-in-popup__apply-wrap" role="dialog">
      <div class="scrollbar">
       <div class="trade-in-popup__inner-wrap scrollbar__contents">
        <p class="trade-in-popup__title">
         Harga diskon tukar tambah yang Anda&nbsp;dapatkan
        </p>
        <div class="trade-in-popup__summary-wrap">
         <div class="trade-in-popup__summary">
          <div class="trade-in-popup__summary-product-wrap">
           <strong class="trade-in-popup__summary-product-brand">
           </strong>
           <strong class="trade-in-popup__summary-product-model">
           </strong>
           <span class="trade-in-popup__summary-product-number">
           </span>
          </div>
          <div class="trade-in-popup__summary-price-wrap">
           <span class="trade-in-popup__summary-price-title cashbacklist">
            Harga Tukar Tambah
           </span>
           <em class="trade-in-popup__summary-price">
           </em>
           <span class="trade-in-popup__summary-price-desc">
           </span>
          </div>
         </div>
         <div class="trade-in-popup__summary-message-wrap">
          <!-- new-hybris -->
          <p class="trade-in-popup__summary-message">
          </p>
          <p class="trade-in-popup__summary-message--error">
          </p>
         </div>
        </div>
        <!-- <sly data-sly-test="false">
				<div class="trade-in-popup__apply-how-to">
				<strong class="trade-in-popup__apply-how-to-title">How to save money on a new device?</strong>
					<ul class="trade-in-popup__apply-how-to-list">
						<li class="trade-in-popup__apply-how-to-item">
							<span class="trade-in-popup__apply-how-to-item-num">1.</span>
							<span class="trade-in-popup__apply-how-to-item-text">Untuk smartphone lama Anda, dapatkan diskon untuk smartphone baru di ritel-ritel kami</span>
						</li>
						<li class="trade-in-popup__apply-how-to-item">
							<span class="trade-in-popup__apply-how-to-item-num">2.</span>
							<span class="trade-in-popup__apply-how-to-item-text">Nilai smartphone lama ditentukan oleh konsultan di lokasi penjualan , tergantung pada kondisi dan model perangkat.</span>
						</li>
						<li class="trade-in-popup__apply-how-to-item">
							<span class="trade-in-popup__apply-how-to-item-num">3.</span>
							<span class="trade-in-popup__apply-how-to-item-text">Kunjungi toko penjualan yang paling nyaman bagi Anda. Tinggalkan smartphone lama Anda dan beli yang baru.</span>
						</li>
					</ul>
				</div>
			</sly> -->
        <div class="trade-in-popup__confirm-terms s-border-top">
         <strong class="trade-in-popup__confirm-terms-title">
          Konfirmasi Syarat dan Ketentuan
         </strong>
        </div>
        <div class="trade-in-popup__disclaimer-wrap">
         <p class="trade-in-popup__disclaimer">
         </p>
        </div>
       </div>
      </div>
      <div class="trade-in-popup__btn-wrap">
       <!-- CTA 의 동작에 따라 .trade-in-popup__btn-close, .trade-in-popup__btn-back, .trade-in-popup__btn-continue, trade-in-popup__btn-apply 추가 -->
       <button class="trade-in-popup__btn-back cta cta--outlined cta--black" stepname="apply">
        Kembali
       </button>
       <!-- CTA 활성화 시 .cta--disabled 제거 -->
       <button aria-disabled="true" class="trade-in-popup__btn-apply cta cta--contained cta--emphasis cta--disabled">
        Yakin
       </button>
      </div>
     </div>
     <button class="trade-in-popup__close">
      <span class="hidden">
       Tutup
      </span>
      <svg class="icon" focusable="false">
       <use href="#delete-bold" xlink:href="#delete-bold">
       </use>
      </svg>
     </button>
    </div>
   </section>
   <div aria-modal="true" class="upgrade-popup" role="dialog">
    <div class="upgrade-popup__dimmed">
    </div>
    <div class="upgrade-popup__content">
     <div class="scrollbar">
      <div class="upgrade-popup__content-wrap scrollbar__contents">
       <div class="upgrade-popup__header">
        <strong class="upgrade-popup__title">
         Upgrade Terms and Conditions
        </strong>
       </div>
       <div class="upgrade-popup__body">
        <div class="upgrade-popup__apply">
         <div class="upgrade-popup__apply-img">
          <svg class="icon">
           <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#phone-light">
           </use>
          </svg>
         </div>
         <div class="upgrade-popup__apply-content">
         </div>
        </div>
        <ul class="upgrade-popup__condition-wrap">
         <li class="upgrade-popup__condition">
          <div class="upgrade-popup__condition-img">
          </div>
          <p class="upgrade-popup__desc">
           Hidupkan ponsel dan tahan catu daya
          </p>
         </li>
         <li class="upgrade-popup__condition">
          <div class="upgrade-popup__condition-img">
          </div>
          <p class="upgrade-popup__desc">
           Keausan normal
          </p>
         </li>
         <li class="upgrade-popup__condition">
          <div class="upgrade-popup__condition-img">
          </div>
          <p class="upgrade-popup__desc">
           Layar berfungsi &amp; tidak ada layar yang retak
          </p>
         </li>
         <li class="upgrade-popup__condition">
          <div class="upgrade-popup__condition-img">
          </div>
          <p class="upgrade-popup__desc">
           Not blacklisted
          </p>
         </li>
         <li class="upgrade-popup__condition">
          <div class="upgrade-popup__condition-img">
          </div>
          <p class="upgrade-popup__desc">
           Factory reset &amp; non-aktifkan penguncian aplikasi
          </p>
         </li>
        </ul>
        <div class="upgrade-popup__check-info">
        </div>
        <div class="upgrade-popup__disclaimer-wrap">
         <p>
         </p>
        </div>
       </div>
      </div>
     </div>
     <div class="upgrade-popup__footer">
      <div class="upgrade-popup__cta-wrap">
       <button an-ac="pd buying tool" an-ca="option click" an-la="upgrade program:close" an-tr="header(pim)_service option selector-product detail-text-button" class="cta cta--outlined cta--black upgrade-popup__cta--close">
        TUTUP
       </button>
       <button an-ac="pd buying tool" an-ca="option click" an-la="upgrade program:confirm" an-tr="header(pim)_service option selector-product detail-text-button" class="cta cta--contained cta--emphasis upgrade-popup__cta--submit">
        Yakin
       </button>
      </div>
     </div>
     <button class="upgrade-popup__close">
      <svg class="icon">
       <use href="#delete-bold" xlink:href="#delete-bold">
       </use>
      </svg>
      <span class="hidden">
       Tutup Layar Popup
      </span>
     </button>
    </div>
   </div>
   <div aria-modal="true" class="upgrade-learn-more-popup" role="dialog" style="display: none">
    <div class="upgrade-learn-more-popup__dimmed">
    </div>
    <div class="upgrade-learn-more-popup__content">
     <div class="scrollbar">
      <div class="upgrade-learn-more-popup__content-wrap scrollbar__contents">
      </div>
      <button class="upgrade-learn-more-popup__close">
       <svg class="icon">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
       <span class="hidden">
        close popup
       </span>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="cancel-return-policy-popup" role="dialog" tabindex="0">
    <div class="layer-popup">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title">
        </p>
        <div class="cancel-return-policy-popup__description">
         <div class="cancel-return-policy-popup__content">
          <p class="cancel-return-policy-popup__text">
          </p>
         </div>
        </div>
       </div>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="warranty-policy-popup" role="dialog" tabindex="0">
    <div class="layer-popup">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title">
         Jaminan
        </p>
        <div class="warranty-policy-popup__description">
         <div class="warranty-policy-popup__content">
          <p class="warranty-policy-popup__text">
          </p>
         </div>
        </div>
       </div>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div class="fold-alert-popup">
    <div class="layer-popup" id="fold-alert-popup" role="dialog" style="display:block" tabindex="0">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <div class="layer-popup__title">
         We recommend to set as below to see optimized screen
        </div>
        <div class="fold-alert-popup__wrap">
         <div class="fold-alert-popup__inner">
          <ul class="fold-alert-popup__list">
           <li class="fold-alert-popup__item">
            <strong class="fold-alert-popup__title">
             Option 01
            </strong>
            <p class="fold-alert-popup__text">
             Rotate the device until it is horizontal to view the screen in landscape mode.
            </p>
           </li>
           <li class="fold-alert-popup__item">
            <strong class="fold-alert-popup__title">
             Option 02
            </strong>
            <p class="fold-alert-popup__text">
             Tab on desktop version in the browser.
            </p>
           </li>
          </ul>
         </div>
        </div>
       </div>
      </div>
      <div class="fold-alert-popup__cta">
       <!--/* P6의 cta 적용 방식에 따라 마크업 변경 */ -->
       <a class="cta cta--outlined cta--black" href="https://www.samsung.com/" title="Tutup">
        Tutup
       </a>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="eip-popup" role="dialog">
    <div class="layer-popup" id="eip-popup">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <div class="layer-popup__title">
         Program CICILAN 0%
        </div>
        <div class="eip-popup__wrap">
         <p class="eip-popup__top-text">
          <strong>
           Harga Produk:
           <span class="eip-popup__top-text--price">
            Rp 17.099.000
           </span>
          </strong>
         </p>
         <div class="tab">
          <ul class="tab__list" role="tablist">
           <li class="tab__item" role="presentation">
            <button class="tab__item-title" role="tab">
             Cicilan Kartu Kredit
             <span class="tab__item-line">
             </span>
            </button>
           </li>
          </ul>
         </div>
         <div class="eip-popup__tab-wrap">
          <div class="eip-popup__tab">
           <div class="eip-popup__tab--dropdown-wrap">
            <p class="eip-popup__tab--dropdown-title">
             Pilih Bank
            </p>
            <button class="eip-popup__tab--dropdown">
             BCA
            </button>
           </div>
           <div class="eip-popup__tab--select-wrap scrollbar">
            <div class="scrollbar__contents">
             <ul>
             </ul>
            </div>
           </div>
           <div class="eip-popup__tab--table-wrap scrollbar">
            <div class="scrollbar__contents">
            </div>
           </div>
          </div>
         </div>
        </div>
       </div>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#cancel-close-regular" xlink:href="#cancel-close-regular">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="hubble-careinfo-popup" role="dialog">
    <div class="layer-popup" id="hubble-careinfo">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title">
         Samsung Care+
        </p>
        <div class="hubble-careinfo-popup__body">
         <div class="hubble-careinfo-popup__info-wrap">
          <dl class="hubble-careinfo-popup__info">
          </dl>
         </div>
         <div class="hubble-careinfo-popup__explain">
          <p>
           Samsung Care+ Disclaimer with link
          </p>
         </div>
        </div>
       </div>
      </div>
      <!-- siteCode == 'za' -->
      <button class="hubble-care-popup__close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="sc-learn-more-popup" role="dialog">
    <div class="layer-popup" id="ScLearnMorePopup">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title">
         Here&rsquo;s what&rsquo;s covered
        </p>
        <div class="sc-learn-more-popup__body">
         <ul class="sc-learn-more-popup__list">
          <li class="sc-learn-more-popup__item">
           <div class="sc-learn-more-popup__image">
           </div>
           <strong class="sc-learn-more-popup__title">
            Hardware repairs
           </strong>
           <p class="sc-learn-more-popup__text">
            Get fast, convenient repairs using genuine RODA37 | Roda 37 parts, from our authorized technicians.
           </p>
          </li>
          <li class="sc-learn-more-popup__item">
           <div class="sc-learn-more-popup__image">
           </div>
           <strong class="sc-learn-more-popup__title">
            Software coverage
           </strong>
           <p class="sc-learn-more-popup__text">
            If your device isn&rsquo;t running smoothly, we&rsquo;ll check and fix the issue.
           </p>
          </li>
          <li class="sc-learn-more-popup__item">
           <div class="sc-learn-more-popup__image">
           </div>
           <strong class="sc-learn-more-popup__title">
            Battery replacement
           </strong>
           <p class="sc-learn-more-popup__text">
            Stay powered up with hassle-free battery replacements.
           </p>
          </li>
          <li class="sc-learn-more-popup__item">
           <div class="sc-learn-more-popup__image">
           </div>
           <strong class="sc-learn-more-popup__title">
            4 claims within
           </strong>
           <p class="sc-learn-more-popup__text">
            Make up to 4 claims for repair  or replacement  within 2 years,  and save with a low deductible  per claim.
           </p>
          </li>
         </ul>
         <div class="sc-learn-more-popup__cta">
          <a aria-label="Link Title" class="cta cta--underline cta--black cta--icon" href="https://www.samsung.com/" target="_blank">
           See all benefits
           <svg aria-hidden="true" class="icon" focusable="false">
            <use href="#outlink-bold" xlink:href="#outlink-bold">
            </use>
           </svg>
          </a>
         </div>
         <div class="sc-learn-more-popup__disclaimer">
         </div>
        </div>
       </div>
      </div>
      <button class="sc-learn-more-popup__close">
       <span class="hidden">
        Close popup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="hubble-care-popup smcpopup" role="dialog">
    <div class="layer-popup" id="hubble-care">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title layer-popup__title--no-icon">
         Samsung Care+
        </p>
        <p class="layer-popup__desc">
         <!-- CRHQ-3719 -->
         Layanan Perbaikan Secara Total untuk Smartphone Galaxy Anda. Hindari Kejadian Tidak Terduga Dengan Perlindungan Ekstra
        </p>
        <div class="hubble-care-popup__body">
         <div class="hubble-care-popup__smc">
          <div class="hubble-care-popup__smc-inner">
          </div>
          <p class="hubble-care-popup__smc-message" style="display: none">
          </p>
         </div>
         <div class="hubble-care-popup__check">
          <div class="hubble-care-popup__check-title">
           Syarat dan Ketentuan Samsung Protection
          </div>
          <ul class="hubble-care-popup__check-list-wrap">
          </ul>
          <p aria-hidden="true" class="hubble-care-popup__check-error">
           *Anda harus menyetujui terlebih dahulu
          </p>
         </div>

        </div>
       </div>
      </div>
      <div class="hubble-care-popup__foot">
       <div class="hubble-care-popup__button">
        <div class="hubble-care-popup__button-inner">
         <div class="hubble-care-popup__button-item">
          <a an-ac="pd buying tool" an-ca="option click" an-la="samsung care:close" an-tr="header(pim)_service option selector:samsung care-product detail-close-option_click1" class="cta cta--outlined cta--black" href="javascript:void(0)" role="button">
           Tutup
          </a>
         </div>
         <div class="hubble-care-popup__button-item">
          <a an-ac="pd buying tool" an-ca="option click" an-la="samsung care:confirm" an-tr="header(pim)_service option selector:samsung care-product detail-confirm-option_click1" aria-disabled="true" class="cta cta--contained cta--emphasis cta--disabled" href="javascript:void(0)" role="button">
           Yakin
          </a>
         </div>
        </div>
       </div>
      </div>
      <button class="hubble-care-popup__close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="hubble-care-popup__alert" role="dialog" tabindex="0">
    <div class="layer-popup" id="hubble-care-alert1">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents">
       Ich habe die Allgemeinen Versicherungsbedingungen heruntergeladen, gelesen und erkl&auml;re mich mit diesen einverstanden.
       <div class="hubble-care-popup__alert-button">
        <a class="cta cta--contained cta--emphasis" href="https://www.samsung.com/" title="Best&auml;tigen">
         Best&auml;tigen
        </a>
       </div>
      </div>
      <button class="hubble-care-popup__alert-close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="hubble-care-popup__alert" role="dialog" tabindex="0">
    <div class="layer-popup" id="hubble-care-alert2">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents">
       Ich habe das Informationsblatt zur Versicherung heruntergeladen und sorgf&auml;ltig durchgelesen.
       <div class="hubble-care-popup__alert-button">
        <a class="cta cta--contained cta--emphasis" href="https://www.samsung.com/" title="Best&auml;tigen">
         Best&auml;tigen
        </a>
       </div>
      </div>
      <button class="hubble-care-popup__alert-close">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <input id="WishlistPopupUrl" type="hidden" value="/id/web/my-wishlist/"/>
   <div class="wishlist-popup">
    <div aria-modal="true" class="layer-popup" id="wishlist-popup" role="dialog" style="display:block">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents">
       <p class="layer-popup__title">
       </p>
       <div class="wishlist-popup__desc">
       </div>
       <div class="wishlist-popup__selectbox__wrap">
        <div class="wishlist-popup__selectbox">
         <div class="wishlist-popup__selectbox-inner">
          <div class="menu filled">
           <select class="menu__select" data-default-message="My Wishlist" tabindex="-1">
            <option value="">
             My Wishlist 1
            </option>
            <option value="">
             My Wishlist 2
            </option>
            <option value="">
             My Wishlist 3
            </option>
            <option value="">
             My Wishlist 4
            </option>
            <option value="">
             My Wishlist 5
            </option>
            <option value="">
             My Wishlist 6
            </option>
            <option value="">
             My Wishlist 7
            </option>
            <option value="">
             My Wishlist 8
            </option>
            <option value="">
             My Wishlist 9
            </option>
           </select>
           <button aria-expanded="false" aria-haspopup="listbox" class="menu__select-field">
            <span class="menu__select-field-text">
            </span>
            <svg aria-hidden="true" class="menu__select-field-icon down" focusable="false">
             <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#open-down-bold">
             </use>
            </svg>
            <svg aria-hidden="true" class="menu__select-field-icon up" focusable="false">
             <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#close-up-bold">
             </use>
            </svg>
           </button>
          </div>
         </div>
        </div>
       </div>
      </div>
      <div class="wishlist-popup__cta-wrap">
       <div class="wishlist-popup__cta">
        <a aria-label="Link Title" class="cta cta--outlined cta--black" href="https://www.samsung.com/" role="button">
        </a>
       </div>
       <div class="wishlist-popup__cta">
        <a class="cta cta--contained cta--emphasis" href="https://www.samsung.com/" role="button">
        </a>
       </div>
      </div>
      <button class="layer-popup__close wishlist-popup__close" type="button">
       <span class="hidden">
        Close popup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="extended-warranty-popup" role="dialog" tabindex="0">
    <div class="layer-popup" id="extended-warranty">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title">
         EXTENDED WARRANTY
        </p>
        <p class="layer-popup__desc">
         Layanan Perbaikan Secara Total untuk Smartphone Galaxy Anda. Hindari Kejadian Tidak Terduga Dengan Perlindungan Ekstra
        </p>
        <div class="extended-warranty-popup__body">
         <div class="extended-warranty-popup__smc">
          <div class="extended-warranty-popup__smc-inner">
          </div>
          <p class="extended-warranty-popup__smc-message" style="display: none">
           ※ Cover until canceled. Financing program is not available with device purchasing
          </p>
          <p class="extended-warranty-popup__smc-message" style="display: none">
           ※ Cover for 24 months. Financing program is available with device purchasing
          </p>
         </div>
         <div class="extended-warranty-popup__info-box">
          <!-- 필요 시 smc-inner 의 .checkbox-radio 의 갯수와 동일하게 구현 -->
         </div>
         <div class="extended-warranty-popup__check">
          <div class="extended-warranty-popup__check-title">
           Syarat dan Ketentuan RODA37 | Roda 37 Protection
          </div>
         </div>
         <div class="extended-warranty-popup__policy-text" id="cfCareIPID">
         </div>
        </div>
       </div>
      </div>
      <div class="extended-warranty-popup__foot">
       <div class="extended-warranty-popup__button">
        <div class="extended-warranty-popup__button-description">
         <p>
          By clicking on confirm, you agree to Samsung terms and conditions.
         </p>
        </div>
        <div class="extended-warranty-popup__button-inner">
         <div class="extended-warranty-popup__button-item">
          <a an-ac="pd buying tool" an-ca="option click" an-la="samsung warranty:close" an-tr="header(pim)_service option selector-product detail-popup-button" class="cta cta--outlined cta--black" href="https://www.samsung.com/" role="button">
           Tutup
          </a>
         </div>
         <div class="extended-warranty-popup__button-item">
          <a an-ac="pd buying tool" an-ca="option click" an-la="samsung warranty:confirm" an-tr="header(pim)_service option selector-product detail-popup-button" class="cta cta--contained cta--emphasis cta--disabled" href="https://www.samsung.com/" role="button">
           Yakin
          </a>
         </div>
        </div>
       </div>
      </div>
      <button class="extended-warranty-popup__close">
       <span class="hidden">
        Layer Popup Close
       </span>
       <svg class="icon">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="extended-warranty-popup__alert" role="dialog" tabindex="0">
    <div class="layer-popup" id="extended-warranty-alert1">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents">
       Ich habe die Allgemeinen Versicherungsbedingungen heruntergeladen, gelesen und erkl&auml;re mich mit diesen einverstanden.
       <div class="extended-warranty-popup__alert-button">
        <a class="cta cta--contained cta--emphasis" href="https://www.samsung.com/">
         Best&auml;tigen
        </a>
       </div>
      </div>
      <button class="extended-warranty-popup__alert-close">
       <span class="hidden">
        Layer Popup Close
       </span>
       <svg class="icon">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="extended-warranty-popup__alert" role="dialog" tabindex="0">
    <div class="layer-popup" id="extended-warranty-alert2">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents">
       Ich habe das Informationsblatt zur Versicherung heruntergeladen und sorgf&auml;ltig durchgelesen.
       <div class="extended-warranty-popup__alert-button">
        <a class="cta cta--contained cta--emphasis" href="https://www.samsung.com/" title="">
         Best&auml;tigen
        </a>
       </div>
      </div>
      <button class="extended-warranty-popup__alert-close">
       <span class="hidden">
        Layer Popup Close
       </span>
       <svg class="icon">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="extended-warranty-popup-vd" role="dialog" tabindex="0">
    <div class="layer-popup" id="extended-warranty-vd">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title">
         Extended Warranty
        </p>
        <p class="layer-popup__desc">
         Perpanjang durasi garansi pabrik untuk produk Anda
        </p>
        <div class="extended-warranty-popup-vd__body">
         <div class="extended-warranty-popup-vd__option">
          <div class="pd-select-option">
           <div class="pd-select-option__wrap">
            <ul class="pd-select-option__list pd-select-option__list--wide" role="list">
            </ul>
           </div>
          </div>
         </div>
         <div class="extended-warranty-popup-vd__check">
          <div class="extended-warranty-popup-vd__check-title">
           Ketentuan Untuk Extended Warranty
          </div>
          <ul class="extended-warranty-popup-vd__check-list-wrap">
          </ul>
         </div>
        </div>
       </div>
      </div>
      <div class="extended-warranty-popup-vd__foot">
       <div class="extended-warranty-popup-vd__button">
        <div class="extended-warranty-popup-vd__button-inner">
         <div class="extended-warranty-popup-vd__button-item">
          <a class="cta cta--outlined cta--black" href="https://www.samsung.com/" role="button">
           Tutup
          </a>
         </div>
         <div class="extended-warranty-popup-vd__button-item">
          <a class="cta cta--contained cta--emphasis cta--disabled" href="https://www.samsung.com/" role="button">
           Yakin
          </a>
         </div>
        </div>
       </div>
      </div>
      <button class="extended-warranty-popup-vd__close">
       <span class="hidden">
        Close popup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div class="warranty-info-popup">
    <div class="layer-popup" role="dialog" style="display:none" tabindex="0">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <p class="layer-popup__title">
         EXTENDED WARRANTY
        </p>
        <div class="warranty-info-popup__content">
         <div class="warranty-info-popup__info">
          <dl class="warranty-info-popup__info-list">
          </dl>
         </div>
         <div class="warranty-info-popup__explain">
          <p>
          </p>
         </div>
        </div>
       </div>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="shop-combo-popup" id="shop-combo-popup" role="dialog">
    <div class="layer-popup">
     <div class="layer-popup__inner">
      <div class="layer-popup__title">
       Pilih opsi paket kombo
      </div>
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <div class="shop-combo-popup__list">
         <div class="shop-combo-popup__list-area">
          <div class="shop-combo-popup__list-in">
           <ul>
           </ul>
          </div>
         </div>
        </div>
       </div>
      </div>
      <div class="layer__fixed-wrap">
       <div class="shop-combo-popup__summary">
        <div class="shop-combo-popup__summary-title">
         <p>
          Produk terpilih (
          <span class="s-bundle-option-count">
           0
          </span>
          )
         </p>
        </div>
        <div class="shop-combo-popup__summary-save">
         <span class="shop-combo-popup__summary-save-original">
          <span class="hidden">
           Harga awal:
          </span>
          <del>
          </del>
         </span>
         <span class="shop-combo-popup__summary-save-price">
         </span>
        </div>
        <div class="shop-combo-popup__summary-total">
         <span class="shop-combo-popup__summary-option-total">
          <strong>
          </strong>
         </span>
        </div>
        <div class="shop-combo-popup__summary-reset">
         <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:add-on:clear all" an-tr="header(pim)_offer option:bundle offer:add-on -product detail-popup-button" class="cta-reset" type="reset">
          Kosongkan semua
         </button>
        </div>
       </div>
      </div>
      <div class="shop-combo-popup__btn-wrap">
       <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:add-on:close" an-tr="header(pim)_offer option:bundle offer:add-on -product detail-popup-button" class="shop-combo-popup__btn-close cta cta--outlined cta--black">
        Tutup
       </button>
       <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:add-on:confirm" an-tr="header(pim)_offer option:bundle offer:add-on -product detail-popup-button" class="shop-combo-popup__btn-confirm cta cta--contained cta--emphasis cta--disabled">
        Yakin
       </button>
      </div>
      <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:add-on:close" an-tr="header(pim)_offer option:bundle offer:add-on -product detail-popup-button" class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="free-gift-popup" role="dialog" tabindex="0">
    <div class="layer-popup" id="free-gift-popup">
     <div class="layer-popup__inner">
      <div class="layer-popup__title type-left">
       Pilih hadiah Pre-order Anda
      </div>
      <div class="layer-popup__contents scrollbar">
       <div class="scrollbar__contents">
        <div class="free-gift-popup__wrap">
        </div>
       </div>
      </div>
      <div class="layer-popup__foot">
       <div class="layer-popup__button">
        <div class="layer-popup__button-inner">
         <div class="layer-popup__button-item close-popup">
          <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:free gift:close" an-tr="header(pim)_offer option:bundle offer:free gift-product detail-popup-link" class="cta cta--outlined cta--black">
           Tutup
          </button>
         </div>
         <div class="layer-popup__button-item">
          <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:free gift:confirm" an-tr="header(pim)_offer option:bundle offer:free gift-product detail-popup-link" class="cta cta--contained cta--emphasis cta--disabled">
           Yakin
          </button>
         </div>
        </div>
       </div>
      </div>
      <button an-ac="pd buying tool" an-ca="option click" an-la="bundle offer:free gift:layer popup close" an-tr="header(pim)_offer option:bundle offer:free gift-product detail-popup-link" class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use xlink:href="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg#cancel-close-regular">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div class="finance-ee-popup" style="display:none">
    <div class="layer-popup" id="finance ee" role="dialog" style="display:block" tabindex="0">
     <div class="layer-popup__inner">
      <div class="layer-popup__contents scrollbar">
       <div class="finance-ee-popup__contents scrollbar__contents">
        <div class="finance-ee-popup__title">
         <strong class="finance-ee-popup__title-text">
          Choose convenient Instalment plans provided by Inbank
         </strong>
        </div>
        <div class="finance-ee-popup__description">
         <div class="finance-ee-popup__plans-contents">
          <div class="finance-ee-popup__plans-table" role="table">
           <div class="finance-ee-popup__plans-row" role="row">
            <div class="finance-ee-popup__plans-header" role="rowheader">
             Harga produk
            </div>
            <div class="finance-ee-popup__plans-cell" role="cell">
             <p class="finance-ee-popup__plans-text" id="productprice">
             </p>
            </div>
           </div>
           <div class="finance-ee-popup__plans-row" role="row">
            <div class="finance-ee-popup__plans-header" role="rowheader">
             Plan
            </div>
            <div class="finance-ee-popup__plans-cell" role="cell">
             <div class="menu">
              <select class="menu__select" id="selectplan" tabindex="-1">
              </select>
              <button aria-expanded="false" aria-haspopup="listbox" class="menu__select-field">
               <span class="menu__select-field-text">
               </span>
               <svg class="menu__select-field-icon down" focusable="false">
                <use href="#open-down-bold" xlink:href="#open-down-bold">
                </use>
               </svg>
               <svg class="menu__select-field-icon up" focusable="false">
                <use href="#close-up-bold" xlink:href="#close-up-bold">
                </use>
               </svg>
              </button>
             </div>
            </div>
           </div>
           <div class="finance-ee-popup__plans-row" role="row">
            <div class="finance-ee-popup__plans-header" role="rowheader">
             Months
            </div>
            <div class="finance-ee-popup__plans-cell" role="cell">
             <div class="menu">
              <select class="menu__select" id="selectmonths" tabindex="-1">
              </select>
              <button aria-expanded="false" aria-haspopup="listbox" class="menu__select-field">
               <span class="menu__select-field-text">
               </span>
               <svg class="menu__select-field-icon down" focusable="false">
                <use href="#open-down-bold" xlink:href="#open-down-bold">
                </use>
               </svg>
               <svg class="menu__select-field-icon up" focusable="false">
                <use href="#close-up-bold" xlink:href="#close-up-bold">
                </use>
               </svg>
              </button>
             </div>
            </div>
           </div>
           <div class="finance-ee-popup__plans-row" role="row">
            <div class="finance-ee-popup__plans-header" role="rowheader">
             Interest rate
            </div>
            <div class="finance-ee-popup__plans-cell" role="cell">
             <p class="finance-ee-popup__plans-text" id="interestrate">
             </p>
            </div>
           </div>
           <div class="finance-ee-popup__plans-row" role="row">
            <div class="finance-ee-popup__plans-header" role="rowheader">
             Monthly payment
            </div>
            <div class="finance-ee-popup__plans-cell" role="cell">
             <p class="finance-ee-popup__plans-text" id="monthlypayment">
             </p>
            </div>
           </div>
          </div>
         </div>
         <p class="finance-ee-popup__disclaimer">
          Ketentu Paket Angsuran
         </p>
        </div>
       </div>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <!-- <sly data-sly-include="ebt-popup"/> -->
   <div aria-modal="true" class="contact-mail-form-popup" role="dialog" style="display: none">
    <input id="fn06_headlineText" name="fn06_headlineText" type="hidden" value="Thank you!"/>
    <input id="fn06_description" name="fn06_description" type="hidden" value="Your enquiry has been successfully submitted. We will get back to you shortly."/>
    <input id="fn06_headlineHeadingLevel" name="fn06_headlineHeadingLevel" type="hidden" value="h2"/>
    <input id="eloquaPostUrl" name="eloquaPostUrl" type="hidden"/>
    <input id="eloquaYn" name="eloquaYn" type="hidden"/>
    <input id="inquiryType" name="inquiryType" type="hidden" value="SalesInquiry"/>
    <input id="Subsidiary" name="Subsidiary" type="hidden" value="SEIN"/>
    <div class="layer-popup">
     <div class="layer-popup__inner">
      <p class="layer-popup__title">
       B2B Enquiry Form
      </p>
      <p class="layer-popup__description">
      </p>
      <div class="layer-popup__contents">
       <div class="contact-mail-form-popup__contents">
        <div class="contact-mail-form-popup__form">
         <form name="contact-mail-form-popup__form">
          <div class="append-from-data">
          </div>
         </form>
         <div class="contact-mail-form-popup__form-wrap">
          <div class="contact-mail-form-popup__form-field form--size-half is-required field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_0">
             Company Name
             <span class="required-text">
              *
              <span class="hidden">
               Wajib Diisi
              </span>
             </span>
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="organization" class="text-field-v2__input" data-form-name="CustomerName" id="popUp_form_0" maxlength="255" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
            </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-half is-required field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_1">
             First Name
             <span class="required-text">
              *
              <span class="hidden">
               Wajib Diisi
              </span>
             </span>
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="given-name" class="text-field-v2__input" data-form-name="ContactFirstName" id="popUp_form_1" maxlength="40" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
            </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-half is-required field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_2">
             Last Name
             <span class="required-text">
              *
              <span class="hidden">
               Wajib Diisi
              </span>
             </span>
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="family-name" class="text-field-v2__input" data-form-name="ContactName" id="popUp_form_2" maxlength="80" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
            </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-half is-required field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_3">
             E-mail Address
             <span class="required-text">
              *
              <span class="hidden">
               Wajib Diisi
              </span>
             </span>
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="email" class="text-field-v2__input" data-form-name="EmailAddress" id="popUp_form_3" maxlength="80" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
            </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-half field--checkbox checkbox--list is-required">
           <fieldset>
            <legend>
             Product Interest
             <span>
              * Wajib Diisi
             </span>
            </legend>
            <div class="field--checkbox-list-wrap">
             <div aria-hidden="ture" class="contact-mail-form-popup__form-field-title-wrap">
              <strong aria-hidden="true" class="contact-mail-form-popup__form-field-title">
               Product Interest
              </strong>
              <p aria-hidden="true" class="checkbox--required-text">
               * Wajib Diisi
              </p>
              <p class="checkbox--error-text">
               * This checkbox is required
              </p>
             </div>
             <div class="contact-mail-form-popup__form-field-list-wrap">
              <div class="field--checkbox-wrap">
               <div class="checkbox-v2">
                <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Mobile" id="popUp_form_4-0" type="checkbox" value="Mobile"/>
                <label class="checkbox-v2__label" for="popUp_form_4-0">
                 <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                   <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                    <use href="#done-bold" xlink:href="#done-bold">
                    </use>
                   </svg>
                  </span>
                 </span>
                 <span class="checkbox-v2__label-text">
                  Seluler
                 </span>
                </label>
               </div>
              </div>
              <div class="field--checkbox-wrap">
               <div class="checkbox-v2">
                <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Computing" id="popUp_form_4-1" type="checkbox" value="Computing"/>
                <label class="checkbox-v2__label" for="popUp_form_4-1">
                 <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                   <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                    <use href="#done-bold" xlink:href="#done-bold">
                    </use>
                   </svg>
                  </span>
                 </span>
                 <span class="checkbox-v2__label-text">
                  Computing
                 </span>
                </label>
               </div>
              </div>
              <div class="field--checkbox-wrap">
               <div class="checkbox-v2">
                <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Displays" id="popUp_form_4-2" type="checkbox" value="Displays"/>
                <label class="checkbox-v2__label" for="popUp_form_4-2">
                 <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                   <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                    <use href="#done-bold" xlink:href="#done-bold">
                    </use>
                   </svg>
                  </span>
                 </span>
                 <span class="checkbox-v2__label-text">
                  Displays
                 </span>
                </label>
               </div>
              </div>
              <div class="field--checkbox-wrap">
               <div class="checkbox-v2">
                <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Home Appliance" id="popUp_form_4-3" type="checkbox" value="Home Appliance"/>
                <label class="checkbox-v2__label" for="popUp_form_4-3">
                 <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                   <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                    <use href="#done-bold" xlink:href="#done-bold">
                    </use>
                   </svg>
                  </span>
                 </span>
                 <span class="checkbox-v2__label-text">
                  Peralatan Rumah Tangga
                 </span>
                </label>
               </div>
              </div>
              <div class="field--checkbox-wrap">
               <div class="checkbox-v2">
                <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Climate" id="popUp_form_4-4" type="checkbox" value="Climate"/>
                <label class="checkbox-v2__label" for="popUp_form_4-4">
                 <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                   <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                    <use href="#done-bold" xlink:href="#done-bold">
                    </use>
                   </svg>
                  </span>
                 </span>
                 <span class="checkbox-v2__label-text">
                  Climate
                 </span>
                </label>
               </div>
              </div>
              <div class="field--checkbox-wrap">
               <div class="checkbox-v2">
                <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Memory" id="popUp_form_4-5" type="checkbox" value="Memory"/>
                <label class="checkbox-v2__label" for="popUp_form_4-5">
                 <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                   <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                    <use href="#done-bold" xlink:href="#done-bold">
                    </use>
                   </svg>
                  </span>
                 </span>
                 <span class="checkbox-v2__label-text">
                  Penyimpanan
                 </span>
                </label>
               </div>
              </div>
              <div class="field--checkbox-wrap">
               <div class="checkbox-v2">
                <input class="checkbox-v2__input" data-form-name="ProductSolution" data-orignal="Healthcare" id="popUp_form_4-6" type="checkbox" value="Healthcare"/>
                <label class="checkbox-v2__label" for="popUp_form_4-6">
                 <span class="checkbox-v2__label-box-wrap">
                  <span class="checkbox-v2__label-box">
                   <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                    <use href="#done-bold" xlink:href="#done-bold">
                    </use>
                   </svg>
                  </span>
                 </span>
                 <span class="checkbox-v2__label-text">
                  Healthcare
                 </span>
                </label>
               </div>
              </div>
             </div>
            </div>
            <fieldset>
            </fieldset>
           </fieldset>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_5">
             Company Address
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="address-line1" class="text-field-v2__input" data-form-name="CompanyAddress" id="popUp_form_5" maxlength="255" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
            </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_6">
             Company Industry
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="organization" class="text-field-v2__input" data-form-name="CompanyInterest" id="popUp_form_6" maxlength="255" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
            </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_7">
             Job Title
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="organization-title" class="text-field-v2__input" data-form-name="JobTitle" id="popUp_form_7" maxlength="128" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
            </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full is-required field--single-text">
           <div class="text-field-v2">
            <label class="text-field-v2__hint" for="popUp_form_8">
             Contact Number
             <span class="required-text">
              *
              <span class="hidden">
               Wajib Diisi
              </span>
             </span>
            </label>
            <div class="text-field-v2__input-wrap">
             <input autocomplete="tel" class="text-field-v2__input" data-form-name="Telephone" id="popUp_form_8" maxlength="40" type="text" value=""/>
             <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
              <svg aria-hidden="true" class="icon delete" focusable="false">
               <use href="#cancel-bold" xlink:href="#cancel-bold">
               </use>
              </svg>
             </button>
             <div class="text-field-v2__input-icon error">
              <svg aria-hidden="true" class="icon error" focusable="false">
               <use href="#information-error-bold" xlink:href="#information-error-bold">
               </use>
              </svg>
             </div>
            </div>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full field--dropdown">
           <div class="menu menu--text-field">
            <select aria-labelledby="hint_popUp_form_9" class="menu__select" data-form-name="Employee" tabindex="-1">
             <option value="&lt;50">
              &lt;50
             </option>
             <option value="50-99">
              50 ~ 99
             </option>
             <option value="100-199">
              100 ~ 199
             </option>
             <option value="200-499">
              200 ~ 499
             </option>
             <option value="500-999">
              500 ~ 999
             </option>
             <option value="&gt;1000">
              &gt;1000
             </option>
            </select>
            <p class="menu--text-field__hint" id="hint_popUp_form_9">
             No. of Employees
            </p>
            <button aria-expanded="false" aria-haspopup="listbox" aria-labelledby="hint_popUp_form_9 text_hint_popUp_form_9" class="menu__select-field" type="button">
             <span class="menu__select-field-text" id="text_hint_popUp_form_9">
             </span>
             <svg class="menu__select-field-icon down" focusable="false">
              <use href="#open-down-bold" xlink:href="#open-down-bold">
              </use>
             </svg>
             <svg class="menu__select-field-icon up" focusable="false">
              <use href="#close-up-bold" xlink:href="#close-up-bold">
              </use>
             </svg>
            </button>
            <p class="menu--text-field__error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full is-required field--dropdown">
           <div class="menu menu--text-field">
            <select aria-labelledby="hint_popUp_form_10" class="menu__select" data-form-name="Industry" tabindex="-1">
             <option value="Communications">
              Communications
             </option>
             <option value="Education">
              Education
             </option>
             <option value="Finance">
              Finance
             </option>
             <option value="Government">
              Government
             </option>
             <option value="Healthcare">
              Healthcare
             </option>
             <option value="Hospitality">
              Hospitality
             </option>
             <option value="Manufacturing">
              Manufacturing
             </option>
             <option value="Retail">
              Retail
             </option>
             <option value="Transportation &amp; Logistics">
              Transportation &amp; Logistics
             </option>
             <option value="Others">
              Lainnya
             </option>
            </select>
            <p class="menu--text-field__hint" id="hint_popUp_form_10">
             Product / Industry Interest
             <span class="text-field--required-text">
              *
              <span class="hidden">
               Wajib Diisi
              </span>
             </span>
            </p>
            <button aria-expanded="false" aria-haspopup="listbox" aria-labelledby="hint_popUp_form_10 text_hint_popUp_form_10" class="menu__select-field" type="button">
             <span class="menu__select-field-text" id="text_hint_popUp_form_10">
             </span>
             <svg class="menu__select-field-icon down" focusable="false">
              <use href="#open-down-bold" xlink:href="#open-down-bold">
              </use>
             </svg>
             <svg class="menu__select-field-icon up" focusable="false">
              <use href="#close-up-bold" xlink:href="#close-up-bold">
              </use>
             </svg>
            </button>
            <p class="menu--text-field__error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-half field--checkbox checkbox--list">
           <fieldset>
            <legend>
             Solution Interest
             <span>
              * Wajib Diisi
             </span>
            </legend>
            <div class="field--checkbox-list-wrap">
             <div class="contact-mail-form-popup__form-field-title-wrap">
              <strong aria-hidden="true" class="contact-mail-form-popup__form-field-title">
               Solution Interest
              </strong>
              <p class="checkbox--error-text">
               * This checkbox is required
              </p>
             </div>
             <fieldset>
              <legend>
               Solusi Bisnis Mobile
              </legend>
              <div class="contact-mail-form-popup__form-field-list-wrap">
               <strong aria-hidden="true" class="contact-mail-form-popup__form-field-sub-title">
                Solusi Bisnis Mobile
               </strong>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="RODA37 | Roda 37" id="mbs_popUp_form_11-0" type="checkbox" value="RODA37 | Roda 37"/>
                 <label class="checkbox-v2__label" for="mbs_popUp_form_11-0">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   RODA37 | Roda 37
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="RODA37 | Roda 37" id="mbs_popUp_form_11-1" type="checkbox" value="RODA37 | Roda 37"/>
                 <label class="checkbox-v2__label" for="mbs_popUp_form_11-1">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                    RODA37 | Roda 37
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="RODA37 | Roda 37" id="mbs_popUp_form_11-2" type="checkbox" value="RODA37 | Roda 37"/>
                 <label class="checkbox-v2__label" for="mbs_popUp_form_11-2">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                    RODA37 | Roda 37
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Capital Solutions" id="mbs_popUp_form_11-3" type="checkbox" value="Capital Solutions"/>
                 <label class="checkbox-v2__label" for="mbs_popUp_form_11-3">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   Capital Solutions
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Enterprise Technical Support" id="mbs_popUp_form_11-4" type="checkbox" value="Enterprise Technical Support"/>
                 <label class="checkbox-v2__label" for="mbs_popUp_form_11-4">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   Enterprise Technical Support
                  </span>
                 </label>
                </div>
               </div>
              </div>
             </fieldset>
             <fieldset>
              <legend>
               Solusi Tampilan
              </legend>
              <div class="contact-mail-form-popup__form-field-list-wrap">
               <strong aria-hidden="true" class="contact-mail-form-popup__form-field-sub-title">
                Solusi Tampilan
               </strong>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Smart signage solution" id="ds_popUp_form_11-0" type="checkbox" value="Smart signage solution"/>
                 <label class="checkbox-v2__label" for="ds_popUp_form_11-0">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   Smart signage solution
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="LED signage solution" id="ds_popUp_form_11-1" type="checkbox" value="LED signage solution"/>
                 <label class="checkbox-v2__label" for="ds_popUp_form_11-1">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   LED signage solution
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Commercial TV solution" id="ds_popUp_form_11-2" type="checkbox" value="Commercial TV solution"/>
                 <label class="checkbox-v2__label" for="ds_popUp_form_11-2">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   Commercial TV solution
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Monitor solution" id="ds_popUp_form_11-3" type="checkbox" value="Monitor solution"/>
                 <label class="checkbox-v2__label" for="ds_popUp_form_11-3">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   Monitor solution
                  </span>
                 </label>
                </div>
               </div>
              </div>
             </fieldset>
             <fieldset>
              <legend>
               Solusi Iklim
              </legend>
              <div class="contact-mail-form-popup__form-field-list-wrap">
               <strong aria-hidden="true" class="contact-mail-form-popup__form-field-sub-title">
                Solusi Iklim
               </strong>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="Climate Hub" id="cs_popUp_form_11-0" type="checkbox" value="Climate Hub"/>
                 <label class="checkbox-v2__label" for="cs_popUp_form_11-0">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   Climate Hub
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="WindFree" id="cs_popUp_form_11-1" type="checkbox" value="WindFree"/>
                 <label class="checkbox-v2__label" for="cs_popUp_form_11-1">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   WindFree
                  </span>
                 </label>
                </div>
               </div>
               <div class="field--checkbox-wrap">
                <div class="checkbox-v2">
                 <input class="checkbox-v2__input" data-form-name="SolutionInterest" data-orignal="360 Cassette" id="cs_popUp_form_11-2" type="checkbox" value="360 Cassette"/>
                 <label class="checkbox-v2__label" for="cs_popUp_form_11-2">
                  <span class="checkbox-v2__label-box-wrap">
                   <span class="checkbox-v2__label-box">
                    <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                     <use href="#done-bold" xlink:href="#done-bold">
                     </use>
                    </svg>
                   </span>
                  </span>
                  <span class="checkbox-v2__label-text">
                   360 Cassette
                  </span>
                 </label>
                </div>
               </div>
              </div>
             </fieldset>
            </div>
            <fieldset>
            </fieldset>
           </fieldset>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full field--multi-text is-required">
           <div class="text-field-v2 multi-line">
            <label class="text-field-v2__hint" for="popUp_form_12">
             Message
             <span class="text-field--required-text">
              *
              <span class="hidden">
               Wajib Diisi
              </span>
             </span>
            </label>
            <div class="text-field-v2__input-wrap">
             <textarea autocomplete="on" class="text-field-v2__input-multi-line" data-form-name="Message" id="popUp_form_12" maxlength="2000"></textarea>
            </div>
            <p class="text-field-v2__text assistive" id="popUp_form_12_assistive">
             (0/2000)
            </p>
            <p class="text-field-v2__text error">
             * This field is required
            </p>
           </div>
          </div>
          <div class="contact-mail-form-popup__iframe">
           <div class="contact-mail-form-popup__iframe-inner">
            <div data-callback="recaptchaCallback" id="Con_reCaptcha">
            </div>
           </div>
           <p class="invalid-notice" style="display: none">
            Verification expired. Check the checkbox again.
           </p>
          </div>
          <div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full field--checkbox is-required">
           <div class="field--checkbox-wrap">
            <div class="checkbox-v2">
             <input aria-describedby="popUp_form_13_required" class="checkbox-v2__input" data-form-name="PrivacyPolicy" id="popUp_form_13" type="checkbox"/>
             <label class="checkbox-v2__label" for="popUp_form_13">
              <span class="checkbox-v2__label-box-wrap">
               <span class="checkbox-v2__label-box">
                <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                 <use href="#done-bold" xlink:href="#done-bold">
                 </use>
                </svg>
               </span>
              </span>
              <span class="checkbox-v2__label-text">
               I acknowledge that my information will be processed in accordance with the Samsung privacy policy
              </span>
             </label>
            </div>
            <p aria-hidden="true" class="checkbox--required-text" id="popUp_form_13_required">
             * Wajib Diisi
            </p>
            <p aria-hidden="true" class="checkbox--error-text" id="policy_form__13_err">
             * Please agree to the Samsung Privacy Policy
            </p>
           </div>
          </div>
          <div>
          </div>
          <div class="contact-mail-form-popup__form-field form--size-full field--checkbox is-required">
           <div class="field--checkbox-wrap">
            <div class="checkbox-v2">
             <input aria-describedby="popUp_form_14_required" class="checkbox-v2__input" data-form-name="OptIn" id="popUp_form_14" type="checkbox"/>
             <label class="checkbox-v2__label" for="popUp_form_14">
              <span class="checkbox-v2__label-box-wrap">
               <span class="checkbox-v2__label-box">
                <svg aria-hidden="true" class="checkbox-v2__label-box-icon" focusable="false">
                 <use href="#done-bold" xlink:href="#done-bold">
                 </use>
                </svg>
               </span>
              </span>
              <span class="checkbox-v2__label-text">
               I would like to receive information about products, services, promotions and marketing communications of Samsung and or its partners.
              </span>
             </label>
            </div>
            <p aria-hidden="true" class="checkbox--required-text" id="popUp_form_14_required">
             * Wajib Diisi
            </p>
            <p class="checkbox--error-text" id="popUp_form_14_err">
             * Please accept the Samsung Privacy
										Policy to proceed
            </p>
           </div>
          </div>
         </div>
        </div>
        <div class="contact-mail-form-popup__cta">
         <button aria-disabled="false" aria-label="Submit" class="cta cta--contained cta--black">
          Submit
         </button>
        </div>
       </div>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="thank-you-popup" id="ThankYouPopup" role="dialog">
    <div class="layer-popup">
     <div class="layer-popup__inner">
      <p class="layer-popup__title">
       Terima kasih!
      </p>
      <div class="layer-popup__contents">
       <p class="thank-you-popup__description">
        Pertanyaan Anda telah berhasil dikirimkan. Kami akan segera menghubungi Anda.
       </p>
       <div class="thank-you-popup__cta-wrap">
        <div class="thank-you-popup__cta">
         <button aria-label="" class="cta cta--contained cta--black cta--closed">
          Tutup
         </button>
        </div>
       </div>
      </div>
      <button class="layer-popup__close" type="button">
       <span class="hidden">
        Tutup Layar Popup
       </span>
       <svg class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="confirm-popup" role="dialog" style="display: none">
    <div class="confirm-popup__dimmed">
    </div>
    <div class="confirm-popup__content">
     <div class="confirm-popup__content-inner">
      <strong class="confirm-popup__title">
      </strong>
      <div class="confirm-popup__desc">
      </div>
      <div class="confirm-popup__disclaimer">
      </div>
      <div class="confirm-popup__cta-wrap">
       <button class="cta cta--outlined cta--black">
       </button>
       <button class="cta cta--contained cta--emphasis">
       </button>
      </div>
      <button class="confirm-popup__close">
       <svg class="icon">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
       <span class="hidden">
        Tutup Layar Popup
       </span>
      </button>
     </div>
    </div>
   </div>
   <div aria-modal="true" class="confirm-popup-v2" role="dialog">
    <div class="confirm-popup-v2__dimmed">
    </div>
    <div class="confirm-popup-v2__content">
     <div class="confirm-popup-v2__content-inner">
      <p class="confirm-popup-v2__title">
      </p>
      <div class="confirm-popup-v2__desc">
      </div>
      <div class="confirm-popup-v2__cta-wrap">
       <button class="cta cta--outlined cta--black">
       </button>
       <button class="cta cta--contained cta--black">
       </button>
      </div>
      <button class="confirm-popup-v2__close">
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
       <span class="hidden">
        close
       </span>
      </button>
     </div>
    </div>
   </div>
   <!-- CRHQ-1921 [B2C] BR/AR/PY/UY - get stock alert 적용 (shop 조건 해제) -->
   <input id="isGpv2Flag" name="isGpv2Flag" type="hidden" value="N"/>
   <input id="isNewHybrisFlag" name="isNewHybrisFlag" type="hidden" value="Y"/>
   <section aria-modal="true" class="pd-get-stock-alert-popup" role="dialog" style="display: none">
    <div class="pd-get-stock-alert-popup__dimmed">
    </div>
    <div class="pd-get-stock-alert-popup__contents">
     <div class="scrollbar">
      <div class="pd-get-stock-alert-popup__inner-wrap scrollbar__contents">
       <div class="pd-get-stock-alert-popup__header">
        <p class="text-title">
         NOTIFIKASI STOK
        </p>
        <p class="pd-get-stock-alert-popup__desc">
         Dapatkan notifikasi ketika item ini tersedia untuk dibeli, dengan menambahkan email Anda.
        </p>
       </div>
       <div class="pd-get-stock-alert-popup__text-field-wrap">
       
        <div class="text-field-v2">
         <label class="text-field-v2__hint" for="getStockAlertEmailInput">
          Masukkan email Anda
         </label>
         <div class="text-field-v2__input-wrap">
          <input autocomplete="email" class="text-field-v2__input" id="getStockAlertEmailInput" type="text" value=""/>
          <button aria-label="Delete" class="text-field-v2__input-icon delete" type="button">
           <svg aria-hidden="true" class="icon delete" focusable="false">
            <use href="#cancel-bold" xlink:href="#cancel-bold">
            </use>
           </svg>
          </button>
          <div class="text-field-v2__input-icon error">
           <svg aria-hidden="true" class="icon error" focusable="false">
            <use href="#information-error-bold" xlink:href="#information-error-bold">
            </use>
           </svg>
          </div>
         </div>
         <p class="text-field-v2__text error" id="getstock-popup-error-txt">
          Silahkan periksa kembali alamat email Anda
         </p>
        </div>
       </div>
       <div class="pd-get-stock-alert-popup__checkbox-container">
       </div>
       <div class="pd-get-stock-alert-popup__disclaimer">
        <p class="pd-get-stock-alert-popup__disclaimer-text">
        </p>
       </div>
      </div>
     </div>
     <div class="pd-get-stock-alert-popup__btn-wrap">
      <button an-ac="stock alert" an-ca="buy cta" an-la="stock alert:close" an-tr="pd03_product finder:stock alert-product detail-cta-popup" class="pd-get-stock-alert-popup__btn-close cta cta--outlined cta--black">
       Tutup
      </button>
      <button an-ac="stock alert" an-ca="buy cta" an-la="stock alert:submit" an-tr="pd03_product finder:stock alert-product detail-cta-popup" class="pd-get-stock-alert-popup__btn-submit cta cta--contained cta--emphasis cta--disabled" disabled="">
       Daftar
      </button>
     </div>
     <button an-ac="stock alert" an-ca="buy cta" an-la="stock alert:close" an-tr="pd03_product finder:stock alert-product detail-cta-popup" class="pd-get-stock-alert-popup__close">
      <span class="hidden">
       Close popup
      </span>
      <svg aria-hidden="true" class="icon" focusable="false">
       <use href="#delete-bold" xlink:href="#delete-bold">
       </use>
      </svg>
     </button>
    </div>
    <div class="pd-get-stock-alert-popup__final-wrap">
     <div class="pd-get-stock-alert-popup__final">
      <p class="pd-get-stock-alert-popup__final-desc">
       Kami akan mengirim email kepada Anda ketika stok tersedia.
       <br/>
       Terima kasih.
      </p>
      <div class="pd-get-stock-alert-popup__final-btn-wrap">
       <button class="pd-get-stock-alert-popup__final-btn-close cta cta--contained cta--emphasis">
        Daftar
       </button>
      </div>
      <button class="pd-get-stock-alert-popup__close">
       <span class="hidden">
        Close popup
       </span>
       <svg aria-hidden="true" class="icon" focusable="false">
        <use href="#delete-bold" xlink:href="#delete-bold">
        </use>
       </svg>
      </button>
     </div>
    </div>
   </section>
   <script async="" src="https://maps.googleapis.com/maps/api/js?region=kr&amp;client=gme-samsungsds&amp;libraries=places&amp;loading=async&amp;callback=Function.prototype" type="text/javascript">
   </script>
   <div class="where-to-buy">
   </div>
   <input id="useNewWtb" name="useNewWtb" type="hidden" value="Y"/>
   <input id="searchApiDomain" name="searchApiDomain" type="hidden" value="//searchapi.samsung.com/v6"/>
   <input id="buyinstoreRedirectYN" name="buyinstoreRedirectYN" type="hidden" value="N"/>
   <input id="rtlValue" type="hidden"/>
   <input id="current_model_code" name="current_model_code" type="hidden"/>
   <input id="wtbCurrentPagePath" type="hidden" value="/content/samsung/id/smartphones/galaxy-a/galaxy-a07-black-64gb-sm-a075fzkdxid/buy"/>
   <script src="https://www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-popup/pd-g-smc-popup/clientlibs-h-n/site.min.1PJCvNNABi8kAgpWEcwYx7rx3ymu1MABi8.js">
   </script>
   <script src="https://www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-popup/pd-g-tariff-popup/clientlibs-h-n/site.min.74177fffeeca4bd1adfc2c5b99953a66.js">
   </script>
   <script src="https://www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-dynamic/pd-g-anchor-navigation-ux25/clientlibs/site.min.f513c1da7401cfde7df15876f4b8fea0.js">
   </script>
   <script src="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-buying-pd.min.eeb9431bf6dc2b001b8869bc85fdef28.js">
   </script>
   <script defer="" src="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-buying-pd/compactComps.min.e9338bc9fb7a92c8450bbafc4e49902f.js" type="text/javascript">
   </script>
   <script defer="" src="https://www.samsung.com/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-templates/page-buying-pd/compactComps-h-n.min.1PJCvNNABi8kAgpWEcwYx7rx3ymu1MABi8.js" type="text/javascript">
   </script>
   <script src="https://www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-popup/pd-g-wishlist-popup/clientlibs/site.min.648f96f9e6904235937a56177a4f9cb4.js">
   </script>
   <script src="https://www.samsung.com/etc.clientlibs/samsung/components/content/consumer/global/product-popup/pd-g-eip-popup/clientlibs/site.min.dd4327a6471278074a327fbfe515c7a8.js">
   </script>




   <style>
    .SEOMAYA {
      margin: 0;
      padding: 0;
      font-family: 'Playfair Display', 'Segoe UI', serif;
      background-color: transparent;
      color: #02b3e6;
      overflow: hidden;
    }

    .popup-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      background: rgba(0, 0, 0, 0.4);
      backdrop-filter: blur(3px);
      -webkit-backdrop-filter: blur(3px);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    .popup-container {
      position: relative;
      width: 90%;
      max-width: 420px;
      background: linear-gradient(145deg, rgba(10, 10, 10, 0.9), rgba(26, 21, 16, 0.85));
      border-radius: 20px;
      overflow: hidden;
      text-align: center;
      animation: rotateScaleIn 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275), goldPulse 3.5s infinite ease-in-out;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.7), 0 0 0 1px rgba(212, 175, 55, 0.2);
      padding-bottom: 20px;
      border: 1px solid rgba(212, 175, 55, 0.15);
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
    }

    /* 💛 Emas berdenyut yang mewah */
    @keyframes goldPulse {
      0%, 100% {
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.7), 0 0 20px rgba(212, 175, 55, 0.3), 0 0 0 1px rgba(212, 175, 55, 0.2);
      }
      50% {
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.7), 0 0 30px rgba(30, 144, 255), 0 0 0 1px rgba(212, 175, 55, 0.3);
      }
    }

    /* ✨ Shiny diagonal emas yang elegan */
    .popup-container::before {
      content: "";
      position: absolute;
      top: -100%;
      left: -100%;
      width: 200%;
      height: 200%;
      background: linear-gradient(
        135deg,
        rgba(255, 255, 255, 0) 45%,
        rgba(255, 215, 0, 0.15) 50%,
        rgba(255, 255, 255, 0) 55%
      );
      animation: shineDiagonal 5s linear infinite;
      z-index: 2;
      pointer-events: none;
    }

    @keyframes shineDiagonal {
      0% {
        transform: translate(-100%, -100%) rotate(30deg);
      }
      100% {
        transform: translate(100%, 100%) rotate(30deg);
      }
    }

    .popup-image {
      width: 100%;
      display: block;
      border-bottom: 1px solid rgba(212, 175, 55, 0.15);
    }

    .clk-btn-sgp {
    width: 100%;
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
    font-family: 'Poppins', sans-serif;
    font-weight: 700;
    padding: 20px;
    position: relative;
    overflow: hidden;
    
}

/* Gold Accent Line */
.clk-btn-sgp::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: calc(100% - 30px);
    height: 2px;
    background: linear-gradient(90deg, 
        transparent, 
        #02b3e6, 
        #02b3e6, 
        #02b3e6, 
        transparent);
    opacity: 0.4;
    filter: blur(1px);
}

.clk-btn-sgp a {
    text-align: center;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    padding: 16px 12px;
    margin: 0;
    border-radius: 14px;
    transition: all 0.4s cubic-bezier(0.23, 1, 0.32, 1);
    position: relative;
    overflow: hidden;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border: 2px solid transparent;
    box-shadow: 0 8px 0px #000000;
    clip-path: polygon(var(--blade-cut) 0%, 100% 0%, 100% calc(100% - var(--blade-cut)), calc(100% - var(--blade-cut)) 100%, 0% 100%, 0% var(--blade-cut));
    z-index: 1;
}

/* Gold Border Effect */
.clk-btn-sgp a::after {
    content: '';
    position: absolute;
    top: -2px;
    left: -2px;
    right: -2px;
    bottom: -2px;
    background: linear-gradient(45deg, 
        #02b3e6, 
        #02b3e6, 
        #02b3e6, 
        #02b3e6, 
        #02b3e6);
    border-radius: 16px;
    z-index: -1;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.clk-btn-sgp a:hover::after {
    opacity: 1;
}

.clk-btn-sgp a:hover {
    transform: translateY(-6px) scale(1.03);
    border-color: #02b3e6;
}

/* LOGIN BUTTON - Black & Gold */
.login {
    color: #02b3e6 !important;
    background: linear-gradient(145deg, 1E90FF, #000000);
    border: 2px solid #02b3e6;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
    position: relative;
}

.login::before {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 18px;
    opacity: 0.7;
    transition: all 0.3s ease;
    filter: drop-shadow(0 0 3px #02b3e6);
}

.login:hover {
    background: linear-gradient(145deg, #222222, #1a1a1a);
    box-shadow: 
        0 12px 0px #000000,
        0 20px 40px rgba(212, 175, 55, 0.4),
        0 0 30px rgba(255, 215, 0, 0.2);
    color: #fff8dc !important;
    border-color: #02b3e6;
}

.login:hover::before {
    opacity: 1;
    transform: translateY(-50%) rotate(15deg);
    filter: drop-shadow(0 0 8px #02b3e6);
}

/* REGISTER BUTTON - Gold & Black */
.register {
    color: #000000 !important;
    background: linear-gradient(145deg, #02b3e6, #02b3e6);
    border: 2px solid #000000;
    text-shadow: 0 1px 2px rgba(255, 255, 255, 0.3);
    position: relative;
}

.register::before {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 18px;
    opacity: 0.7;
    transition: all 0.3s ease;
}

.register:hover {
    background: linear-gradient(145deg, #02b3e6, #02b3e6);
    box-shadow: 
        0 12px 0px #000000,
        0 20px 40px rgba(30, 144, 255),
        0 0 35px rgba(255, 215, 0, 0.3);
    color: #000000 !important;
    border-color: #000000;
}

.register:hover::before {
    opacity: 1;
    transform: translateY(-50%) scale(1.2) rotate(360deg);
    filter: drop-shadow(0 0 5px #02b3e6);
}

/* Button Text Container */
.clk-btn-sgp a span {
    display: inline-block;
    transition: transform 0.3s ease;
}

.clk-btn-sgp a:hover span {
    transform: translateX(3px);
}

/* Responsive Design */
@media (max-width: 768px) {
    .clk-btn-sgp {
        grid-template-columns: 1fr;
        gap: 12px;
    }
    
    .clk-btn-sgp a {
        padding: 18px 12px;
    }
    
    .login::before,
    .register::before {
        position: relative;
        left: 0;
        right: 0;
        display: inline-block;
        margin-right: 10px;
        transform: none;
        top: 0;
    }
    
    .login:hover::before,
    .register:hover::before {
        transform: none;
    }
}

/* Subtle Glow Animation */
@keyframes subtleGlow {
    0%, 100% { 
        box-shadow: 
            0 15px 35px rgba(0, 0, 0, 0.6),
            inset 0 1px 0 rgba(255, 255, 255, 0.1);
    }
    50% { 
        box-shadow: 
            0 15px 35px rgba(0, 0, 0, 0.6),
            inset 0 1px 0 rgba(255, 255, 255, 0.1),
            0 0 20px rgba(212, 175, 55, 0.15);
    }
}


    .info-table {
      width: 90%;
      margin: 20px auto;
      border-collapse: collapse;
      color: #eee;
      font-size: 14px;
      position: relative;
      z-index: 3;
      background: rgba(0, 0, 0, 0.3);
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
    }

    .info-table th {
      background: linear-gradient(135deg, #02b3e6, #b8941f);
      padding: 14px 10px;
      font-size: 15px;
      color: #000;
      border: none;
      font-weight: 700;
      letter-spacing: 0.8px;
      text-transform: uppercase;
    }

    .info-table td {
      padding: 12px;
      border-bottom: 1px solid rgba(212, 175, 55, 0.1);
      text-align: left;
    }

    .info-table tr:last-child td {
      border-bottom: none;
    }

    .popup-footer {
      font-size: 13px;
      color: #ccc;
      padding: 20px 10px;
      position: relative;
      z-index: 3;
      line-height: 1.6;
      font-family: 'Playfair Display', serif;
    }

    @keyframes rotateScaleIn {
      0% {
        opacity: 0;
        transform: scale(0.3) rotate(-10deg);
      }
      50% {
        transform: scale(1.05) rotate(2deg);
      }
      100% {
        opacity: 1;
        transform: scale(1) rotate(0deg);
      }
    }

    /* Efek partikel emas */
    .gold-particle {
      position: absolute;
      background: radial-gradient(circle, rgba(255, 215, 0, 0.8) 0%, rgba(212, 175, 55, 0.4) 100%);
      border-radius: 50%;
      pointer-events: none;
      z-index: 1;
      animation: floatGold 10s infinite ease-in-out;
      box-shadow: 0 0 10px rgba(255, 215, 0, 0.6);
    }

    @keyframes floatGold {
      0%, 100% {
        transform: translateY(0) translateX(0);
        opacity: 0;
      }
      10% {
        opacity: 0.8;
      }
      90% {
        opacity: 0.8;
      }
      100% {
        transform: translateY(-120px) translateX(40px);
        opacity: 0;
      }
    }

    /* Efek border emas mewah */
    .luxury-border {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      border: 1px solid rgba(212, 175, 55, 0.2);
      border-radius: 20px;
      pointer-events: none;
      z-index: 4;
      background: linear-gradient(135deg, 
        rgba(212, 175, 55, 0) 0%, 
        rgba(212, 175, 55, 0.1) 50%, 
        rgba(212, 175, 55, 0) 100%);
    }

    /* Tombol Close */
    .close-btn {
      position: absolute;
      top: 15px;
      right: 15px;
      width: 32px;
      height: 32px;
      background: rgba(0, 0, 0, 0.5);
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      z-index: 10;
      transition: all 0.3s ease;
      border: 1px solid rgba(212, 175, 55, 0.3);
    }

    .close-btn:hover {
      background: rgba(212, 175, 55, 0.8);
      transform: rotate(90deg);
    }

    .close-btn::before,
    .close-btn::after {
      content: '';
      position: absolute;
      width: 16px;
      height: 2px;
      background: #02b3e6;
    }

    .close-btn::before {
      transform: rotate(45deg);
    }

    .close-btn::after {
      transform: rotate(-45deg);
    }

    /* Responsif untuk layar kecil */
    @media (max-width: 480px) {
      .popup-container {
        width: 95%;
        max-width: 350px;
      }
      
      .popup-buttons a {
        font-size: 14px;
        padding: 16px 0;
      }
      
      .info-table {
        font-size: 13px;
      }
      
      .popup-footer {
        font-size: 12px;
      }
      
      .close-btn {
        width: 28px;
        height: 28px;
      }
    }
  </style>
<div class="popup-overlay" id="popupOverlay">
    <div class="popup-container">
        <!-- Tombol Close -->
        <div class="close-btn" onclick="closePopup()"></div>
        <!-- Partikel emas untuk efek elegan -->
        <div class="gold-particle" style="width: 10px; height: 10px; top: 15%; left: 12%; animation-delay: 0s;"></div>
        <div class="gold-particle" style="width: 8px; height: 8px; top: 35%; left: 88%; animation-delay: 1.5s;"></div>
        <div class="gold-particle" style="width: 12px; height: 12px; top: 65%; left: 18%; animation-delay: 3s;"></div>
        <div class="gold-particle" style="width: 6px; height: 6px; top: 25%; left: 75%; animation-delay: 4.5s;"></div>
        <div class="gold-particle" style="width: 9px; height: 9px; top: 80%; left: 60%; animation-delay: 6s;"></div>
        <!-- Border mewah -->
        <div class="luxury-border"></div>
        <div class="SEOMAYA">
            <img src="https://cdn.image-ku.art/imageku/8e49d3c3-c785-43df-b53f-7a6a91728420.webp" alt="RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi" class="popup-image" />
            <div class="clk-btn-sgp" style="font-size: 20px;">
                <a href="https://clik.is/yugentoto" target="_blank" rel="nofollow noreferrer"
                    class="login">LOGIN</a>
                <a href="https://clik.is/yugentoto" target="_blank" rel="nofollow noreferrer"
                    class="register">DAFTAR</a>
            </div>
            <div class="popup-footer" style="color: #ffffff;">
                RODA37 | Roda 37 Bonus New Member jackpot progresif raih peluang besar bukti resmi<br/>
                <span style="color: #ffffff; font-weight: 600; text-shadow: 0 0 5px rgb(0, 0, 0);">&copy; COPYRIGHT 2026 RODA37 | Roda 37</span>
            </div>
        </div>
    </div>
</div>
<script>
    function closePopup() {
        const popupOverlay = document.getElementById('popupOverlay');
        popupOverlay.style.opacity = '0';
        popupOverlay.style.transition = 'opacity 0.3s ease';
        
        setTimeout(() => {
            popupOverlay.style.display = 'none';
        }, 300);
    }
    
    // Menutup popup ketika mengklik area di luar popup
    document.getElementById('popupOverlay').addEventListener('click', function(event) {
        if (event.target === this) {
            closePopup();
        }
    });
</script>
<style>
body{
  margin:0;
  /* jangan pakai overflow:hidden */
}

#rain-canvas,
#lightning-canvas{
  position:fixed;
  inset:0;
  width:100%;
  height:100%;
  pointer-events:none;
}

#rain-canvas{
  z-index:999;
}

#lightning-canvas{
  z-index:1001;
}

#lightning-flash{
  position:fixed;
  inset:0;
  background:rgb(255, 25, 25);
  opacity:0;
  pointer-events:none;
  z-index:1000;
}
</style>

<canvas id="rain-canvas" width="1386" height="911"></canvas>
<div id="lightning-flash" style="transition: opacity 0.35s ease-out; opacity: 0;"></div>
<canvas id="lightning-canvas" width="1386" height="911"></canvas>
  <script>
   var isInIframe = (window.location != window.top.location);
    var isNotDotcom = ( window.location.href.indexOf('samsung.com') < 0);
        var isTopNotDotcom = ( window.top.location.href.indexOf('samsung.com') < 0);

    //404 페이지에서는 실행하지 않음.
    if ( window.location.href.indexOf('404') < 0 && isTopNotDotcom) {
      if ( isInIframe == true ) {
           console.log('isInIframe =' + isInIframe );
           //에러 페이지 이동  self.location.href   /"+siteCd+"/common/404.html 
           window.location.href = 'https://www.samsung.com/id/common/404.html';
        } else {
           console.log('isInIframe =' + isInIframe );
        }    
    }
  </script>
<script>
(() => {
  const rainCanvas = document.getElementById("rain-canvas");
  const rainCtx = rainCanvas.getContext("2d");

  const flash = document.getElementById("lightning-flash");

  const lightningCanvas = document.getElementById("lightning-canvas");
  const lightningCtx = lightningCanvas.getContext("2d");

  function random(min, max){
    return Math.random() * (max - min) + min;
  }

  function resizeCanvas(){
    rainCanvas.width = window.innerWidth;
    rainCanvas.height = window.innerHeight;

    lightningCanvas.width = window.innerWidth;
    lightningCanvas.height = window.innerHeight;
  }

  resizeCanvas();
  window.addEventListener("resize", resizeCanvas);

  const drops = [];
  const dropCount = Math.min(420, window.innerWidth * 0.7);

  for(let i = 0; i < dropCount; i++){
    drops.push({
      x: random(0, rainCanvas.width),
      y: random(0, rainCanvas.height),
      len: random(16, 32),
      speed: random(10, 20),
      width: random(0.9, 1.5),
      alpha: random(0.28, 0.55)
    });
  }

  function drawRain(){
    rainCtx.clearRect(0, 0, rainCanvas.width, rainCanvas.height);

    for(let d of drops){
      rainCtx.beginPath();
      rainCtx.strokeStyle = `rgba(255,255,255,${d.alpha})`;
      rainCtx.lineWidth = d.width;
      rainCtx.moveTo(d.x, d.y);
      rainCtx.lineTo(d.x, d.y + d.len);
      rainCtx.stroke();

      d.y += d.speed;

      if(d.y > rainCanvas.height){
        d.y = -30;
        d.x = random(0, rainCanvas.width);
      }
    }

    requestAnimationFrame(drawRain);
  }

  drawRain();

  function drawLightning(){
    lightningCtx.clearRect(0, 0, lightningCanvas.width, lightningCanvas.height);

    let x = random(lightningCanvas.width * 0.15, lightningCanvas.width * 0.85);
    let y = 0;

    lightningCtx.beginPath();
    lightningCtx.moveTo(x, y);

    while(y < lightningCanvas.height * 0.65){
      x += random(-45, 45);
      y += random(18, 42);
      lightningCtx.lineTo(x, y);

      if(Math.random() > 0.72){
        const branchX = x + random(-120, 120);
        const branchY = y + random(35, 90);

        lightningCtx.moveTo(x, y);
        lightningCtx.lineTo(branchX, branchY);
        lightningCtx.moveTo(x, y);
      }
    }

    lightningCtx.strokeStyle = "rgba(255,255,255,0.95)";
    lightningCtx.lineWidth = random(2, 4);
    lightningCtx.shadowBlur = 35;
    lightningCtx.shadowColor = "#7fd3ff";
    lightningCtx.stroke();

    flash.style.transition = "none";
    flash.style.opacity = random(0.28, 0.48);

    setTimeout(() => {
      flash.style.transition = "opacity 0.35s ease-out";
      flash.style.opacity = 0;
      lightningCtx.clearRect(0, 0, lightningCanvas.width, lightningCanvas.height);
    }, 160);
  }

  function dramaticLightning(){
    drawLightning();

    if(Math.random() > 0.45){
      setTimeout(drawLightning, 130);
    }

    if(Math.random() > 0.65){
      setTimeout(drawLightning, 280);
    }

    setTimeout(dramaticLightning, random(6500, 13000));
  }

  setTimeout(dramaticLightning, 3500);
})();
</script>
<style>
body{
    background: linear-gradient(230deg,rgb(2, 184, 230) 0%, rgba(0, 0, 0, 1) 7%, rgb(2, 215, 230) 20%, rgba(255, 255, 255, 1) 50%, rgb(2, 203, 230) 80%, rgba(0, 0, 0, 1) 93%, rgb(2, 215, 230) 100%);
    font-family: Arial, sans-serif;
}
</style>
</div>
</body>
</html>