<?php
/*
 * FILE MANAGER ULTIMATE
 * Root dibatasi ke: /home/host1748896/montag-opor.ru
 * Memerlukan PHP 7.4+; fitur ZIP memerlukan ekstensi ZipArchive.
 * Upload ke htdocs/www/filemanager.php
 */

session_start();
error_reporting(0);
ini_set('display_errors', '0');

/* ===== KONFIGURASI WAJIB DIUBAH ===== */
$PASSWORD = '000';
$ROOT_INPUT = '/var/lib/wordpress/tetradesign/';
$MAX_EDIT = 2 * 1024 * 1024; // Maksimum editor 2 MB
$MAX_SEARCH = 2000;
/* ==================================== */

$ROOT = realpath($ROOT_INPUT);
if (!$ROOT || !is_dir($ROOT)) {
    http_response_code(500);
    exit('Root domain tidak ditemukan. Periksa ROOT_INPUT.');
}

function fm_h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}
function fm_token() {
    if (function_exists('random_bytes')) {
        try { return bin2hex(random_bytes(32)); } catch (Exception $e) {}
    }
    return hash('sha256', uniqid((string)mt_rand(), true));
}
if (empty($_SESSION['fm_token'])) $_SESSION['fm_token'] = fm_token();

function fm_inside($path) {
    global $ROOT;
    return $path === $ROOT || strpos($path, $ROOT . DIRECTORY_SEPARATOR) === 0;
}
function fm_valid_name($name) {
    return $name !== '' && $name !== '.' && $name !== '..' &&
        strpos($name, '/') === false && strpos($name, '\\') === false &&
        strpos($name, "\0") === false;
}
/* Path relatif saja; menolak traversal dan symlink. Mendukung parent yang belum ada. */
function fm_path($relative) {
    global $ROOT;
    $relative = str_replace('\\', '/', (string)$relative);
    if (strpos($relative, "\0") !== false || substr($relative, 0, 1) === '/') return false;
    $parts = explode('/', $relative);
    $path = $ROOT;
    $missing = false;
    foreach ($parts as $part) {
        if ($part === '' || $part === '.') continue;
        if ($part === '..') return false;
        $path .= DIRECTORY_SEPARATOR . $part;
        if (!$missing && file_exists($path)) {
            if (is_link($path)) return false;
            $real = realpath($path);
            if ($real === false || !fm_inside($real)) return false;
            $path = $real;
        } else {
            $missing = true;
        }
    }
    if (file_exists($path)) {
        if (is_link($path)) return false;
        $real = realpath($path);
        return ($real !== false && fm_inside($real)) ? $real : false;
    }
    $ancestor = dirname($path);
    while (!is_dir($ancestor)) {
        $next = dirname($ancestor);
        if ($next === $ancestor) return false;
        $ancestor = $next;
    }
    $realParent = realpath($ancestor);
    if ($realParent === false || !fm_inside($realParent)) return false;
    return $path;
}
function fm_rel($path) {
    global $ROOT;
    if ($path === $ROOT) return '';
    return str_replace(DIRECTORY_SEPARATOR, '/', substr($path, strlen($ROOT) + 1));
}
function fm_check_csrf() {
    if (!isset($_POST['csrf']) || !hash_equals($_SESSION['fm_token'], $_POST['csrf'])) {
        http_response_code(403);
        exit('Token keamanan tidak valid.');
    }
}
function fm_delete($path) {
    if (is_link($path)) return false;
    if (is_file($path)) return @unlink($path);
    if (!is_dir($path)) return false;
    $items = @scandir($path);
    if ($items === false) return false;
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $child = $path . DIRECTORY_SEPARATOR . $item;
        if (is_link($child) || !fm_delete($child)) return false;
    }
    return @rmdir($path);
}
function fm_copy($src, $dst) {
    if (is_link($src) || file_exists($dst)) return false;
    if (is_file($src)) return @copy($src, $dst);
    if (!is_dir($src)) return false;
    if (!@mkdir($dst, 0755)) return false;
    $items = @scandir($src);
    if ($items === false) return false;
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $a = $src . DIRECTORY_SEPARATOR . $item;
        $b = $dst . DIRECTORY_SEPARATOR . $item;
        if (is_link($a) || !fm_copy($a, $b)) {
            fm_delete($dst);
            return false;
        }
    }
    return true;
}
function fm_size($size) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    $i = 0;
    while ($size >= 1024 && $i < 4) { $size /= 1024; $i++; }
    return round($size, 2) . ' ' . $units[$i];
}
function fm_flash($message) { $_SESSION['fm_message'] = $message; }
function fm_redirect($dir) {
    $base = strtok($_SERVER['REQUEST_URI'], '?');
    header('Location: ' . $base . '?dir=' . urlencode($dir));
    exit;
}

/* ===== LOGOUT DAN LOGIN ===== */
if (isset($_GET['logout'])) {
    $_SESSION = array();
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
    header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
    exit;
}
$loginError = '';
if (isset($_POST['login'])) {
    if (hash_equals($PASSWORD, isset($_POST['password']) ? (string)$_POST['password'] : '')) {
        session_regenerate_id(true);
        $_SESSION['fm_auth'] = true;
        $_SESSION['fm_token'] = fm_token();
        header('Location: ' . strtok($_SERVER['REQUEST_URI'], '?'));
        exit;
    }
    $loginError = 'Password salah.';
}
if (empty($_SESSION['fm_auth'])) {
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>File Manager Login</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b1020;color:#e7ebf5;font:14px Arial;padding:20px}.login{width:100%;max-width:370px;padding:28px;background:#151f32;border:1px solid #303c55;border-radius:16px}h2{color:#9eafff}input,button{width:100%;padding:13px;margin-top:12px;border-radius:8px}input{background:#0c1426;border:1px solid #36435c;color:#fff}button{background:#6379ff;color:white;border:0;font-weight:bold}.err{color:#ff9999}
</style></head><body><div class="login"><h2>FILE MANAGER ULTIMATE</h2><p>Secure Hosting Access</p><form method="post"><input type="password" name="password" placeholder="Password akses" required><button name="login" value="1">LOGIN</button></form><p class="err"><?php echo fm_h($loginError); ?></p></div></body></html>
<?php
exit;
}

/* ===== DIREKTORI AKTIF ===== */
$dir = isset($_REQUEST['dir']) ? trim((string)$_REQUEST['dir']) : '';
$current = fm_path($dir);
if ($current === false || !is_dir($current)) { $dir = ''; $current = $ROOT; }
$message = '';

/* ===== OPERASI FILE ===== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    fm_check_csrf();
    $action = $_POST['action'];
    $name = isset($_POST['name']) ? trim((string)$_POST['name']) : '';
    $target = fm_path(($dir !== '' ? $dir . '/' : '') . $name);
    $notice = 'Operasi tidak dikenali.';

    if ($action === 'mkdir') {
        if (fm_valid_name($name) && $target !== false && !file_exists($target))
            $notice = @mkdir($target, 0755) ? 'Folder berhasil dibuat.' : 'Gagal membuat folder.';
        else $notice = 'Nama folder tidak valid atau sudah ada.';
    } elseif ($action === 'newfile') {
        if (fm_valid_name($name) && $target !== false && !file_exists($target))
            $notice = @file_put_contents($target, '') !== false ? 'File berhasil dibuat.' : 'Gagal membuat file.';
        else $notice = 'Nama file tidak valid atau sudah ada.';
    } elseif ($action === 'upload' && isset($_FILES['upload'])) {
        $ok = 0; $bad = 0; $f = $_FILES['upload'];
        if (is_array($f['name'])) {
            for ($i = 0; $i < count($f['name']); $i++) {
                $original = basename($f['name'][$i]);
                $dest = fm_path(($dir !== '' ? $dir . '/' : '') . $original);
                if ($f['error'][$i] === UPLOAD_ERR_OK && fm_valid_name($original) &&
                    $dest !== false && !file_exists($dest) &&
                    @move_uploaded_file($f['tmp_name'][$i], $dest)) $ok++;
                else $bad++;
            }
        }
        $notice = 'Upload berhasil: ' . $ok . ', gagal: ' . $bad . '.';
    } elseif ($action === 'save') {
        $file = isset($_POST['file']) ? (string)$_POST['file'] : '';
        $dest = fm_path($file);
        if ($dest !== false && is_file($dest) && is_writable($dest) &&
            filesize($dest) <= $MAX_EDIT && isset($_POST['content']) &&
            strlen($_POST['content']) <= $MAX_EDIT) {
            $notice = @file_put_contents($dest, $_POST['content'], LOCK_EX) !== false ?
                'File berhasil disimpan.' : 'Gagal menyimpan file.';
        } else $notice = 'File tidak bisa diedit, tidak writable, atau melebihi batas 2 MB.';
    } elseif ($action === 'delete') {
        if ($target !== false && $target !== $ROOT && file_exists($target))
            $notice = fm_delete($target) ? 'Item berhasil dihapus.' : 'Gagal menghapus item.';
        else $notice = 'Target tidak valid.';
    } elseif ($action === 'bulk_delete') {
        $selected = isset($_POST['selected']) && is_array($_POST['selected']) ? $_POST['selected'] : array();
        $deleted = 0; $failed = 0;
        foreach (array_unique($selected) as $selectedName) {
            $selectedName = (string)$selectedName;
            if (!fm_valid_name($selectedName)) { $failed++; continue; }
            $itemPath = fm_path(($dir !== '' ? $dir . '/' : '') . $selectedName);
            if ($itemPath === false || $itemPath === $ROOT || !file_exists($itemPath)) { $failed++; continue; }
            if (fm_delete($itemPath)) $deleted++; else $failed++;
        }
        $notice = 'Hapus massal selesai. Berhasil: ' . $deleted . ', gagal: ' . $failed . '.';
    } elseif ($action === 'bulk_zip') {
        $selected = isset($_POST['selected']) && is_array($_POST['selected']) ? $_POST['selected'] : array();
        $zipName = isset($_POST['zipname']) ? trim((string)$_POST['zipname']) : '';
        $zipPath = fm_path(($dir !== '' ? $dir . '/' : '') . $zipName);
        if (!class_exists('ZipArchive')) {
            $notice = 'Ekstensi ZipArchive tidak aktif di server.';
        } elseif (!$selected || !fm_valid_name($zipName) || strtolower(substr($zipName, -4)) !== '.zip' || $zipPath === false || file_exists($zipPath)) {
            $notice = 'Pilih item dan gunakan nama ZIP baru yang valid.';
        } else {
            $zip = new ZipArchive();
            if ($zip->open($zipPath, ZipArchive::CREATE) === true) {
                $added = 0; $skipped = 0;
                foreach (array_unique($selected) as $selectedName) {
                    $selectedName = (string)$selectedName;
                    if (!fm_valid_name($selectedName)) { $skipped++; continue; }
                    $source = fm_path(($dir !== '' ? $dir . '/' : '') . $selectedName);
                    if ($source === false || !file_exists($source) || is_link($source) || $source === $zipPath) { $skipped++; continue; }
                    $archiveBase = basename($source);
                    if (is_file($source)) {
                        if ($zip->addFile($source, $archiveBase)) $added++; else $skipped++;
                    } elseif (is_dir($source)) {
                        $zip->addEmptyDir($archiveBase);
                        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
                        foreach ($it as $info) {
                            $entryPath = $info->getPathname();
                            if (is_link($entryPath)) { $skipped++; continue; }
                            $inside = str_replace(DIRECTORY_SEPARATOR, '/', substr($entryPath, strlen($source) + 1));
                            $archiveEntry = $archiveBase . '/' . $inside;
                            if ($info->isDir()) $zip->addEmptyDir($archiveEntry);
                            elseif ($info->isFile() && $zip->addFile($entryPath, $archiveEntry)) $added++;
                            else $skipped++;
                        }
                    }
                }
                $zip->close();
                if ($added === 0 && $skipped > 0) @unlink($zipPath);
                $notice = 'ZIP pilihan selesai. File ditambahkan: ' . $added . ', dilewati: ' . $skipped . '.';
            } else $notice = 'Gagal membuat arsip ZIP.';
        }
    } elseif ($action === 'rename') {
        $newname = isset($_POST['newname']) ? trim((string)$_POST['newname']) : '';
        $dest = fm_path(($dir !== '' ? $dir . '/' : '') . $newname);
        if ($target !== false && file_exists($target) && $target !== $ROOT &&
            fm_valid_name($newname) && $dest !== false && !file_exists($dest))
            $notice = @rename($target, $dest) ? 'Rename berhasil.' : 'Rename gagal.';
        else $notice = 'Nama baru tidak valid atau sudah ada.';
    } elseif ($action === 'chmod') {
        $perm = isset($_POST['permission']) ? (string)$_POST['permission'] : '';
        if ($target !== false && file_exists($target) && $target !== $ROOT &&
            preg_match('/^[0-7]{3,4}$/', $perm))
            $notice = @chmod($target, octdec($perm)) ? 'Permission berhasil diubah.' : 'Gagal mengubah permission.';
        else $notice = 'Permission atau target tidak valid.';
    } elseif ($action === 'clipboard') {
        $mode = isset($_POST['mode']) ? $_POST['mode'] : '';
        if ($target !== false && file_exists($target) && $target !== $ROOT &&
            in_array($mode, array('copy', 'cut'), true)) {
            $_SESSION['fm_clip'] = array('path' => fm_rel($target), 'mode' => $mode);
            $notice = 'Item masuk clipboard: ' . $mode . '.';
        } else $notice = 'Item tidak valid.';
    } elseif ($action === 'paste' && !empty($_SESSION['fm_clip'])) {
        $clip = $_SESSION['fm_clip'];
        $src = fm_path($clip['path']);
        $dst = fm_path(($dir !== '' ? $dir . '/' : '') . basename($clip['path']));
        if ($src !== false && $dst !== false && file_exists($src) && !file_exists($dst) &&
            $src !== $current && strpos($current . DIRECTORY_SEPARATOR, $src . DIRECTORY_SEPARATOR) !== 0) {
            $done = ($clip['mode'] === 'cut') ? @rename($src, $dst) : fm_copy($src, $dst);
            $notice = $done ? 'Paste berhasil.' : 'Paste gagal.';
            if ($done) unset($_SESSION['fm_clip']);
        } else $notice = 'Tujuan tidak valid, item sudah ada, atau folder tujuan berada di dalam sumber.';
    } elseif ($action === 'clearclip') {
        unset($_SESSION['fm_clip']); $notice = 'Clipboard dikosongkan.';
    } elseif ($action === 'zip') {
        $zipName = isset($_POST['zipname']) ? trim((string)$_POST['zipname']) : '';
        $zipPath = fm_path(($dir !== '' ? $dir . '/' : '') . $zipName);
        if (class_exists('ZipArchive') && fm_valid_name($zipName) &&
            strtolower(substr($zipName, -4)) === '.zip' && $zipPath !== false && !file_exists($zipPath)) {
            $zip = new ZipArchive();
            if ($zip->open($zipPath, ZipArchive::CREATE) === true) {
                $it = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($current, FilesystemIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::SELF_FIRST
                );
                foreach ($it as $info) {
                    $p = $info->getPathname();
                    if (is_link($p) || $p === $zipPath) continue;
                    $rel = str_replace(DIRECTORY_SEPARATOR, '/', substr($p, strlen($current) + 1));
                    if ($info->isDir()) $zip->addEmptyDir($rel);
                    elseif ($info->isFile()) $zip->addFile($p, $rel);
                }
                $zip->close();
                $notice = 'ZIP berhasil dibuat dari isi folder aktif.';
            } else $notice = 'Gagal membuka ZIP untuk ditulis.';
        } else $notice = 'ZipArchive tidak aktif, nama ZIP salah, atau file sudah ada.';
    } elseif ($action === 'unzip') {
        if ($target !== false && is_file($target) && strtolower(substr($target, -4)) === '.zip' && class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            if ($zip->open($target) === true) {
                $ok = 0; $bad = 0;
                for ($i = 0; $i < $zip->numFiles; $i++) {
                    $entry = str_replace('\\', '/', $zip->getNameIndex($i));
                    if ($entry === '' || substr($entry, 0, 1) === '/' || strpos($entry, "\0") !== false) { $bad++; continue; }
                    $parts = explode('/', $entry); $invalid = false;
                    foreach ($parts as $part) if ($part === '..') $invalid = true;
                    if ($invalid) { $bad++; continue; }
                    $dest = fm_path(($dir !== '' ? $dir . '/' : '') . $entry);
                    if ($dest === false) { $bad++; continue; }
                    if (substr($entry, -1) === '/') {
                        if (is_dir($dest) || @mkdir($dest, 0755, true)) $ok++; else $bad++;
                        continue;
                    }
                    $parent = dirname($dest);
                    if (!is_dir($parent) && !@mkdir($parent, 0755, true)) { $bad++; continue; }
                    if (file_exists($dest)) { $bad++; continue; }
                    $in = $zip->getStream($zip->getNameIndex($i));
                    if (!$in) { $bad++; continue; }
                    $out = @fopen($dest, 'xb');
                    if (!$out) { fclose($in); $bad++; continue; }
                    $copied = stream_copy_to_stream($in, $out);
                    fclose($in); fclose($out);
                    if ($copied === false) { @unlink($dest); $bad++; } else $ok++;
                }
                $zip->close();
                $notice = 'Extract selesai. Berhasil: ' . $ok . ', gagal/dilewati: ' . $bad . '.';
            } else $notice = 'Arsip ZIP tidak bisa dibuka.';
        } else $notice = 'ZIP tidak valid atau ekstensi ZipArchive tidak aktif.';
    }

    fm_flash($notice);
    fm_redirect($dir);
}

/* ===== DOWNLOAD ===== */
if (isset($_GET['download'])) {
    $file = fm_path((string)$_GET['download']);
    if ($file !== false && is_file($file) && is_readable($file)) {
        while (ob_get_level()) ob_end_clean();
        header('Content-Type: application/octet-stream');
        header('X-Content-Type-Options: nosniff');
        header('Content-Length: ' . filesize($file));
        header('Content-Disposition: attachment; filename="' . str_replace('"', '', basename($file)) . '"');
        readfile($file);
        exit;
    }
}

/* ===== EDITOR ===== */
$editor = null;
if (isset($_GET['edit'])) {
    $file = fm_path((string)$_GET['edit']);
    if ($file !== false && is_file($file) && is_readable($file) && filesize($file) <= $MAX_EDIT) {
        $content = file_get_contents($file);
        if (strpos($content, "\0") === false) {
            $editor = array('path' => fm_rel($file), 'name' => basename($file), 'content' => $content);
        }
    }
}

/* ===== PENCARIAN ===== */
$query = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
$searchResults = array();
if ($query !== '' && strlen($query) <= 200) {
    try {
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($current, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($it as $info) {
            $p = $info->getPathname();
            if (is_link($p)) continue;
            if (stripos($info->getFilename(), $query) !== false) {
                $searchResults[] = array('name' => $info->getFilename(), 'path' => fm_rel($p), 'dir' => $info->isDir());
                if (count($searchResults) >= $MAX_SEARCH) break;
            }
        }
    } catch (Exception $e) {}
}

/* ===== LIST FOLDER ===== */
$folders = array(); $files = array();
$items = @scandir($current);
if ($items !== false) {
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $p = $current . DIRECTORY_SEPARATOR . $item;
        if (is_link($p)) continue;
        if (is_dir($p)) $folders[] = $item; else $files[] = $item;
    }
}
natcasesort($folders); natcasesort($files);
$parentDir = dirname($dir);
if ($parentDir === '.') $parentDir = '';
$message = isset($_SESSION['fm_message']) ? $_SESSION['fm_message'] : '';
unset($_SESSION['fm_message']);
$baseUrl = strtok($_SERVER['REQUEST_URI'], '?');
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>File Manager Ultimate</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#0b1020;color:#e7ebf5;font:14px Arial,sans-serif}a{color:#a5b6ff;text-decoration:none}button,.btn{cursor:pointer;background:#6379ff;color:#fff;border:0;border-radius:7px;padding:9px 11px;display:inline-block;font-size:11px}button.gray,.btn.gray{background:#394760}button.red,.btn.red{background:#b84658}button.green,.btn.green{background:#168c70}.top{position:sticky;top:0;z-index:3;background:#151f34;border-bottom:1px solid #303c55;padding:15px 18px;display:flex;justify-content:space-between;align-items:center}.logo{font-weight:bold;color:#a1b1ff;font-size:17px}.logout{color:#ff9999}.wrap{max-width:1250px;margin:auto;padding:16px}.card{background:#151f32;border:1px solid #28354e;border-radius:12px;padding:15px;margin-bottom:14px}.path{line-height:2;overflow-wrap:anywhere;color:#9baac6}.muted{font-size:11px;color:#8795af}.stats{display:flex;gap:16px;flex-wrap:wrap;color:#aab6ce;font-size:12px;margin-top:12px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.tool{background:#101a2e;padding:12px;border-radius:9px}.tool h4{margin:0 0 8px;color:#b2c0ff}input,textarea{width:100%;background:#0c1426;border:1px solid #36435c;color:#fff;border-radius:7px;padding:10px;margin:4px 0}.tool button{margin-top:5px}.rowitem{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:12px 4px;border-bottom:1px solid #28354b}.rowitem:last-child{border:0}.iname{min-width:0;flex:1;overflow-wrap:anywhere}.iname strong{display:block;margin-bottom:5px}.actions{display:flex;flex-wrap:wrap;gap:5px;align-items:center}.actions form{display:inline-flex;gap:3px;align-items:center}.actions input{width:85px;padding:7px;font-size:11px}.actions button,.actions a{padding:7px 8px;font-size:10px}.msg{padding:12px;background:#12382e;color:#8af0c2;border-radius:8px;margin-bottom:12px}.search{display:flex;gap:6px}.search input{flex:1}.editor{min-height:420px;font:13px/1.6 monospace;white-space:pre;tab-size:4}.empty{text-align:center;padding:25px;color:#8290a8}.footer{font-size:11px;color:#8290a8}/* Tampilan ringkas ala cPanel */
.quickbar{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
.quick{display:flex;align-items:center;gap:9px;min-width:0;padding:10px;background:#101a2e;border:1px solid #293751;border-radius:8px}
.quick .qicon{font-size:18px;width:24px;text-align:center}.quick .qbody{min-width:0;flex:1}
.quick h4{font-size:12px;margin:0 0 5px;color:#dbe3f5;font-weight:600}
.quick form{display:flex;align-items:center;gap:5px}.quick input:not([type=file]){min-width:0;margin:0;padding:7px 8px;font-size:11px}
.quick input[type=file]{min-width:0;width:100%;font-size:10px}.quick button{white-space:nowrap;padding:7px 9px;font-size:10px;margin:0}
.quick .muted{margin-top:4px}.quick-heading{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:12px}.quick-heading button{padding:7px 10px;font-size:10px}.quick-content.is-collapsed{display:none}.listhead{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px}.bulk-tools{display:flex;align-items:center;gap:7px;flex-wrap:wrap}.bulk-tools form{display:flex;align-items:center;gap:5px;margin:0}.bulk-tools input{width:125px;margin:0;padding:8px;font-size:11px}.bulk-tools button{padding:8px 10px}
.listhead h3{margin:0}.bulkbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.bulkbar button{padding:8px 11px}
.rowitem{display:grid;grid-template-columns:22px minmax(180px,1fr) auto;align-items:center;gap:10px;padding:10px 2px}
.pick{width:16px;height:16px;accent-color:#6379ff}.iname strong{font-size:13px}.actions{justify-content:flex-end}.actions form{margin:0}
@media(max-width:850px){.quickbar{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:650px){.wrap{padding:10px}.grid{grid-template-columns:1fr}.quickbar{grid-template-columns:1fr}.rowitem{display:flex;align-items:flex-start;flex-direction:column}.rowitem .pick{align-self:flex-start}.actions{width:100%;justify-content:flex-start}.top{padding:13px}.editor{min-height:330px}.listhead{align-items:flex-start;flex-direction:column}}
</style>
</head>
<body>
<div class="top"><div class="logo">◈ FILE MANAGER ULTIMATE</div><a class="logout" href="?logout=1">LOGOUT ↗</a></div>
<div class="wrap">

<div class="card">
<strong>ROOT DOMAIN</strong>
<div class="path"><a href="<?php echo fm_h($baseUrl); ?>">🏠 ROOT</a>
<?php
$crumb = '';
$parts = $dir !== '' ? explode('/', $dir) : array();
foreach ($parts as $part) {
    $crumb .= ($crumb !== '' ? '/' : '') . $part;
    echo ' / <a href="?dir=' . urlencode($crumb) . '">' . fm_h($part) . '</a>';
}
?>
</div>
<div class="muted"><?php echo fm_h($current); ?></div>
<div class="stats"><span>📁 <?php echo count($folders); ?> Folder</span><span>📄 <?php echo count($files); ?> File</span><span>PHP <?php echo fm_h(PHP_VERSION); ?></span><span><?php echo class_exists('ZipArchive') ? 'ZIP ENABLED' : 'ZIP DISABLED'; ?></span></div>
</div>

<?php if ($message !== ''): ?><div class="msg"><?php echo fm_h($message); ?></div><?php endif; ?>

<div class="card quick-card"><div class="quick-heading"><h3 style="margin:0">⚡ Quick Operations</h3><button type="button" class="gray" id="quickToggle" aria-expanded="true" aria-controls="quickContent">MINIMIZE −</button></div><div class="quick-content" id="quickContent"><div class="quickbar">
<div class="quick"><span class="qicon">📁</span><div class="qbody"><h4>New Folder</h4><form method="post"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="mkdir"><input name="name" placeholder="Folder name" required><button class="green">Create</button></form></div></div>
<div class="quick"><span class="qicon">📄</span><div class="qbody"><h4>New File</h4><form method="post"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="newfile"><input name="name" placeholder="filename.php" required><button>Create</button></form></div></div>
<div class="quick"><span class="qicon">☁️</span><div class="qbody"><h4>Upload Files</h4><form method="post" enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="upload"><input type="file" name="upload[]" multiple required><button class="green">Upload</button></form></div></div>
<div class="quick"><span class="qicon">🗜️</span><div class="qbody"><h4>Compress Folder</h4><form method="post"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="zip"><input name="zipname" placeholder="backup.zip" required><button>ZIP</button></form></div></div>
<div class="quick"><span class="qicon">📋</span><div class="qbody"><h4>Clipboard</h4><div class="muted"><?php if (!empty($_SESSION['fm_clip'])) echo fm_h($_SESSION['fm_clip']['mode'] . ': ' . $_SESSION['fm_clip']['path']); else echo 'Clipboard empty'; ?></div><form method="post"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="paste"><button class="green">Paste</button></form></div></div>
<div class="quick"><span class="qicon">🔍</span><div class="qbody"><h4>Search</h4><form class="search" method="get"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input name="q" value="<?php echo fm_h($query); ?>" placeholder="File or folder name"><button>Find</button></form></div></div>
</div></div></div>

<?php if ($query !== ''): ?>
<div class="card"><h3>🔎 Search Results: <?php echo fm_h($query); ?></h3>
<?php if ($searchResults): foreach ($searchResults as $r): ?>
<div class="rowitem"><div class="iname"><strong><?php echo $r['dir'] ? '📁 ' : '📄 '; ?><?php echo fm_h($r['name']); ?></strong><span class="muted"><?php echo fm_h($r['path']); ?></span></div><div class="actions"><?php if ($r['dir']): ?><a class="btn" href="?dir=<?php echo urlencode($r['path']); ?>">OPEN</a><?php else: ?><a class="btn green" href="?download=<?php echo urlencode($r['path']); ?>">DOWNLOAD</a><a class="btn" href="?dir=<?php echo urlencode($dir); ?>&edit=<?php echo urlencode($r['path']); ?>">EDIT</a><?php endif; ?></div></div>
<?php endforeach; else: ?><div class="empty">Tidak ada hasil pencarian.</div><?php endif; ?></div>
<?php endif; ?>

<div class="card">
<div class="listhead"><h3>📂 File &amp; Folder List</h3><div class="bulk-tools">
<form id="bulkZipForm" method="post" onsubmit="return confirm('Buat ZIP dari semua item yang dipilih?')"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="bulk_zip"><input type="text" name="zipname" placeholder="pilihan.zip" value="pilihan.zip" required><button class="green" type="submit">ZIP Pilihan</button></form>
<form id="bulkDeleteForm" method="post" onsubmit="return confirm('Yakin hapus semua item yang dipilih? Folder akan dihapus beserta seluruh isinya.')"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="bulk_delete"><button class="red" type="submit">Hapus Pilihan</button></form>
<button class="gray" type="button" onclick="document.querySelectorAll('.pick').forEach(x=>x.checked=true)">Pilih Semua</button><button class="gray" type="button" onclick="document.querySelectorAll('.pick').forEach(x=>x.checked=false)">Batal</button>
</div></div>
<?php if ($dir !== ''): ?><div class="rowitem"><div class="iname"><strong>📁 ..</strong><span class="muted">Kembali ke folder sebelumnya</span></div><a class="btn gray" href="?dir=<?php echo urlencode($parentDir); ?>">BACK</a></div><?php endif; ?>

<?php foreach ($folders as $item):
$rel = ($dir !== '' ? $dir . '/' : '') . $item;
$full = $current . DIRECTORY_SEPARATOR . $item;
?>
<div class="rowitem"><input class="pick" type="checkbox" name="selected[]" value="<?php echo fm_h($item); ?>" aria-label="Pilih folder <?php echo fm_h($item); ?>"><div class="iname"><strong>📁 <a href="?dir=<?php echo urlencode($rel); ?>"><?php echo fm_h($item); ?></a></strong><span class="muted">Folder · <?php echo date('d/m/Y H:i', filemtime($full)); ?> · <?php echo substr(sprintf('%o', fileperms($full)), -4); ?></span></div>
<div class="actions">
<?php foreach (array('copy'=>'COPY','cut'=>'CUT') as $mode=>$label): ?><form method="post"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="clipboard"><input type="hidden" name="name" value="<?php echo fm_h($item); ?>"><input type="hidden" name="mode" value="<?php echo fm_h($mode); ?>"><button class="gray"><?php echo $label; ?></button></form><?php endforeach; ?>
<form method="post"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="rename"><input type="hidden" name="name" value="<?php echo fm_h($item); ?>"><input name="newname" placeholder="Nama baru" required><button>RENAME</button></form>
<form method="post" onsubmit="return confirm('Hapus folder beserta seluruh isinya?')"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="name" value="<?php echo fm_h($item); ?>"><button class="red">DELETE</button></form>
</div></div>
<?php endforeach; ?>

<?php foreach ($files as $item):
$rel = ($dir !== '' ? $dir . '/' : '') . $item;
$full = $current . DIRECTORY_SEPARATOR . $item;
?>
<div class="rowitem"><input class="pick" type="checkbox" name="selected[]" value="<?php echo fm_h($item); ?>" aria-label="Pilih file <?php echo fm_h($item); ?>"><div class="iname"><strong>📄 <?php echo fm_h($item); ?></strong><span class="muted"><?php echo fm_size(filesize($full)); ?> · <?php echo date('d/m/Y H:i', filemtime($full)); ?> · <?php echo substr(sprintf('%o', fileperms($full)), -4); ?></span></div>
<div class="actions">
<a class="btn green" href="?download=<?php echo urlencode($rel); ?>">DOWNLOAD</a>
<a class="btn" href="?dir=<?php echo urlencode($dir); ?>&edit=<?php echo urlencode($rel); ?>">EDIT</a>
<?php if (strtolower(substr($item, -4)) === '.zip'): ?><form method="post" onsubmit="return confirm('Ekstrak ZIP ke folder ini?')"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="unzip"><input type="hidden" name="name" value="<?php echo fm_h($item); ?>"><button class="green">EXTRACT</button></form><?php endif; ?>
<?php foreach (array('copy'=>'COPY','cut'=>'CUT') as $mode=>$label): ?><form method="post"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="clipboard"><input type="hidden" name="name" value="<?php echo fm_h($item); ?>"><input type="hidden" name="mode" value="<?php echo fm_h($mode); ?>"><button class="gray"><?php echo $label; ?></button></form><?php endforeach; ?>
<form method="post"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="rename"><input type="hidden" name="name" value="<?php echo fm_h($item); ?>"><input name="newname" placeholder="Nama baru" required><button>RENAME</button></form>
<form method="post"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="chmod"><input type="hidden" name="name" value="<?php echo fm_h($item); ?>"><input name="permission" placeholder="0644" pattern="[0-7]{3,4}" required><button class="gray">CHMOD</button></form>
<form method="post" onsubmit="return confirm('Hapus file ini?')"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="name" value="<?php echo fm_h($item); ?>"><button class="red">DELETE</button></form>
</div></div>
<?php endforeach; ?>
<?php if (!$folders && !$files): ?><div class="empty">Folder ini masih kosong.</div><?php endif; ?>
</div>

<?php if ($editor !== null): ?>
<div class="card"><h3>✏️ Code Editor: <?php echo fm_h($editor['name']); ?></h3><p class="muted"><?php echo fm_h($editor['path']); ?> · Maksimum 2 MB</p>
<form method="post"><input type="hidden" name="csrf" value="<?php echo fm_h($_SESSION['fm_token']); ?>"><input type="hidden" name="dir" value="<?php echo fm_h($dir); ?>"><input type="hidden" name="action" value="save"><input type="hidden" name="file" value="<?php echo fm_h($editor['path']); ?>"><textarea class="editor" name="content" spellcheck="false"><?php echo fm_h($editor['content']); ?></textarea><button class="green">SAVE CHANGES</button> <a class="btn gray" href="?dir=<?php echo urlencode($dir); ?>">CLOSE EDITOR</a></form>
</div>
<?php endif; ?>

<div class="card footer">FILE MANAGER ULTIMATE · Root domain terbatas · PHP <?php echo fm_h(PHP_VERSION); ?> · <?php echo class_exists('ZipArchive') ? 'ZIP ENABLED' : 'ZIP DISABLED'; ?><br>Gunakan HTTPS. Hapus file manager setelah selesai jika tidak diperlukan.</div>
</div>
<script>
(function(){
  var toggle=document.getElementById('quickToggle'), content=document.getElementById('quickContent');
  if(toggle&&content){
    var collapsed=false; try{collapsed=localStorage.getItem('fmQuickCollapsed')==='1';}catch(e){}
    function paint(){content.classList.toggle('is-collapsed',collapsed);toggle.textContent=collapsed?'EXPAND +':'MINIMIZE −';toggle.setAttribute('aria-expanded',collapsed?'false':'true');}
    toggle.addEventListener('click',function(){collapsed=!collapsed;try{localStorage.setItem('fmQuickCollapsed',collapsed?'1':'0');}catch(e){}paint();});paint();
  }
  function bindBulk(id){var form=document.getElementById(id);if(!form)return;form.addEventListener('submit',function(ev){
    form.querySelectorAll('input[name="selected[]"]').forEach(function(n){n.remove();});
    document.querySelectorAll('.pick:checked').forEach(function(box){var h=document.createElement('input');h.type='hidden';h.name='selected[]';h.value=box.value;form.appendChild(h);});
    if(!form.querySelector('input[name="selected[]"]')){alert('Pilih minimal satu file atau folder terlebih dahulu.');ev.preventDefault();}
  });}
  bindBulk('bulkZipForm');bindBulk('bulkDeleteForm');
})();
</script>
</div>
</body></html>
